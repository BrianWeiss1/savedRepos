# Stock-Analyser

This Repository is based around analyzing stocks and deciding the best stocks to invest in based on their predictions from a stock analyst.

This Repository has numerous ways of showing this data: from the bots to thr shortGrab.py

There will be serveral customizable features that this file comes with:
1. Custom Sensitivity

The qulaifications for a stock of this nature must be of follows:

1. The specific stock must have a marketcap >20 million
2. The specific stock must be listed on the NASDAQ/NYSE/AMEX
3. The specific stock must be recognized as a stock/index. No cryptocurrenies, currencies, or commodities are allowed.


