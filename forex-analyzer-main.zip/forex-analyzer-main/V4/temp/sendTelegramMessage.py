def send_message(text, bot):
    chat_id = 5046185897
    bot.send_message(chat_id, text)
