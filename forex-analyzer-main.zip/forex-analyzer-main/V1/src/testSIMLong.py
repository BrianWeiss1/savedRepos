
if __name__ == '__main__':
    print("MAIN")

'''
ToDo:
Setup hull:
  HMA 150 close
  HMA 95 close

If RSI > 45 and < 55: 
    dont trade
When prev HMA 90 > prev HMA 150 and HMA 90 < HMA 150:
 sell 20 min
if prev HMA 90 < prev HMA 150 and HMA 90 > HMA 150:
buy 20min
'''