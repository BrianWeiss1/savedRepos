
import yfinance as yf
from src.testGrabData import calltimes, calltimes15m, calltimes5m, grabHistoricalData, grabHistoricalDataBTC, calltimes30
import pandas as pd
symbol = "BTCUSD"
# data = grabHistoricalDataBTC(symbol)
# print(data)
# f = open('documents/dataCrypto.txt', 'w')
# f.write(str(data))



# calltimes("BTCUSD", 1, "2023-09-6 0:45", 'd3234f9b98msh636f82f9af5f491p15d26ejsn2b89beb2bdc9')
# calltimes5m("BTCUSD", 1, "2022-09-6 0:42")
# calltimes15m("BTCUSD", 5000)
calltimes30('FLMUSDT')
# BTCUSD ---> 0.03925
# ETHUSD --->  0.0492
# SOLUSD ---> 0.1017
# XRPUSD ---> 0.01043
# USDTUSD ---> 0.00121
# BNBUSD ---> NA
# ADAUSD ---> 0.05
# LINKUSD ---> 0.04927
# LTCUSD --> 0.08167
# BCHUSD ---> 0.16165 --> 0.13
# ETCUSD ---> ---> Very intresting --> if increase accruacy its 0.12
# EOSUSD ---> 0.01331
# ALGOUSD --> 0.04584 --> good if u increase
# DYDXUSD ---> NA
# TRTXUSD ---> 0.00193
# DOTUSD ---> 0.0314
# UNIUSD ---> 0.03
# FILUSD ---> 0.02
# AAVEUSD ---> 0.07
# DOGEUSD ---> 0.05518
# MANAUSD ---> 0.005
# SANDUSD ---> 0.01

# aapl= yf.Ticker("BTC-USD")
# aapl_historical = aapl.history(start="2023-07-11", end="2023-09-20", interval="30m")
# print(aapl_historical)
# aapl = pd.DataFrame(aapl_historical)
# aapl.to_csv('output.csv')


