import csv
import datetime
import pytz
import requests
import subprocess
import urllib
import uuid
import constants
import yfinance as yf
from flask import redirect, render_template, session
from functools import wraps
import pandas as pd
from datetime import datetime, timedelta

def get_stock_data(stock_symbols, age_in_days):
    # Calculate the start and end dates
    end_date = datetime.now()
    start_date = end_date - timedelta(days=age_in_days)

    # Fetch the stock data from Yahoo Finance
    stock_data = yf.download(stock_symbols, start=start_date, end=end_date)

    return stock_data
def amountToDate(num):
    return (datetime.now() - timedelta(days=num)).strftime("%Y-%m-%d")

def get_old_stock_data(stock_symbols, age_in_days, offset=365):
    # Calculate the start and end dates
    end_date = datetime.now() 
    start_date = end_date - timedelta(days=age_in_days)
    start_date = start_date - timedelta(days=offset)
    # Fetch the stock data from Yahoo Finance
    stock_data = yf.download(stock_symbols, start=start_date, end=end_date)
    print(stock_data[0:age_in_days])
    return stock_data, stock_data[0:age_in_days]

def check_symbol_exists(symbol):
    try:
        stock = yf.Ticker(symbol)
        info = stock.info
        return True
    except:
        return False
def check(val):
    if val > 0 and val < constants.MAXIND:
        return True
    return False
def apology(message, cash=None, code=400):
    """Render message as an apology to user."""
    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [("-", "--"), (" ", "-"), ("_", "__"), ("?", "~q"),
                         ("%", "~p"), ("#", "~h"), ("/", "~s"), ("\"", "''")]:
            s = s.replace(old, new)
        return s
    return render_template("apology.html", cash=cash, top=code, bottom=escape(message)), code


def login_required(f):
    """
    Decorate routes to require login.

    http://flask.pocoo.org/docs/0.12/patterns/viewdecorators/
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated_function


def lookup(symbol):
    """Look up quote for symbol."""

    # Prepare API request
    symbol = symbol.upper()
    end = datetime.datetime.now(pytz.timezone("US/Eastern"))
    start = end - datetime.timedelta(days=7)

    # Yahoo Finance API
    url = (
        f"https://query1.finance.yahoo.com/v7/finance/download/{urllib.parse.quote_plus(symbol)}"
        f"?period1={int(start.timestamp())}"
        f"&period2={int(end.timestamp())}"
        f"&interval=1d&events=history&includeAdjustedClose=true"
    )

    # Query API
    try:
        response = requests.get(url, cookies={"session": str(uuid.uuid4())}, headers={"User-Agent": "python-requests", "Accept": "*/*"})
        response.raise_for_status()

        # CSV header: Date,Open,High,Low,Close,Adj Close,Volume
        quotes = list(csv.DictReader(response.content.decode("utf-8").splitlines()))
        quotes.reverse()
        price = round(float(quotes[0]["Adj Close"]), 2)
        return {
            "name": symbol,
            "price": price,
            "symbol": symbol
        }
    except (requests.RequestException, ValueError, KeyError, IndexError):
        return None


def usd(value):
    """Format value as USD."""
    return f"${value:,.2f}"
if __name__ == '__main__':
    stock_symbols = eval(open('static/stockList.txt').read())
    age_in_days = 30 # Number of days for which you want the data
    data = get_stock_data(stock_symbols, age_in_days)

    print(data['Close']['AAPL'][-1])

