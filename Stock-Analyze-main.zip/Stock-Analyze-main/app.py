import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime
from helpers import amountToDate, apology, get_old_stock_data, get_stock_data, login_required, lookup, usd, check, check_symbol_exists
import constants
from indicatorHelps import AROONrun, BBrun, DOUBLEHMArun, EMArun, HMArun, RSIRun, STOCHRSIrun, STOCHrun, SUPERTRENDrun
import json
# Configure application
app = Flask(__name__)

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response
@app.route('/killIndicator', methods=['POST'])
@login_required
def removeIndicator():
    indicator = request.form.get('x')
    db.execute('DELETE FROM indicators WHERE indicator_name == ? AND user_id == ?', indicator, session['user_id'])
    return redirect('/')

@app.route('/killStock', methods=['POST'])
@login_required
def removeStock():
    indicator = request.form.get('x')
    db.execute('DELETE FROM stocks WHERE stock == ? AND user_id == ?', indicator, session['user_id'])
    return redirect('/')

@app.route("/", methods=['POST', 'GET'])
@login_required
def index():
    if request.method == 'POST':
        indicator_name = request.form.get('indicator_name')
        weight = request.form.get('weight')
        if indicator_name and weight:
            try: 
                weight = float(weight)
            except ValueError:
                return apology('Invalid Weight')
            if weight >= 0:
                indicatorValues = db.execute('SELECT value1, value2, value3, value4, value5 FROM indicators WHERE user_id == ? AND indicator_name == ?', session['user_id'], indicator_name)[0]
                print(indicatorValues)
                db.execute('REPLACE INTO indicators (user_id, indicator_name, weight, value1, value2, value3, value4, value5) VALUES(?, ?, ?, ?, ?, ?, ?, ?)', session['user_id'], indicator_name, weight, indicatorValues['value1'], indicatorValues['value2'], indicatorValues['value3'], indicatorValues['value4'], indicatorValues['value5'])
                return redirect('/')
            else:
                return apology('Weight must be > or = 0')
        else:
            return apology('invalid weight')
    else:
        stocks = db.execute('SELECT * FROM stocks WHERE user_id == ?', session['user_id'])
        indicators = db.execute('SELECT * FROM indicators WHERE user_id == ?', session['user_id'])
        return render_template('index.html', stocks=stocks, indicators=indicators)

def is_integer_like(n):
    try:
        n = float(n)
    except ValueError:
        return False
    try:
        return n == int(n)
    except (ValueError, TypeError):
        return False

@app.route("/indicator", methods=["GET", "POST"])
@login_required
def addIndicator():
    """Buy shares of stock"""
    if request.method == "POST":
        continuation = False
        indicator = request.form.get('indicator')
        indVal1 = request.form.get('Val1')
        indVal2 = request.form.get('Val2')
        indVal3 = request.form.get('Val3')
        indVal4 = request.form.get('Val4')
        if indicator:
            if indicator in constants.INDICATORS:
                numInds = constants.INDICATORLENGTH[indicator]
                if numInds == 1 and indVal1:
                    try:
                        indVal1 = int(indVal1)
                        if check(indVal1):
                            continuation = True
                    except ValueError: 
                        return apology('Invalid Indicator Value/s')
                    if continuation:
                        db.execute('REPLACE INTO indicators (user_id, indicator_name, value1) VALUES(?, ?, ?)', session['user_id'], indicator, indVal1)
                        return redirect('/')
                    else:
                        return apology('Invalid Indicator Value/s')
                elif numInds == 2 and indVal1 and indVal2:
                    print("WOKING")
                    try:
                        indVal1 = int(indVal1)
                        indVal2 = int(indVal2)
                        if check(indVal1) and check(indVal2):
                            continuation = True
                    except ValueError:
                        return apology('Invalid indicators')
                    if continuation:
                        db.execute('REPLACE INTO indicators (user_id, indicator_name, value1, value2) VALUES(?, ?, ?, ?)', session['user_id'], indicator, indVal1, indVal2)
                        return redirect('/')
                    else:
                        return apology('Invalid indicators')
                elif numInds == 3 and indVal1 and indVal2 and indVal3:
                    try:
                        indVal1 = int(indVal1)
                        indVal2 = int(indVal2)
                        indVal3 = int(indVal3)
                        if check(indVal1) and check(indVal2) and check(indVal3):
                            continuation = True                            
                    except ValueError:
                        return apology('Invalid indicators')
                    if continuation:
                        db.execute('REPLACE INTO indicators (user_id, indicator_name, value1, value2, value3) VALUES(?, ?, ?, ?, ?)', session['user_id'], indicator, indVal1, indVal2, indVal3)
                        return redirect('/')
                    else:
                        return apology('Invalid indicators')
                elif numInds == 4 and indVal1 and indVal2 and indVal3 and indVal4:
                    try:
                        indVal1 = int(indVal1)
                        indVal2 = int(indVal2)
                        indVal3 = int(indVal3)
                        indVal4 = int(indVal4)
                        if check(indVal1) and check(indVal2) and check(indVal3) and check(indVal4):
                            continuation = True
                    except ValueError:
                        return apology('Invalid indicators')
                    if continuation:
                        db.execute('REPLACE INTO indicators (user_id, indicator_name, value1, value2, value3, value4) VALUES(?, ?, ?, ?, ?, ?)', session['user_id'], indicator, indVal1, indVal2, indVal3, indVal4)
                        return redirect('/')
                    else:
                        return apology('Invalid indicators')
                else:
                    continuation = False
                    return apology('Invalid Indicators')
                
            else:
                return apology('Please provide an indicator')
        else:
            return apology("Please provide an indicator")
    else:
        return render_template("addIndicator.html", indicators=constants.INDICATORS)


@app.route("/history")
@login_required
def history():
    cash = db.execute("SELECT * FROM users WHERE id == ?", session["user_id"])
    cash = round(cash[0].get("cash"), 2)
    """Show history of transactions"""
    transactions = db.execute(
        "SELECT * FROM transactions WHERE user_id == ?", session["user_id"]
    )
    return render_template("history.html", transactions=transactions)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute(
            "SELECT * FROM users WHERE username = ?", request.form.get("username")
        )

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/stock", methods=["GET", "POST"])
@login_required
def addStock():
    """Get stock quote."""
    if request.method == "POST":
        stock_symbol = request.form.get("symbol")
        if stock_symbol:
            if check_symbol_exists(stock_symbol):
                try:
                    db.execute('INSERT INTO stocks (user_id, stock) VALUES(?, ?)', session['user_id'], stock_symbol.upper())
                except ValueError:
                    return redirect('/')
                return redirect('/')
            else:
                return apology('Invalid stock symbol')
        else:
            return apology("Blank Input")
    else:
        return render_template("addStock.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")
        if username and password and confirmation:
            if password == confirmation:
                currentUser = db.execute(
                    "SELECT username FROM users WHERE username == ?", username
                )
                if len(currentUser) == 0:
                    db.execute(
                        "INSERT INTO users (username, hash) VALUES(?, ?)",
                        username,
                        generate_password_hash(password),
                    )
                    return render_template("login.html")
                else:
                    return apology("Invalid Username")
            else:
                return apology("Password Incorrect Repeat")
        else:
            return apology("Bad Username/Password")
    else:
        return render_template("register.html")

def resultsExist():
    rows = db.execute('SELECT * FROM results WHERE user_id == ?', session['user_id'])
    if rows:
        return rows
    return False
def backtestExist():
    rows = db.execute('SELECT * FROM backtest WHERE user_id == ?', session['user_id'])
    if rows:
        return rows
    return False
@app.route('/oldResults', methods=['POST'])
@login_required
def oldResults():
    rows = resultsExist()
    if rows:
        rows = [[item['stock'], item['rank']] for item in rows]
        stockList = sorted(rows, key=lambda x: x[1], reverse=True)
        return render_template('results.html', stockList=stockList)
    else:
        return apology('No results exist')


@app.route('/results', methods=["GET", "POST"])
@login_required
def results():
    if request.method == 'GET':
        # 100/min
        stockAmount = db.execute('SELECT COUNT(*) FROM stocks WHERE user_id == ?', session['user_id'])[0]['COUNT(*)']
        minutes = stockAmount / 100
        return render_template('getResult.html', time=minutes)
    else:
        indicatorValues = db.execute('SELECT indicator_name, value1, value2, value3, value4, value5, weight FROM indicators WHERE user_id == ?', session['user_id'])
        stocks = db.execute('SELECT stock FROM stocks WHERE user_id == ?', session['user_id'])
        maxiumum = 0
        stockArr = []
        for indicator in indicatorValues:
            weight = indicator['weight']
            if not weight:
                weight = 1
            if indicator['indicator_name'] != 'RSI' and indicator['indicator_name'] != 'Aroon' and indicator['indicator_name'] != 'Bollinger Bands':
                maxiumum+=weight*2
            maxiumum+=weight*1
            
        for stock in stocks:
            stockArr.append(stock['stock'])
        stockPowers = []
        highest_value = 0
        for entry in indicatorValues:
            for key in ['value1', 'value2', 'value3', 'value4', 'value5']:
                if entry[key] is not None and int(entry[key]) > highest_value:
                    highest_value = int(entry[key])

        all_stock_data = get_stock_data(stockArr, highest_value*2) # about 1 hour for 9900 stocks. 165 stocks a minute 3 a second

        for stock in stocks:
            sumPow = 0
            for indicator in indicatorValues:
                weight = indicator['weight']
                if not weight:
                    weight = 1
                if indicator['indicator_name'] == 'RSI': # -2 -
                    try:
                        power = RSIRun(all_stock_data['Close'][stock['stock']], int(indicator['value1']))
                        sumPow+=power*weight*2
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'HMA':
                    try:
                        power = HMArun(all_stock_data['Close'][stock['stock']], int(indicator['value1'])) #1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'Aroon':
                    try:
                        power = AROONrun(all_stock_data['High'][stock['stock']], all_stock_data['Low'][stock['stock']], int(indicator['value1']))
                        sumPow+=power*weight*2
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'EMA':
                    try:
                        power = EMArun(all_stock_data['Close'][stock['stock']], int(indicator['value1']), int(indicator['value2'])) # 1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'Double HMA':
                    try:
                        power = DOUBLEHMArun(all_stock_data['Close'][stock['stock']], int(indicator['value1']), int(indicator['value2'])) # 1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'Stochastic Oscillator':
                    try:
                        power = STOCHrun(all_stock_data['Close'][stock['stock']], all_stock_data['High'][stock['stock']], all_stock_data['Low'][stock['stock']], int(indicator['value1']), int(indicator['value2']), int(indicator['value3'])) # 1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                if indicator['indicator_name'] == 'Bollinger Bands':
                    try:
                        power = BBrun(all_stock_data['Close'][stock['stock']], int(indicator['value1']), int(indicator['value2'])) # 2, -2
                        sumPow+=power*weight*2
                    except (IndexError, TypeError):
                        sumPow+=0
                if indicator['indicator_name'] == 'Supertrend':
                    try:
                        power = SUPERTRENDrun(all_stock_data['Close'][stock['stock']], all_stock_data['High'][stock['stock']], all_stock_data['Low'][stock['stock']], int(indicator['value1']), int(indicator['value2'])) # 1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'Stochastic RSI':
                    try:
                        power = STOCHRSIrun(all_stock_data['Close'][stock['stock']], int(indicator['value1']), int(indicator['value2']), int(indicator['value3'])) # 1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
            sumPow = round((sumPow/maxiumum)*100, 2)
            if not sumPow:
                sumPow = 0
            stockPowers.append([stock['stock'], sumPow])
        sorted_stockPowers = sorted(stockPowers, key=lambda x: x[1], reverse=True)
        print(sorted_stockPowers)
        db.execute("DELETE FROM results WHERE user_id == ?", session['user_id'])
        for i in range(1, len(sorted_stockPowers)+1):
            db.execute("INSERT INTO results (user_id, rank, stock) VALUES(?, ?, ?)", session['user_id'], sorted_stockPowers[i-1][1], sorted_stockPowers[i-1][0])
        return render_template('results.html', stockList=sorted_stockPowers)

@app.route('/autoFillStock', methods=['POST'])
@login_required
def autoFill():
    with open('static/stockList.txt') as file:
        stockList = eval(file.read())
    for stock in stockList:
        db.execute('REPLACE INTO stocks (user_id, stock) VALUES(?, ?)', session['user_id'], stock)
    return redirect('/')

@app.route('/backtest', methods=['GET', 'POST'])
@login_required
def backtest():
    if request.method == 'POST':
        time = request.form.get('length')
        print(time)
        if not time:
            return apology('Invalid Time')
            time = 365
        if time == '2 months':
            time = 60
        if time == '6 months':
            time = 180
        if time =='1 year':
            time = 365
        if time == '2 years':
            time = 730
        if time == '3 years':
            time = 1095
        if time == '5 years':
            time = 1825
        
        indicatorValues = db.execute('SELECT indicator_name, value1, value2, value3, value4, value5, weight FROM indicators WHERE user_id == ?', session['user_id'])
        stocks = db.execute('SELECT stock FROM stocks WHERE user_id == ?', session['user_id'])
        stockArr = []
        for stock in stocks:
            stockArr.append(stock['stock'])
        stockPowers = []
        highest_value = 0
        for entry in indicatorValues:
            for key in ['value1', 'value2', 'value3', 'value4', 'value5']:
                if entry[key] is not None and int(entry[key]) > highest_value:
                    highest_value = int(entry[key])

        all_stock_data, stock_data = get_old_stock_data(stockArr, highest_value*2, time) 
        print("STARTTTING")
        print('\n\n')
        maxiumum = 0
        for indicator in indicatorValues:
            weight = indicator['weight']
            if not weight:
                weight = 1
            if indicator['indicator_name'] != 'RSI' and indicator['indicator_name'] != 'Aroon' and indicator['indicator_name'] != 'Bollinger Bands':
                maxiumum+=weight*2
            maxiumum+=weight*1
            
        for stock in stocks:
            sumPow = 0
            
            for indicator in indicatorValues:
                weight = indicator['weight']
                if not weight:
                    weight = 1
                if indicator['indicator_name'] == 'RSI': # -2 -
                    try:
                        power = RSIRun(stock_data['Close'][stock['stock']], int(indicator['value1'])) # 2, -2
                        sumPow+=power*weight*2
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'HMA':
                    try:
                        power = HMArun(stock_data['Close'][stock['stock']], int(indicator['value1'])) #1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'Aroon':
                    try:
                        power = AROONrun(stock_data['High'][stock['stock']], stock_data['Low'][stock['stock']], int(indicator['value1'])) # 2, -2
                        sumPow+=power*weight*2
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'EMA':
                    try:
                        power = EMArun(stock_data['Close'][stock['stock']], int(indicator['value1']), int(indicator['value2'])) # 1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'Double HMA':
                    try:
                        power = DOUBLEHMArun(stock_data['Close'][stock['stock']], int(indicator['value1']), int(indicator['value2'])) # 1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'Stochastic Oscillator':
                    try:
                        power = STOCHrun(stock_data['Close'][stock['stock']], stock_data['High'][stock['stock']], stock_data['Low'][stock['stock']], int(indicator['value1']), int(indicator['value2']), int(indicator['value3'])) # 1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                if indicator['indicator_name'] == 'Bollinger Bands':
                    try:
                        power = BBrun(stock_data['Close'][stock['stock']], int(indicator['value1']), int(indicator['value2'])) # 2, -2
                        sumPow+=power*weight*2
                    except (IndexError, TypeError):
                        sumPow+=0
                if indicator['indicator_name'] == 'Supertrend':
                    try:
                        power = SUPERTRENDrun(stock_data['Close'][stock['stock']], stock_data['High'][stock['stock']], stock_data['Low'][stock['stock']], int(indicator['value1']), int(indicator['value2'])) # 1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
                elif indicator['indicator_name'] == 'Stochastic RSI':
                    try:
                        power = STOCHRSIrun(stock_data['Close'][stock['stock']], int(indicator['value1']), int(indicator['value2']), int(indicator['value3'])) # 1, -1
                        sumPow+=power*weight
                    except (AttributeError, IndexError, TypeError):
                        sumPow+=0
            sumPow = round((sumPow/maxiumum)*100, 2)
            if not sumPow:
                sumPow = 0
            stockPowers.append([stock['stock'], sumPow])
        sorted_stockPowers = sorted(stockPowers, key=lambda x: x[1], reverse=True)
        # stockData = grabData1Year(stock)
        stockBacktest = {}
        for stock in stockArr:
            tempDic = {}
            try:
                tempDic['0'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2)]
            except KeyError:
                for i in range(1, 30):
                    try:
                        tempDic['0'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2+i)]
                        break
                    except:
                        continue
            try:
                tempDic['1 Month'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2+30)]
            except KeyError:
                for i in range(1, 30):
                    try:
                        tempDic['1 Month'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2+i-30)]
                        break
                    except:
                        continue
            try:
                tempDic['2 Month'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2+60)]
            except KeyError:
                for i in range(1, 30):
                    try:
                        tempDic['2 Month'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2+i-60)]
                        break
                    except:
                        continue
            try:
                tempDic['3 Month'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2+90)]
            except KeyError:
                for i in range(1, 30):
                    try:
                        tempDic['3 Month'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2+90-i)]
                        break
                    except:
                        continue
            try:
                tempDic['6 Month'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2+180)]
            except KeyError:
                for i in range(1, 30):
                    try:
                        tempDic['6 Month'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2-i+180)]
                        break
                    except:
                        continue
            try:
                tempDic['9 Month'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2+270)]
            except KeyError:
                for i in range(1, 30):
                    try:
                        tempDic['9 Month'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2-i+270)]
                        break
                    except:
                        continue
            try:
                tempDic['1 year'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2+360)]
            except KeyError:
                for i in range(1, 30):
                    try:
                        tempDic['1 year'] = all_stock_data['Close'][stock].loc[amountToDate(highest_value*2-i+360)]
                        break
                    except:
                        continue
            stockBacktest[stock] = tempDic
        
        db.execute("DELETE FROM backtest WHERE user_id == ?", session['user_id'])
        for i in range(1, len(sorted_stockPowers)+1):
            db.execute("INSERT INTO backtest (user_id, rank, stock, newValues) VALUES(?, ?, ?, ?)", session['user_id'], sorted_stockPowers[i-1][1], sorted_stockPowers[i-1][0], json.dumps(stockBacktest[sorted_stockPowers[i-1][0]]))
        return render_template('backtest.html', stockList=sorted_stockPowers, stockBacktest=stockBacktest)
    else:
        stockAmount = db.execute('SELECT COUNT(*) FROM stocks WHERE user_id == ?', session['user_id'])[0]['COUNT(*)']
        minutes = stockAmount / 100
        return render_template('getBacktest.html', time=minutes)
    
@app.route('/removeAllStocks', methods=['POST'])
@login_required
def removeAllStocks(): 
    db.execute('DELETE FROM stocks WHERE user_id == ?', session['user_id'])
    return redirect('/')

@app.route('/removeAllIndicators', methods=['POST'])
@login_required
def removeAllIndicators(): 
    db.execute('DELETE FROM indicators WHERE user_id == ?', session['user_id'])
    return redirect('/')

@app.route('/oldbacktest', methods=['POST'])
@login_required
def oldBacktest(): 
    rows = backtestExist()
    print(rows)
    if rows:
        stockBacktest = {item['stock']: json.loads(item['newValues']) for item in rows}
        stocks = [[item['stock'], item['rank']] for item in rows]
        stockList = sorted(stocks, key=lambda x: x[1], reverse=True)
        return render_template('backtest.html', stockList=stockList, stockBacktest=stockBacktest)
        # return render_template('backtest.html', stockList=stockList, oldPrice=___, 1weekPrice = ___, 1monthPrice = ___, 3monthPrice = ___, 6monthPrice = ___, 1yearPrice = ___, 2yearPrice = ___, 3yearPrice = ___, 5yearPrice = ___)
    else:
        return apology('No results exist')
