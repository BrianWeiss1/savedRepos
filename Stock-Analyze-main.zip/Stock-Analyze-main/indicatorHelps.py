from ta.momentum import StochRSIIndicator
from ta.momentum import StochasticOscillator
from ta.momentum import RSIIndicator
from ta.trend import EMAIndicator
import pandas_ta 
from helpers import get_stock_data
import numpy as np
def RSIRun(closeData, indVal):
    rsiInd = RSIIndicator(closeData, indVal)
    val = rsiInd.rsi().iloc[-1]
    total = val + (100-val)    
    percentage_x = (val - (100-val)) / total
    power = round(percentage_x, 2)
    return power

def HMArun(closeData, indVal):
    if indVal < 1:
        return False
    hma = pandas_ta.hma(closeData, length=indVal)
    hullPrice = hma.iloc[-1]
    lastPrice = closeData.iloc[-1]
    if hullPrice < lastPrice: # buy 
        return 1
    elif hullPrice > lastPrice: # sell
        return -1
    else:
        return 0
def AROONrun(highData, lowData, indVal):
    aroon = pandas_ta.aroon(highData, lowData, length=indVal)
    aroon = aroon.iloc[-1]
    if aroon[f'AROONOSC_{indVal}'] < 80 and aroon[f'AROONOSC_{indVal}'] > -80:
        return aroon[f'AROONOSC_{indVal}']*0.5 / 100
    else:
        return aroon[f'AROONOSC_{indVal}'] / 100
def EMArun(closeData, indVal1, smoothingPeriod):
    ema = EMAIndicator(closeData, indVal1).ema_indicator()
    emaSmooth = EMAIndicator(ema, smoothingPeriod).ema_indicator()
    valSmooth = emaSmooth.iloc[-1]
    val = ema.iloc[-1]
    if valSmooth > val:
        return 1
    elif valSmooth < val:
        return -1
    else:
        return 0
def DOUBLEHMArun(closeData, longerPeriod, shorterPeriod):
    longerHMA = pandas_ta.hma(closeData, length=longerPeriod).iloc[-1]
    shorterHMA = pandas_ta.hma(closeData, length=shorterPeriod).iloc[-1]
    lastData = closeData.iloc[-1]
    if shorterHMA > longerHMA:
        if lastData > shorterHMA:
            return 1
        elif lastData < shorterHMA and lastData > longerHMA: 
            return 0
        elif lastData < longerHMA: 
            return -1
    elif longerHMA > shorterHMA:
        if lastData > longerHMA:
            return -1
        elif lastData < longerHMA and lastData > shorterHMA:
            return 0
        elif lastData < shorterHMA:
            return 1
def STOCHrun(closeData, highData, lowData, KLength, KSmoothing, DSmoothing):
    stoch = pandas_ta.stoch(highData, lowData, closeData, KLength, DSmoothing, KSmoothing)
    i = -1
    if  stoch[f'STOCHk_{KLength}_{DSmoothing}_{KSmoothing}'].iloc[i] > (stoch[f'STOCHd_{KLength}_{DSmoothing}_{KSmoothing}'].iloc[i]*1.03):
        return -1
    elif (stoch[f'STOCHk_{KLength}_{DSmoothing}_{KSmoothing}'].iloc[i]*1.03) < stoch[f'STOCHd_{KLength}_{DSmoothing}_{KSmoothing}'].iloc[i]:
        return 1
    else:
        return 0
def STOCHRSIrun(closeData,  k, d, rsi_length):
    stochrsi = pandas_ta.stochrsi(closeData, length=rsi_length, rsi_length=rsi_length, k=k, d=d)
    if stochrsi.iloc[-1][f'STOCHRSIk_{rsi_length}_{rsi_length}_{k}_{d}'] > 0.8 and stochrsi.iloc[-1][f'STOCHRSId_{rsi_length}_{rsi_length}_{k}_{d}'] > 0.8:
        return -1
    elif stochrsi.iloc[-1][f'STOCHRSIk_{rsi_length}_{rsi_length}_{k}_{d}'] < 0.2 and stochrsi.iloc[-1][f'STOCHRSId_{rsi_length}_{rsi_length}_{k}_{d}'] < 0.2:
        return 1
    else:
        return 0
def BBrun(closeData, length, stdDev):
    bbBands = pandas_ta.bbands(closeData, length, stdDev)
    close = closeData.iloc[-1]
    if close <= bbBands[f'BBL_{length}_{stdDev}.0'].iloc[-1]:
        return 1
    elif close >= bbBands[f'BBU_{length}_{stdDev}.0'].iloc[-1]:
        return -1
    else:
        return 0
def SUPERTRENDrun(closeData, highData, lowData, ATRlength, factor):
    supertrend = pandas_ta.supertrend(highData, lowData, closeData, ATRlength, factor)
    if (supertrend[f'SUPERTd_{ATRlength}_{factor}.0'].iloc[-5] == supertrend[f'SUPERTd_{ATRlength}_{factor}.0'].iloc[-4]) and (supertrend[f'SUPERTd_{ATRlength}_{factor}.0'].iloc[-3] == supertrend[f'SUPERTd_{ATRlength}_{factor}.0'].iloc[-2]) and (supertrend[f'SUPERTd_{ATRlength}_{factor}.0'].iloc[-2] == supertrend[f'SUPERTd_{ATRlength}_{factor}.0'].iloc[-1]):
        return supertrend[f'SUPERTd_{ATRlength}_{factor}.0'].iloc[-1]
    
if __name__ == '__main__':
    from cs50 import SQL
    db = SQL("sqlite:///finance.db")
    indicatorValues = db.execute('SELECT indicator_name, value1, value2, value3, value4, value5, weight FROM indicators WHERE user_id == ?', 14) 
    highest_value = 0
    for entry in indicatorValues:
        for key in ['value1', 'value2', 'value3', 'value4', 'value5']:
            if entry[key] is not None and int(entry[key]) > highest_value:
                highest_value = int(entry[key])
    age_in_days = highest_value*2
    data = get_stock_data('AAPL', age_in_days)
    print(SUPERTRENDrun(closeData, 3, 3))