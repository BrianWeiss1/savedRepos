INDICATORS = ["Stochastic Oscillator", "RSI", "Stochastic RSI", "HMA", "Double HMA", "Bollinger Bands", "Supertrend", "Aroon", "EMA"]
LENGTH = [3, 1, 4, 1, 2, 2, 2, 1]
INDICATORLENGTH = {'Stochastic Oscillator': 3, 'RSI': 1, 'Stochastic RSI': 3, 'HMA': 1, 'Double HMA': 2, 'Bollinger Bands': 2, 'Supertrend': 2, 'Aroon': 1, 'EMA': 2}
INDICATORVALUES = {'Stochastic Oscillator': ['%K length', '%K Smoothing', '%D Smoothing'], 'RSI': ['RSI Length'], 'Stochastic RSI': ['K', 'D', 'RSI Length'], 'HMA': ['Length'], 'Double HMA': ['longerPeriod', 'shorterPeriod'], 'Bollinger Bands': ['Length', 'StdDev'], 'Supertrend': ['ATR Length', 'Factor'], 'Aroon': ['Length'], 'EMA': ['Length', 'Smoothing']}
INDICATORDEFAULT = {'Stochastic Oscillator': ['14', '3', '3'], 'RSI': ['14'], 'Stochastic RSI': ['3', '3', '14'], 'HMA': ['14'], 'Double HMA': ['20', '50'], 'Bollinger Bands': ['20', '2'], 'Supertrend': ['14', '3'], 'Aroon': ['14'], 'EMA': ['5', '9']}
MAXIND = 2500