#!/bin/bash

# Update the package list and install unattended-upgrades if not already installed
sudo apt update
sudo apt install -y unattended-upgrades

# Automatically configure /etc/apt/apt.conf.d/20auto-upgrades
sudo bash -c 'cat > /etc/apt/apt.conf.d/20auto-upgrades' << EOF
Unattended-Upgrade::Allowed-Origins {
    "\${distro_id}:\${distro_codename}-security";
    "\${distro_id}:\${distro_codename}-updates";
};
Unattended-Upgrade::Mail "your-email@example.com";
Unattended-Upgrade::MailOnlyOnError "true";
Unattended-Upgrade::Remove-Unused-Dependencies "true";
EOF

# Automatically configure /etc/apt/apt.conf.d/10periodic
sudo bash -c 'cat > /etc/apt/apt.conf.d/10periodic' << EOF
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::AutocleanInterval "7";
APT::Periodic::Unattended-Upgrade "1";
EOF

# Enable and start the unattended-upgrades service
sudo systemctl enable unattended-upgrades
sudo systemctl start unattended-upgrades

# Display a message to indicate that the configuration is complete
echo "Automatic security updates have been configured."