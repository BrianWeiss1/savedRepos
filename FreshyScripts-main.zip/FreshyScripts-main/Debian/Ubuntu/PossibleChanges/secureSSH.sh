#!/bin/bash

# Ensure the script is run as root
if [ "$(id -u)" != "0" ]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

#disable unnessary services
systemctl disable avahi-daemon
systemctl stop avahi-daemon
systemctl disable cups
systemctl stop cups

apt-get install apparmor apparmor-profiles -y
systemctl enable apparmor
systemctl start apparmor


# Update System Packages
echo "Updating system packages..."
apt-get update && apt-get upgrade -y

# Configure Firewall (UFW)
echo "Configuring UFW Firewall..."
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw logging on
ufw logging full
ufw limit ssh
ufw enable

sudo ufw deny 53/tcp
sudo ufw deny 53/udp
sudo ufw deny 67/tcp
sudo ufw deny 67/udp
sudo ufw deny 68/tcp
sudo ufw deny 68/udp
sudo ufw deny 111/tcp
sudo ufw deny 111/udp
sudo ufw deny 123/tcp
sudo ufw deny 123/udp
sudo ufw deny 135/tcp
sudo ufw deny 135/udp
sudo ufw deny 137/tcp
sudo ufw deny 137/udp
sudo ufw deny 138/tcp
sudo ufw deny 138/udp
sudo ufw deny 139/tcp
sudo ufw deny 139/udp
sudo ufw deny 161/tcp
sudo ufw deny 161/udp
sudo ufw deny 162/tcp
sudo ufw deny 162/udp



# Secure SSH Access
echo "Securing SSH..."
sed -i '/^Port/s/^.*$/Port 2222/' /etc/ssh/sshd_config
sed -i '/^PermitRootLogin/s/^.*$/PermitRootLogin no/' /etc/ssh/sshd_config
sed -i '/^PasswordAuthentication/s/^.*$/PasswordAuthentication no/' /etc/ssh/sshd_config
systemctl restart sshd

sudo apt install unattended-upgrades
dpkg-reconfigure -plow unattended-upgrades

# Set Strong Password Policies
echo "Setting strong password policies..."
apt-get install libpam-pwquality -y

# Configure Auditd for System Auditing
echo "Configuring auditd..."
apt-get install auditd -y
systemctl enable auditd
systemctl start auditd

# Install and Configure Fail2Ban
echo "Installing and configuring Fail2Ban..."
apt-get install fail2ban -y
systemctl enable fail2ban
systemctl start fail2ban

# Install and Configure ClamAV for Malware Scanning
echo "Installing and configuring ClamAV..."
apt-get install clamav clamav-daemon -y
systemctl stop clamav-freshclam
freshclam
systemctl start clamav-freshclam

# Configure Rsyslog for Log Management
echo "Configuring Rsyslog..."
systemctl restart rsyslog

echo "Installing and configuring AIDE..."
apt-get install aide -y
aideinit
cp /var/lib/aide/aide.db.new /var/lib/aide/aide.db
echo "0 3 * * * /usr/bin/aide.wrapper --config /etc/aide/aide.conf --check" >> /etc/crontab

echo "Security enhancements applied successfully."
# Update your package list
sudo apt update

# Install ClamAV
sudo apt install clamav clamav-daemon

# Update ClamAV's database
sudo freshclam

# Install necessary security tools
sudo apt install clamav rkhunter ufw -y

sudo ufw allow 2222
sudo ufw enable

echo "0 3 * * * root /usr/bin/rkhunter --update && /usr/bin/rkhunter --checkall --report-warnings-only" | sudo tee /etc/cron.d/rkhunter

echo "30 2 * * * root /usr/bin/clamscan -r --remove /" | sudo tee /etc/cron.d/clamav

sudo apt install lynis -y
echo "45 4 * * * root /usr/sbin/lynis audit system" | sudo tee /etc/cron.d/lynis
echo "Security enhancements applied. Please review configurations and tailor to your specific needs."
