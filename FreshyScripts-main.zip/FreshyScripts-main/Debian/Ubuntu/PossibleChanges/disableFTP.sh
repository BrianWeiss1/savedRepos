#disable ftp server
sudo systemctl stop vsftpd
sudo systemctl disable vsftpd
sudo apt-get remove vsftpd
sudo rm -r /etc/vsftpd

sudo systemctl stop proftpd
sudo systemctl disable proftpd
sudo apt-get remove proftpd
sudo rm -r /etc/proftpd

sudo systemctl stop pure-ftpd
sudo systemctl disable pure-ftpd
sudo apt-get remove pure-ftpd
sudo rm -r /etc/pure-ftpd
