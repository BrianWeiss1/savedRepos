Essental:
sudo apt install clamav
sudo apt install unattended-upgrades
sudo apt install ufw
sudo apt install fail2ban
sudo apt install apparmor
sudo apt install chkrootkit

Unimportant:
sudo apt install rkhunter
sudo apt install tripwire
sudo apt install cryptsetup
sudo apt install gnupg