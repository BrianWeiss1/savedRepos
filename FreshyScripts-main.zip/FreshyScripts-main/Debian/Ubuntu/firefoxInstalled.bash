#!/bin/bash
while (true); do
    echo "Do you want to install Firefox or Chrome via PPA? (y/n)"
    read UserInput
    if [ "$UserInput" == "y" ]; then
        sudo add-apt-repository ppa:mozillateam/firefox-next
        sudo apt update
        sudo apt install firefox
        # sets firefox as default browser
        sudo update-alternatives --install /usr/bin/x-www-browser x-www-browser /usr/bin/firefox 100
        sudo update-alternatives --install /usr/bin/gnome-www-browser gnome-www-browser /usr/bin/firefox 100
        sudo update-alternatives --config x-www-browser
        sudo update-alternatives --config gnome-www-browser
        break
    elif [ "$UserInput" == "n" ]; then
        break
    fi
    echo "Please input 'y' or 'n'"
done
