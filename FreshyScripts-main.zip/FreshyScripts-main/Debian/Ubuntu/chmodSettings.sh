#!/bin/bash

# Ensure the script is run as root
if [ "$(id -u)" != "0" ]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi
change_permission() {
    file=$1
    perm=$2

    if [ -e "$file" ]; then
        chmod $perm $file
        echo "Permissions for $file set to $perm"
    else
        echo "Warning: $file does not exist"
    fi
}
# Define an associative array of files and their recommended permissions
declare -A filePermissions=(
    ["/etc/shadow"]="600"
    ["/etc/passwd"]="644"
    ["/etc/group"]="644"
    ["/etc/gshadow"]="600"
    ["/etc/sudoers"]="440"
    ["/etc/ssh/sshd_config"]="600"
    ["/var/log/auth.log"]="600"
    ["/var/log/wtmp"]="664"
    ["/var/log/btmp"]="600"
    ["/var/log/lastlog"]="644"
    ["/etc/fstab"]="644"
    ["/etc/crontab"]="600"
    ["/etc/cron.hourly"]="700"
    ["/etc/cron.daily"]="700"
    ["/etc/cron.weekly"]="700"
    ["/etc/cron.monthly"]="700"
    ["/etc/cron.d"]="700"
    ["/etc/securetty"]="644"
    ["/etc/hosts.allow"]="644"
    ["/etc/hosts.deny"]="644"
    ["/etc/aliases.db"]="640"
    ["/etc/at.deny"]="600"
    ["/etc/bash_completion.d/"]="755"
    ["/etc/cups/"]="700"
    ["/etc/dbus-1/"]="700"
    ["/etc/default/grub"]="600"
    ["/etc/dhcp/"]="700"
    ["/etc/dovecot/"]="700"
    ["/etc/environment"]="644"
    ["/etc/exports.d/"]="700"
    ["/etc/firewalld/"]="700"
    ["/etc/fstab.d/"]="700"
    ["/etc/group-"]="600"
    ["/etc/gshadow-"]="600"
    ["/etc/hostname"]="644"
    ["/etc/init/"]="755"
    ["/etc/ld.so.conf"]="644"
    ["/etc/ld.so.conf.d/"]="755"
    ["/etc/logrotate.d/"]="700"
    ["/etc/lsb-release"]="644"
    ["/etc/mailcap"]="644"
    ["/etc/mime.types"]="644"
    ["/etc/modprobe.d/"]="700"
    ["/etc/modules"]="644"
    ["/etc/motd.d/"]="700"
    ["/etc/mtab"]="644"
    ["/etc/networks"]="644"
    ["/etc/ntp.drift"]="600"
    ["/etc/os-release"]="644"
    ["/etc/pam.conf"]="644"
    ["/etc/pam.d/"]="700"
    ["/etc/profile.d/"]="755"
    ["/etc/rc0.d/"]="755"
    ["/etc/rc1.d/"]="755"
    ["/etc/rc2.d/"]="755"
    ["/etc/rc3.d/"]="755"
    ["/etc/rc4.d/"]="755"
    ["/etc/rc5.d/"]="755"
    ["/etc/rc6.d/"]="755"
    ["/etc/rcS.d/"]="755"
    ["/etc/resolv.conf.d/"]="755"
    ["/etc/rsyslog.d/"]="700"
    ["/etc/security/limits.d/"]="700"
    ["/etc/selinux/"]="700"
    ["/etc/services"]="644"
    ["/etc/ssh/ssh_config.d/"]="700"
    ["/etc/ssl/certs/"]="755"
    ["/etc/ssl/private/"]="700"
    ["/etc/sysctl.d/"]="700"
    ["/etc/systemd/"]="755"
)

# Set permissions
for file in "${!filePermissions[@]}"; do
    chmod ${filePermissions[$file]} "$file"
done
change_permission "/etc/shadow" 600
change_permission "/etc/passwd" 644
change_permission "/etc/group" 644
change_permission "/etc/gshadow" 600
change_permission "/etc/ssh/sshd_config" 600
change_permission "/var/log/auth.log" 600
chmod 640 /etc/httpd/conf/httpd.conf
chmod 600 /etc/shadow
chmod 644 /etc/passwd
chmod 600 /etc/shadow
chmod 600 /etc/gshadow
chmod 644 /etc/passwd
chmod 644 /etc/group
chmod 755 /etc
chmod 755 /usr/bin
chmod 755 /usr/sbin
chmod 755 /bin/*
chmod 755 /usr/bin/*
chmod 700 /root
chmod 755 /home
chmod 644 /etc/sysctl.conf
chmod 640 /etc/rsyslog.conf
chmod 644 /etc/logrotate.conf
chmod 644 /etc/resolv.conf
chmod 644 /etc/nsswitch.conf
chmod 700 /etc/pam.d
chmod 700 /etc/security
chmod 644 /etc/aliases
chmod 644 /etc/mail/sendmail.cf
chmod 600 /etc/mail/access
chmod 644 /etc/mail/aliases
chmod 644 /etc/ssh/ssh_config
chmod 600 /etc/ssh/ssh_host_rsa_key
chmod 644 /etc/ssh/ssh_host_rsa_key.pub
chmod 600 /etc/ssh/ssh_host_ecdsa_key
chmod 644 /etc/ssh/ssh_host_ecdsa_key.pub
chmod 600 /etc/ssh/ssh_host_ed25519_key
chmod 644 /etc/ssh/ssh_host_ed25519_key.pub
chmod 600 /etc/network/interfaces
chmod 644 /etc/sysconfig/network
chmod 700 /etc/sysconfig/network-scripts
chmod 644 /etc/hostname
chmod 644 /etc/hosts
chmod 644 /etc/issue
chmod 644 /etc/issue.net
chmod 644 /etc/motd
chmod 644 /etc/profile
chmod 644 /etc/bashrc
chmod 600 /etc/shadow
chmod 644 /etc/inittab
chmod 755 /etc/init.d
chmod 644 /etc/login.defs
chmod 755 /usr/local/etc
chmod 640 /etc/cron.allow
chmod 640 /etc/at.allow
chmod 700 /etc/skel
chmod 644 /etc/ssh/ssh_config
chmod 600 /etc/ssh/sshd_host_dsa_key
chmod 644 /etc/ssh/sshd_host_dsa_key.pub
chmod 750 /usr/local/sbin
chmod 700 /var/spool/mail
chmod 640 /etc/mail/access.db
chmod 640 /etc/mail/domaintable.db
chmod 640 /etc/mail/mailertable.db
chmod 640 /etc/mail/virtusertable.db
chmod 640 /etc/mail/genericstable.db
chmod 640 /var/log/maillog
chmod 640 /var/log/messages
chmod 600 /var/log/secure
chmod 600 /var/log/cron
chmod 640 /var/log/boot.log
chmod 640 /etc/audit/auditd.conf
chmod 640 /etc/audit/audit.rules
chmod 644 /etc/default/useradd
chmod 600 /etc/security/opasswd
chmod 644 /etc/sysconfig/network
chmod 644 /etc/exports
chmod 644 /etc/auto.master
chmod 644 /etc/auto.misc
chmod 640 /var/log/mail.err
chmod 640 /var/log/mail.info
chmod 640 /var/log/mail.warn
chmod 640 /var/log/daemon.log
chmod 640 /var/log/debug
chmod 640 /var/log/user.log
chmod 644 /etc/motd
chmod 640 /etc/news/newsfeeds
chmod 640 /etc/news/inn.conf
chmod 640 /etc/news/expire.ctl
chmod 644 /etc/news/active
chmod 640 /etc/news/history
chmod 644 /etc/ntp.conf
chmod 644 /etc/ntp/step-tickers
chmod 600 /etc/ntp/keys
chmod 644 /etc/samba/smb.conf
chmod 700 /var/lib/samba/private
chmod 640 /etc/snmp/snmpd.conf
chmod 640 /etc/snmp/snmptrapd.conf
chmod 700 /etc/httpd/conf.d
chmod 700 /etc/pki/tls/private
chmod 755 /etc/pki/tls/certs
chmod 640 /var/log/httpd/access_log
chmod 640 /var/log/httpd/error_log
chmod 640 /etc/shadow
chmod 644 /etc/passwd
chmod 600 /etc/gshadow
chmod 600 /etc/ssh/sshd_config
chmod 700 /root
chmod 440 /etc/sudoers
chmod 640 /var/log/auth.log
chmod 644 /etc/fstab
chmod 644 /etc/group
chmod 600 /etc/securetty
chmod 755 /usr/bin/passwd
chmod 700 /var/spool/cron
chmod 700 /etc/cron.d
chmod 700 /etc/cron.daily
chmod 700 /etc/cron.hourly
chmod 700 /etc/cron.monthly
chmod 700 /etc/cron.weekly
chmod 700 /var/mail
chmod 644 /var/log/syslog
chmod 644 /var/log/wtmp
chmod 644 /etc/hosts
chmod 644 /etc/hostname
chmod 644 /etc/network/interfaces
chmod 644 /etc/resolv.conf
chmod 644 /etc/sysctl.conf
chmod 755 /etc/rc.local
chmod 644 /etc/hosts.allow
chmod 644 /etc/hosts.deny
chmod 644 /etc/aliases
chmod 644 /etc/mail/sendmail.cf
chmod 644 /etc/apache2/apache2.conf
chmod 644 /etc/mysql/my.cnf
chmod 4111 /usr/bin/sudo
chmod 600 /etc/ssh/ssh_host_*_key
chmod 644 /etc/ssh/ssh_host_*_key.pub
chmod 644 /etc/pam.d/*
chmod 644 /var/log/dmesg
chmod 644 /var/log/kern.log
chmod 700 /etc/sysconfig
chmod 644 /etc/yum.conf
chmod 644 /etc/apt/sources.list
chmod 755 /usr/local/bin
chmod 644 /var/log/lastlog
chmod 600 /etc/at.allow
chmod 600 /etc/at.deny
chmod 640 /var/log/secure
chmod 755 /etc/network/if-up.d/
chmod 755 /etc/network/if-down.d/
chmod 755 /etc/network/if-pre-up.d/
chmod 755 /etc/network/if-post-down.d/
chmod 755 /etc/sysconfig/network-scripts/ifdown-eth
chmod 755 /etc/sysconfig/network-scripts/ifup-eth
chmod 755 /etc/sysconfig/network-scripts/ifup-routes
chmod 755 /etc/sysconfig/network-scripts/ifdown-post
chmod 755 /etc/sysconfig/network-scripts/ifup-post
chmod 755 /etc/sysconfig/network-scripts/network-functions
chmod 755 /etc/sysconfig/network-scripts/network-functions-ipv6
chmod 640 /etc/cron.allow
chmod 640 /etc/at.allow
chmod 640 /etc/syslog-ng/syslog-ng.conf
chmod 600 /etc/anacrontab
chmod 600 /etc/rsyncd.conf
chmod 640 /etc/audit/auditd.conf
chmod 644 /etc/default/cron
chmod 640 /etc/logcheck/logcheck.conf
chmod 644 /etc/sysstat/sysstat
chmod 644 /etc/cron.deny
chmod 644 /etc/at.deny
chmod 644 /etc/issue
chmod 644 /etc/issue.net
chmod 640 /etc/aliases.db
chmod 640 /etc/postfix/main.cf
chmod 640 /etc/postfix/master.cf
chmod 600 /etc/ssl/private/ssl-cert-snakeoil.key
chmod 640 /etc/apache2/sites-available/000-default.conf
chmod 640 /etc/apache2/mods-available/dir.conf
chmod 640 /etc/php/7.4/apache2/php.ini
chmod 640 /etc/mysql/mariadb.conf.d/50-server.cnf
chmod 644 /etc/samba/smbusers
chmod 644 /etc/apt/apt.conf.d/01autoremove
chmod 644 /etc/apt/apt.conf.d/70debconf
chmod 644 /etc/apt/sources.list.d/official-package-repositories.list
chmod 644 /etc/network/interfaces.d/50-cloud-init.cfg
chmod 644 /etc/sysconfig/network-scripts/ifcfg-eth0
chmod 644 /etc/sysconfig/network-scripts/route-eth0
chmod 644 /etc/sysconfig/network-scripts/ifcfg-lo
chmod 644 /etc/pki/ca-trust/extracted/openssl/ca-bundle.trust.crt
chmod 644 /etc/pki/tls/certs/ca-bundle.crt
chmod 644 /etc/pki/tls/certs/ca-bundle.trust.crt
chmod 644 /etc/pki/tls/cert.pem
chmod 644 /etc/ssh/ssh_known_hosts
chmod 644 /etc/ssh/ssh_config
chmod 644 /etc/dhcp/dhclient.conf
chmod 644 /etc/default/ufw
chmod 644 /etc/ufw/ufw.conf
chmod 644 /etc/ufw/before.rules
chmod 755 /etc/sysconfig/network-scripts/
chown root:root /etc/cron.allow
chown root:root /etc/at.allow
chown root:root /etc/syslog-ng/syslog-ng.conf
chown root:root /etc/anacrontab
chown root:root /etc/rsyncd.conf
chown root:root /etc/audit/auditd.conf
chown root:root /etc/default/cron
chown root:root /etc/logcheck/logcheck.conf
chown root:root /etc/sysstat/sysstat
chown root:root /etc/cron.deny
chown root:root /etc/at.deny
chown root:root /etc/issue
chown root:root /etc/issue.net
chown root:root /etc/aliases.db
chown root:root /etc/postfix/main.cf
chown root:root /etc/postfix/master.cf
chown root:root /etc/ssl/private/ssl-cert-snakeoil.key
chown root:root /etc/apache2/sites-available/000-default.conf
chown root:root /etc/apache2/mods-available/dir.conf
chown root:root /etc/php/7.4/apache2/php.ini
chown root:root /etc/mysql/mariadb.conf.d/50-server.cnf
chown root:root /etc/samba/smbusers
chown root:root /etc/apt/apt.conf.d/01autoremove
chown root:root /etc/apt/apt.conf.d/70debconf
chown root:root /etc/apt/sources.list.d/official-package-repositories.list
chown root:root /etc/network/interfaces.d/50-cloud-init.cfg
chown root:root /etc/sysconfig/network-scripts/ifcfg-eth0
chown root:root /etc/sysconfig/network-scripts/route-eth0
chown root:root /etc/sysconfig/network-scripts/ifcfg-lo
chown root:root /etc/sysconfig/network-scripts/ifdown-eth
chown root:root /etc/sysconfig/network-scripts/ifup-eth
chown root:root /etc/sysconfig/network-scripts/ifup-routes
chown root:root /etc/sysconfig/network-scripts/ifdown-post
chown root:root /etc/sysconfig/network-scripts/ifup-post
chown root:root /etc/sysconfig/network-scripts/network-functions
chown root:root /etc/sysconfig/network-scripts/network-functions-ipv6
chown root:root /etc/pki/ca-trust/extracted/openssl/ca-bundle.trust.crt
chown root:root /etc/pki/tls/certs/ca-bundle.crt
chown root:root /etc/pki/tls/certs/ca-bundle.trust.crt
chown root:root /etc/pki/tls/cert.pem
chown root:root /etc/ssh/ssh_known_hosts
chown root:root /etc/ssh/ssh_config
chown root:root /etc/dhcp/dhclient.conf
chown root:root /etc/default/ufw
chown root:root /etc/ufw/ufw.conf
chown root:root /etc/ufw/before.rules
chmod 600 /etc/ssh/ssh_host_dsa_key
chmod 644 /etc/ssh/ssh_host_dsa_key.pub
chmod 600 /etc/cron.deny
chmod 600 /etc/at.deny
chmod 600 /etc/mail/statistics
chmod 640 /etc/mail/mailertable
chmod 640 /etc/mail/access
chmod 640 /etc/mail/virtusertable
chmod 640 /etc/mail/domaintable
chmod 640 /etc/mail/genericstable
chmod 700 /var/mail
chmod 640 /var/log/maillog
chmod 640 /var/log/messages
chmod 600 /var/log/cron
chmod 600 /var/log/secure
chmod 640 /var/log/boot.log
chmod 640 /etc/audit/audit.rules
chmod 640 /etc/audit/auditd.conf
chmod 644 /etc/default/useradd
chmod 600 /etc/security/opasswd
chmod 644 /etc/exports
chmod 644 /etc/auto.master
chmod 644 /etc/auto.misc
chmod 640 /var/log/mail.err
chmod 640 /var/log/mail.info
chmod 640 /var/log/mail.warn
chmod 640 /var/log/daemon.log
chmod 640 /var/log/debug
chmod 640 /var/log/user.log
chmod 640 /etc/news/newsfeeds
chmod 640 /etc/news/inn.conf
chmod 640 /etc/news/expire.ctl
chmod 644 /etc/news/active
chmod 640 /etc/news/history
chmod 644 /etc/ntp/step-tickers
chmod 600 /etc/ntp/keys
chmod 644 /etc/samba/smb.conf
chmod 700 /var/lib/samba/private
chmod 640 /etc/snmp/snmpd.conf
chmod 640 /etc/snmp/snmptrapd.conf
chmod 700 /etc/httpd/conf.d
chmod 700 /etc/pki/tls/private
chmod 640 /var/log/httpd/access_log
chmod 640 /var/log/httpd/error_log
chmod 440 /etc/sudoers.d
chmod 644 /etc/logrotate.conf
chmod 644 /etc/sysconfig/network-scripts/ifcfg-eth0
chmod 644 /etc/sysconfig/network-scripts/route-eth0
chmod 644 /etc/sysconfig/network-scripts/ifcfg-lo
chmod 644 /etc/pki/ca-trust/extracted/openssl/ca-bundle.trust.crt
chmod 750 /usr/bin/gcc
chmod 750 /usr/bin/g++
chmod 750 /usr/bin/make
chmod 600 /etc/passwd-
chmod 600 /etc/shadow
chmod 600 /etc/gshadow

mount -o remount,rw /


echo "Security settings applied."
echo "Permissions have been updated."

exit 0