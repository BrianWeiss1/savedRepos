#!/bin/bash

# Check if the script is run as root
if [ "$(id -u)" != "0" ]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

PWDQUALITY_CONF="/etc/security/faillock.conf"

sudo cp $PWDQUALITY_CONF "${PWDQUALITY_CONF}.backup"


# Update pwdquality.conf
cat > "$PWDQUALITY_CONF" << EOF
difok = 1
minlen = 14
dcredit = 3
ucredit = 2
lcredit = 2
ocredit = 2
minclass = 3
maxrepeat = 3
maxclassrepeat = 4
gecoscheck = 1
dictcheck = 1
usercheck = 1
usersubstr = 4
enforcing = 1
retry = 3
enforce_for_root
local_users_only
EOF

# Set permissions
chmod 600 "$PWDQUALITY_CONF"

# Restart the necessary service to apply changes
# Replace 'service_name' with the actual name of the service that needs to be restarted
systemctl restart service_name

# Configure faillock
# Add your faillock configuration commands here
# For example, you can configure faillock in /etc/security/faillock.conf or through PAM

echo "pwdquality and faillock configuration updated and services restarted."
