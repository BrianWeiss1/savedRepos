#!/bin/bash

# Check if the script is run as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root"
    exit
fi

COMMON_AUTH="/etc/pam.d/common-auth"

# Backup the current common-auth file
sudo cp $COMMON_AUTH "${COMMON_AUTH}.backup"

# Write the contents to pam.d/common-auth
cat << 'EOF' > /etc/pam.d/common-auth
# /etc/pam.d/common-auth - authentication settings common to all services

auth    required    pam_env.so
auth    required    pam_faillock.so preauth silent audit deny=5 unlock_time=900
auth    [success=1 default=ignore]  pam_unix.so nullok_secure
auth    requisite   pam_deny.so
auth    required    pam_permit.so
auth required pam_tally2.so deny=5 onerr=fail unlock_time=1800
EOF

# Change the file permissions
chmod 640 /etc/pam.d/common-auth

echo "pam.d/common-auth has been updated."

