#!/bin/bash

# Check if the script is run as root
if [ "$EUID" -ne 0 ]
  then echo "Please run as root"
  exit
fi

PWDQUALITY_CONF="/etc/pam.d/common-password"

sudo cp $PWDQUALITY_CONF "${PWDQUALITY_CONF}.backup"


# Write the contents to pam.d/common-password
cat << 'EOF' > /etc/pam.d/common-password
#
# /etc/pam.d/common-password - password-related modules common to all services
#
# This file is included from other service-specific PAM config files,
# and should contain a list of modules that define the services to be
# used to change user passwords.  The default is pam_unix.

# Explanation of pam_unix options:
# The "yescrypt" option enables
#hashed passwords using the yescrypt algorithm, introduced in Debian
#11.  Without this option, the default is Unix crypt.  Prior releases
#used the option "sha512"; if a shadow password hash will be shared
#between Debian 11 and older releases replace "yescrypt" with "sha512"
#for compatibility .  The "obscure" option replaces the old
#`OBSCURE_CHECKS_ENAB' option in login.defs.  See the pam_unix manpage
#for other options.

# As of pam 1.0.1-6, this file is managed by pam-auth-update by default.
# To take advantage of this, it is recommended that you configure any
# local modules either before or after the default block, and use
# pam-auth-update to manage selection of other modules.  See
# pam-auth-update(8) for details.

account [success=1 new_authtok_reqd=done default=ignore]        pam_unix.so
account requisite                       pam_deny.so
account required                        pam_permit.so
account sufficient                      pam_localuser.so
account [default=bad success=ok user_unknown=ignore]    pam_sss.so

# here are the per-package modules (the "Primary" block)
password    requisite            pam_pwquality.so retry=3 minlen=8 difok=3
password    [success=2 default=ignore]    pam_unix.so remember=5 obscure ucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1
use_authtok try_first_pass yescrypt 
password    sufficient            pam_sss.so use_authtok
# here's the fallback if no module succeeds
password    requisite            pam_deny.so 
# prime the stack with a positive return value if there isn't one already;
# this avoids us returning an error just because nothing sets a success code
# since the modules above will each just jump around
password    required            pam_permit.so
# and here are more per-package modules (the "Additional" block)
password    optional    pam_gnome_keyring.so
# end of pam-auth-update config
EOF

# Change the file permissions
chmod 640 /etc/pam.d/common-password

sudo authselect apply-changes
sudo systemctl restart sshd
# sudo systemctl restart systemd-logind


echo "pam.d/common-password has been updated and the service restarted."
