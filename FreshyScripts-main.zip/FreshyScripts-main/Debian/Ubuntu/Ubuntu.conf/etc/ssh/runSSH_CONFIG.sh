#!/bin/bash

# Check if the script is run as root
if [ "$(id -u)" != "0" ]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

# Backup existing ssh_config file
cp /etc/ssh/ssh_config /etc/ssh/ssh_config.backup

# Write new ssh_config
cat > /etc/ssh/ssh_config <<EOL
Include /etc/ssh/ssh_config.d/*.conf

Host *
    ForwardAgent no
    ForwardX11 no
    PasswordAuthentication no
    HostbasedAuthentication no
    GSSAPIAuthentication yes
    GSSAPIDelegateCredentials no
    GSSAPIKeyExchange no
    GSSAPITrustDNS no
    BatchMode no
    CheckHostIP yes
    AddressFamily any
    ConnectTimeout 20
    StrictHostKeyChecking yes
    IdentityFile ~/.ssh/id_rsa
    IdentityFile ~/.ssh/id_dsa
    IdentityFile ~/.ssh/id_ecdsa
    IdentityFile ~/.ssh/id_ed25519
    Port 22
    Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr
    MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,umac-128-etm@openssh.com
    EscapeChar ~
    Tunnel no
    TunnelDevice any:any
    PermitLocalCommand no
    VisualHostKey no
    RekeyLimit 1G 1h
    ProxyCommand ssh -q -W %h:%p gateway.example.com
    UserKnownHostsFile ~/.ssh/known_hosts.d/%k
    SendEnv LANG LC_*
    HashKnownHosts yes
    KexAlgorithms curve25519-sha256,curve25519-sha256@libssh.org,diffie-hellman-group-exchange-sha256
    HostKeyAlgorithms ssh-ed25519,ssh-rsa
    Compression no
    PreferredAuthentications publickey,password
    ServerAliveInterval 60
    ServerAliveCountMax 3
EOL

# Change file permissions
chmod 644 /etc/ssh/ssh_config

# Restart SSH service to apply changes
systemctl restart sshd

echo "SSH configuration updated and service restarted."
