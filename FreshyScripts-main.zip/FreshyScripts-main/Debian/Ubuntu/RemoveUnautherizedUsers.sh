#!/bin/bash
# Requirements:
    # 1. users.txt file setup with user accounts inputted
    # 2. in root mode (sudo -i)

generate_random_password() {
  upper_chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  lower_chars='abcdefghijklmnopqrstuvwxyz'
  num_chars='0123456789'
  special_chars='!@#$%^&*()_-+=<>?[]{}'
  all_chars="$upper_chars$lower_chars$num_chars$special_chars"
  char_set_length=${#all_chars}
  password=""
  for ((i = 0; i < 20; i++)); do
    index=$((RANDOM % char_set_length))
    password="${password}${all_chars:index:1}"
  done
  echo "$password"
}


readFileAdmins() {
    local file="$1"
    local collect_lines=0
    local output=()
    while IFS= read -r line; do
        if [[ $line == *"Authorized Administrators:"* ]]; then
            collect_lines=1
            continue
        elif [[ $line == *"Authorized Users:"* ]]; then
            break
        fi
        if [ "$collect_lines" -eq 1 ]; then
            username="$line"
            output+=("$username $password")
        fi
    done < "$file"

    echo "${output[@]}"
}


function readFile {
    local file="$1"
    local authorized=false
    local users=()

    while IFS= read -r line; do
        if [ "$authorized" = true ]; then
            users+=("$line")
        fi

        if [ "$line" = "Authorized Users:" ]; then
            authorized=true
        fi
    done < "$file"

    echo "${users[@]}"
}

function getUsers {
    usernames=$(getent passwd | cut -d: -f1)
    readarray -t usernames_array <<< "$usernames"
    echo "${usernames_array[@]}"
}
function getLocalAdmins {
    usernames=$(getent group sudo | cut -d: -f4 | tr ',' '\n')
    readarray -t usernames_array <<< "$usernames"
    echo "${usernames_array[@]}"
}
function getLocalUsers {
    usersNotToRemove=("_rpc" "statd" "root" "daemon" "bin" "sys" "sync" "games" "man" "lp" "mail" "news" "uucp" "proxy" "www-data" "backup" "list" "irc" "gnats" "nobody" "systemd-network" "systemd-resolve" "messagebus" "systemd-timesync" "syslog" "_apt" "tss" "uuidd" "systemd-oom" "tcpdump" "avahi-autoipd" "usbmux" "dnsmasq" "kernoops" "avahi" "cups-pk-helper" "rtkit" "whoopsie" "sssd" "speech-dispatcher" "fwupd-refresh" "nm-openvpn" "saned" "colord" "geoclue" "pulse" "gnome-initial-setup" "hplip" "gdm" "sshd" "ftp" "postfix")
    UsersTotal=($(getUsers))

    Users=()
    for name in "${UsersTotal[@]}"; do
        if [[ ! " ${usersNotToRemove[*]} " =~ " $name " ]]; then
            Users+=("$name")
        fi
    done
    echo "${Users[@]}"
}

LocalAdmins=$(getLocalAdmins)
authorizedUsers=($(readFile "users.txt"))
echo "${authorizedUsers[@]}"
authorizedAdmins=($(readFileAdmins "users.txt"))
renewedArray=()
mainUser=""
for i in "${!authorizedAdmins[@]}"; do
    if [ "${authorizedAdmins[i]}" = "(you)" ]; then
        mainUser="${authorizedAdmins[i-1]}"
        renewedArray=("${authorizedAdmins[@]:0:i}" "${authorizedAdmins[@]:i+1}")
    fi
done

declare -A authorizedAdminsDic
for i in "${!renewedArray[@]}"; do
    if [[ "${renewedArray[i]}" =~ "password:" ]]; then
        authorizedAdminsDic["${renewedArray[i-1]}"]="${renewedArray[i+1]}"
    fi
done

for admin in "${!authorizedAdminsDic[@]}"; do
  echo "$admin: ${authorizedAdminsDic[$admin]}"
done
echo ""

mainPassword=${authorizedAdminsDic["$mainUser"]}

echo "Account:  $mainUser"
echo "Password: $mainPassword"
echo ""
for possibeAdmin in ${LocalAdmins[@]}; do
    if [[ ! ${!authorizedAdminsDic[@]} =~ "$possibeAdmin" ]]; then
        echo "Need to remove $possibeAdmin [admin] --> [user]"
        read response
        if [[ "$response" = 'y' ]]; then
            sudo usermod -G users $possibeAdmin
        fi
    fi
done

for admin in "${!authorizedAdminsDic[@]}"; do
    if [[ ! " ${LocalAdmins[@]} " =~ " ${admin} " ]]; then
        echo "Need to add $admin [user] --> [admin] OR [] --> [admin]"
        if id "$admin" &>/dev/null; then
            echo "User $admin exists, granting sudo privileges (y/n)"
            read response
            if [[ "$response" = 'y' ]]; then
                sudo usermod -aG sudo "$admin"
            fi
        else
            echo "User $admin does not exist, creating and granting sudo privileges"
            read response            
            if [[ "$response" = 'y' ]]; then
                password=$(generate_random_password)
                sudo adduser "$admin"
                echo "$user:$password" | sudo chpasswd
                sudo usermod -aG sudo "$admin"
            fi
        fi
    fi
done
LocalUsers=($(getLocalUsers))
for user in "${authorizedUsers[@]}"; do # finds those not on the computer
    if [[ ! "${LocalUsers[@]}" =~ $user ]]; then 
        echo "User $user is not on this computer (y/n)"
        read response
        if [[ "$response" = 'y' ]]; then
            password=$(generate_random_password)
            sudo useradd -m $user
            echo "$user:$password" | sudo chpasswd
        fi
    fi
done

LocalUsers=($(getLocalUsers))
echo "${!authorizedAdminsDic[@]}"

for possibleUser in "${LocalUsers[@]}"; do
    if [[ ! "${authorizedUsers[@]}" =~ $possibleUser ]]; then
        if [[ ! ${!authorizedAdminsDic[@]} =~ "$possibleUser" ]]; then
            echo "$possibleUser User needs to be removed (y/n)"
            read response
            if [[ "$response" = 'y' ]]; then
                sudo userdel $possibleUser
            fi
        fi
    fi
done
# everything is done here

# sudo -i
# echo "$mainPassword"
# password reset

echo "Do you want to reset all the passwords of the users? (not admins) (y/n)"
read response

if [ "$response" = 'y' ]; then
    declare -A user_password_dict  # Declare an associative array
    for user in "${authorizedUsers[@]}"; do
        new_password=$(generate_random_password)
        sudo echo -e "$user:$new_password" | chpasswd
        if [ $? -eq 0 ]; then
            user_password_dict["$user"]=$new_password  # Store username and password in the dictionary
        else
            echo "Failed to change password for $user"
        fi
    done
    for user in "${!user_password_dict[@]}"; do
        echo "$user: ${user_password_dict[$user]}"
    done
fi

echo "Do you want to reset SOME the passwords of the admins? (y/n) (It will prompt you on a per-by-per-basis)"
read response
if [ "$response" = 'y' ]; then
    declare -A admin_password_dict  # Declare an associative array
    for admin in "${!authorizedAdminsDic[@]}"; do
        while [ true ]; do
            echo "Reset $admin password? (y/n)" 
            read response
            if [ "$response" = 'y' ]; then
                new_password=$(generate_random_password) 
                sudo echo "$admin:$new_password" | chpasswd
                admin_password_dict["$admin"]=$new_password  # Store username and password in the dictionary
                break
            elif [ "$response" = 'n' ]; then
                break
            fi
        done
    done

    for admin in "${!admin_password_dict[@]}"; do
        echo "$admin: ${admin_password_dict[$admin]}"
    done
fi