#!/bin/bash
users=($(ls -l /home | grep '^d' | awk '{print $9}'))
for user in "${users[@]}"; do
    find /home/$user/{Desktop,Documents,Downloads,Templates,Videos,Music,Pictures,Public} -type f
done
