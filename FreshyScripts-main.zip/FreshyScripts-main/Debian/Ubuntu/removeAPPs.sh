apt remove ophcrack -y
apt purge ophcrack -y

apt remove hydra -y
apt purge hydra -y

apt remove aircrack-ng -y
apt purge aircrack-ng -y

apt remove nmap -y
apt purge nmap -y

apt remove metasploit -y
apt purge metasploit -y

apt remove metasploit-framework -y
apt purge metasploit-framework -y

apt remove john -y
apt purge john -y

apt remove johnny -y
apt purge johnny -y

apt remove armitage -y
apt purge armitage -y

apt remove wireshark -y
apt purge wireshark -y

apt remove wifite -y
apt purge wifite -y

apt remove burpsuite -y
apt purge burpsuite -y

apt remove nikto -y
apt purge nikto -y

apt remove sqlmap -y
apt purge sqlmap -y

apt remove ettercap -y
apt purge ettercap -y

apt remove kismet -y
apt purge kismet -y

apt remove zenmap -y
apt purge zenmap -y

apt remove tcpdump -y
apt purge tcpdump -y

apt remove hashcat -y
apt purge hashcat -y

apt remove beef-xss -y
apt purge beef-xss -y

apt remove reaver -y
apt purge reaver -y

apt remove set -y
apt purge set -y

apt remove zaproxy -y
apt purge zaproxy -y

apt remove wpscan -y
apt purge wpscan -y

apt remove wifiphisher -y
apt purge wifiphisher -y

apt remove wifite -y
apt purge wifite -y

apt remove wifite2 -y
apt purge wifite2 -y

apt remove wifite-ng -y
apt purge wifite-ng -y

apt remove wifite2-ng -y
apt purge wifite2-ng -y


apt autoremove


sudo service apache2 stop
sudo service mysql stop
sudo service telnet stop
sudo service postgresql stop
sudo service snmp stop
sudo service icmp stop
sudo service sendmail stop
sudo service dovecot stop
sudo service dhcp stop            # DHCP service, can be used for network snooping or unauthorized access.
sudo service smb stop             # SMB service for server message block, known for vulnerabilities.
sudo service ypbind stop          # NIS/YP service, can expose user and password information.
sudo service ypserv stop          # NIS/YP server, similar risks to ypbind.
sudo service ypbind stop          # NIS/YP binding service, risk of exposing network information.
sudo service rpcbind stop         # RPC service for networked systems, can be exploited for unauthorized access.
sudo service cups stop            # CUPS service for printing, can be a vector for local network attacks.
sudo service rsh stop             # Remote Shell service, considered insecure due to lack of encryption.
sudo service rexec stop           # Rexec service for executing commands, known for security weaknesses.
sudo service rlogin stop          # Rlogin service for remote login, similar vulnerabilities to telnet.
sudo service openvpn stop         # OpenVPN service, if misconfigured can expose network vulnerabilities.
sudo service xinetd stop          # Extended Internet daemon, manages several network services which could be vulnerable.
sudo service squid stop           # Squid proxy server, can be misused if not properly configured.
sudo service tftp stop            # Trivial File Transfer Protocol, known for lack of security features.
sudo service ntp stop             # Network Time Protocol, can be exploited for network attacks.
sudo service samba stop           # Samba service for file sharing, can be vulnerable if misconfigured.
sudo service nfs stop             # Network File System service, can expose files if not properly secured.
sudo service talk stop            # Talk service for sending messages, can be exploited for unauthorized access.
sudo service ntalk stop           # Network talk service, similar vulnerabilities to talk.
sudo service windbind stop        # Windbind service, can be exploited for unauthorized access.
sudo service ms-wbt-server stop   # Microsoft Windows Remote Desktop, can be exploited for unauthorized access.

#MAYBE:
sudo service ssh stop             # SSH service for secure remote access, can be a vector for brute force attacks.
sudo service ftp stop             # FTP service for file transfer, known for lack of encryption in standard mode.
sudo service dns stop             # DNS service, vulnerabilities here can affect domain name resolution.
sudo service vsftpd stop          # Very Secure FTP Daemon, can be a vector for attacks if misconfigured.
sudo service snmpd stop          

sudo systemct1 disable apache2 
sudo systemct1 disable mysql 
sudo systemct1 disable telnet 
sudo systemct1 disable postgresql 
sudo systemct1 disable snmp 
sudo systemct1 disable icmp 
sudo systemct1 disable sendmail 
sudo systemct1 disable dovecot 
sudo systemct1 disable dhcp             # DHCP service, can be used for network snooping or unauthorized access.
sudo systemct1 disable smb              # SMB service for server message block, known for vulnerabilities.
sudo systemct1 disable ypbind           # NIS/YP service, can expose user and password information.
sudo systemct1 disable ypserv           # NIS/YP server, similar risks to ypbind.
sudo systemct1 disable ypbind           # NIS/YP binding service, risk of exposing network information.
sudo systemct1 disable rpcbind          # RPC service for networked systems, can be exploited for unauthorized access.
sudo systemct1 disable cups             # CUPS service for printing, can be a vector for local network attacks.
sudo systemct1 disable rsh              # Remote Shell service, considered insecure due to lack of encryption.
sudo systemct1 disable rexec            # Rexec service for executing commands, known for security weaknesses.
sudo systemct1 disable rlogin           # Rlogin service for remote login, similar vulnerabilities to telnet.
sudo systemct1 disable openvpn          # OpenVPN service, if misconfigured can expose network vulnerabilities.
sudo systemct1 disable xinetd           # Extended Internet daemon, manages several network services which could be vulnerable.
sudo systemct1 disable squid            # Squid proxy server, can be misused if not properly configured.
sudo systemct1 disable tftp             # Trivial File Transfer Protocol, known for lack of security features.
sudo systemct1 disable ntp              # Network Time Protocol, can be exploited for network attacks.
sudo systemct1 disable samba            # Samba service for file sharing, can be vulnerable if misconfigured.
sudo systemct1 disable nfs              # Network File System service, can expose files if not properly secured.
sudo systemct1 disable talk             # Talk service for sending messages, can be exploited for unauthorized access.
sudo systemct1 disable ntalk            # Network talk service, similar vulnerabilities to talk.
sudo systemct1 disable windbind         # Windbind service, can be exploited for unauthorized access.
sudo systemct1 disable ms-wbt-server    # Microsoft Windows Remote Desktop, can be exploited for unauthorized access.

#MAYBE:
sudo systemct1 disable ssh              # SSH service for secure remote access, can be a vector for brute force attacks.
sudo systemct1 disable ftp              # FTP service for file transfer, known for lack of encryption in standard mode.
sudo systemct1 disable dns              # DNS service, vulnerabilities here can affect domain name resolution.
sudo systemct1 disable vsftpd           # Very Secure FTP Daemon, can be a vector for attacks if misconfigured.
sudo systemctl disable snmpd
