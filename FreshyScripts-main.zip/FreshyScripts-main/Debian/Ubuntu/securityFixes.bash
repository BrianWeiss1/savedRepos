#!/bin/bash

sudo apt update
sudo apt upgrade
sudo apt dist-upgrade

sudo apt install ufw
sudo ufw enable

# Group and users to manage
echo "Do you want to create a userGroup? (y/n)"
read inputtedValue

if [ "$inputtedValue" = 'y' ]; then
    group_name="dragonfire"
    users_to_add=("emunson" "gareth" "jeff" "mwheeler" "dhenderson" "lsinclair" "esinclair")

    # Create a group and add users
    sudo groupadd $group_name
    for user in "${users_to_add[@]}"; do
        sudo usermod -a -G $group_name $user
    done
fi

sudo chmod 640 /etc/shadow
sudo mount -o remount,rw /

set_uac() {
    echo "Setting UAC to prompt Admin Approval Mode..."
    sudo sed -i 's/^\(PromptOnSecureDesktop=\).*/\1prompt/' /etc/sudoers
}

set_uac

# Disable Remote Assistance
gsettings set org.gnome.desktop.remote-desktop enabled false

# Disable Remote Desktop
gsettings set org.gnome.Vino require-encryption false
gsettings set org.gnome.Vino prompt-enabled false
gsettings set org.gnome.Vino authentication-methods "['none']"

# Stop and disable services
sudo systemctl stop simptcp
sudo systemctl disable simptcp
sudo systemctl start rsyslog

#smtp disabled
/etc/init.d/postfix stop
/etc/init.d/sendmail stop
update-rc.d [ postfix ] disable
update-rc.d [ sendmail ] disable

sudo apt install clamav
gufw
echo "lisioning services"
ss -tuln
echo "check for open ports"
netstat -tuln


sudo apt list --upgradable
sudo apt install net-tools

