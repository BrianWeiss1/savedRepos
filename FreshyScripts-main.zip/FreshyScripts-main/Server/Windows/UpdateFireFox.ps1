if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Host "Please run PowerShell as an Administrator."
    break
}

# Update/Install firefix, or update/install chrome
$continue2 = $true

while ($continue2) {
    $chromeOrFire = Read-Host "Would you like to install/update chrome or firefox? (chrome/firefox)"
    if ($chromeOrFire -eq "chrome" -or $chromeOrFire -eq "firefox") {
        $continue2 = $false
    }
}
$userInput = Read-Host "Are you sure? (y/n)"
if ($userInput -eq 'y') {
    if ($chromeOrFire -eq 'firefox') {
        $downloadURL = "https://download.mozilla.org/?product=firefox-latest&os=win64&lang=en-US"
        $downloadPath = "$env:USERPROFILE\Downloads\FirefoxInstaller.exe"
        Invoke-WebRequest -Uri $downloadURL -OutFile $downloadPath
        Get-Process -Name "firefox" | ForEach-Object { $_.Kill() }
        Start-Process -FilePath "cmd.exe" -ArgumentList "/C $downloadPath /S" -Wait
        $firefox = Get-WmiObject -Query "SELECT * FROM Win32_Product WHERE Name LIKE '%Mozilla Firefox%'" | Select-Object -First 1
        if ($firefox) {
            $newVersion = $firefox.Version
            Write-Output "Firefox has been updated to version $newVersion."
        } else {
            Write-Output "Firefox is not installed on this computer."
        }
    }
    if ($chromeOrFire -eq 'chrome') {
        # Define the download URL for Google Chrome
        $downloadURL = "https://dl.google.com/chrome/install/latest/chrome_installer.exe"
        $downloadPath = "$env:USERPROFILE\Downloads\ChromeInstaller.exe"

        # Download Google Chrome installer
        Invoke-WebRequest -Uri $downloadURL -OutFile $downloadPath

        # Check if Chrome is running and terminate any processes
        Get-Process -Name "chrome" | ForEach-Object { $_.Kill() }

        # Install Google Chrome silently
        Start-Process -FilePath "cmd.exe" -ArgumentList "/C $downloadPath /silent /install" -Wait

        # Check if Google Chrome is installed
        $chrome = Get-WmiObject -Query "SELECT * FROM Win32_Product WHERE Name LIKE '%Google Chrome%'" | Select-Object -First 1

        if ($chrome) {
            $newVersion = $chrome.Version
            Write-Output "Google Chrome has been installed/updated to version $newVersion."
        } else {
            Write-Output "Google Chrome is not installed on this computer."
        }
    }
}