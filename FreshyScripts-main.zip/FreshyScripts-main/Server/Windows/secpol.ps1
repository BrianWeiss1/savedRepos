if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Host "Please run PowerShell as an Administrator."
    break
}

secedit /export /cfg c:\secpol.cfg
$pathToFile = "c:\secpol.cfg"
Start-Process -FilePath $pathToFile
Start-Sleep -Seconds 10
$userInput = Read-Host "Continue (y?)"

secedit /configure /db c:\windows\security\local.sdb /cfg $pathToFile /areas SECURITYPOLICY

# add LmCompatibilityLevel
$registryPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
$propertyName = "LmCompatibilityLevel"
$newValue = 5  # NTLMv2 only

# Check if the property already exists
if (Get-ItemProperty -Path $registryPath -Name $propertyName -ErrorAction SilentlyContinue) {
    # Modify the existing property
    Set-ItemProperty -Path $registryPath -Name $propertyName -Value $newValue
} else {
    # Add the property
    New-ItemProperty -Path $registryPath -Name $propertyName -Value $newValue -PropertyType "DWord"
}

Write-Host "LmCompatibilityLevel set to $newValue."
