if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Host "Please run PowerShell as an Administrator."
    break
}

function Generate-RandomPassword {
    $result = @()
    for ($i = 1; $i -le 20; $i++) {
        $randomNumber = Get-Random -Minimum 1 -Maximum 62
        if ($randomNumber -le 9) {
            $result += $randomNumber
        } else {
            # Convert the number to a letter using ASCII
            $letter = [char]([byte][char]"A" + ($randomNumber - 10))
            $result += $letter
        }
    }
    return -join $result
}

$password = "be!f0ng123$"
Set-LocalUser -Name "iroh" -Password (ConvertTo-SecureString -AsPlainText $password -Force)
