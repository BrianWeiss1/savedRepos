if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Host "Please run PowerShell as an Administrator."
    break 
}
# Start the Windows Event Log service
Start-Service -Name EventLog

# Set the Windows Event Log service to automatically start
Set-Service -Name EventLog -StartupType Automatic


# Disable Potentially Unnecessary Services
Set-Service -Name 'Fax' -StartupType Disabled
Set-Service -Name 'RemoteRegistry' -StartupType Disabled
Set-Service -Name 'WSearch' -StartupType Disabled
Set-Service -Name 'lmhosts' -StartupType Disabled
Set-Service -Name 'HomeGroupListener' -StartupType Disabled
Set-Service -Name 'HomeGroupProvider' -StartupType Disabled
Set-Service -Name 'wscsvc' -StartupType Disabled # Be cautious, related to Windows Security Center
Set-Service -Name 'SSDPSRV' -StartupType Disabled # SSDP Discovery
Set-Service -Name 'upnphost' -StartupType Disabled # UPnP Host Service
Set-Service -Name 'TapiSrv' -StartupType Disabled # Telephony service
Set-Service -Name 'TermService' -StartupType Disabled # Remote Desktop Services
Set-Service -Name 'SSDPTRAP' -StartupType Disabled # SSDP Discovery Traps
Set-Service -Name 'SessionEnv' -StartupType Disabled # Remote Desktop Configuration

# Disable Remote Services (Be cautious, as it may affect remote management)
# Set-Service -Name 'RemoteDesktopServices' -StartupType Disabled
# Set-Service -Name 'TermService' -StartupType Disabled # Remote Desktop Services

# # Disable Services Related to Data Sharing (Only if not required)
# Set-Service -Name 'Browser' -StartupType Disabled # Computer Browser
# Set-Service -Name 'LanmanServer' -StartupType Disabled # File and Printer Sharing
# Set-Service -Name 'LanmanWorkstation' -StartupType Disabled # Network Discovery

# Uninstall Potentially Dangerous Tools (If they are present)
$tools = @('Wireshark', 'Nmap', 'Metasploit', 'JohnTheRipper')
foreach ($tool in $tools) {
    $app = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -match $tool }
    if ($app) {
        $app.Uninstall()
    }
}

# Additional customizations can be added here based on your specific requirements.
Write-Host "Disabled serveral unsafe services"

Read-Host "Do you want to disable FTP service (Y/n)?"
if ($userInput -eq "Y") {
    $ftpService = Get-Service -Name 'FTPSVC' -ErrorAction SilentlyContinue
    if ($ftpService) {
        # Stop the FTP Service if it's running
        if ($ftpService.Status -eq 'Running') {
            Stop-Service -Name 'FTPSVC'
        }

        # Disable the FTP Service
        Set-Service -Name 'FTPSVC' -StartupType Disabled
    }
    Uninstall-WindowsFeature Web-Ftp-Server
    Write-Host "Disabled FTP service"
}

# Apply Changes
Restart-Computer
