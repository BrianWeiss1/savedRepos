if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Host "Please run PowerShell as an Administrator."
    break
}

powershell.exe -Command "Checkpoint-Computer -Description 'Pre-Hardening Restore Point' -RestorePointType 'MODIFY_SETTINGS'"
