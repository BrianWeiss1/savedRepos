if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Host "Please run PowerShell as an Administrator."
    break
}

$groupName="dragonfire"
$usersToAdd= @("emunson", "gareth", "jeff", "mwheeler", "dhenderson", "lsinclair", "esinclair")

New-LocalGroup -Name $groupName
foreach ($user in $usersToAdd) {
    Add-LocalGroupMember -Group $groupName -Member $user
}