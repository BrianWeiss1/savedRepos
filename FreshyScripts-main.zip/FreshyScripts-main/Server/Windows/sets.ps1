if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Host "Please run PowerShell as an Administrator."
    break
}

$userInput = Read-Host "Do you want to want to save (Y/n)?"
if ($userInput -contains "y") {
    powershell.exe -Command "Checkpoint-Computer -Description 'Pre-Hardening Restore Point' -RestorePointType 'MODIFY_SETTINGS'"
}

$userInput = Read-Host "continue? or skip (y/s/n)"
if ($userInput -contains "y") {
    Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections" -Value 1
    Set-ExecutionPolicy Restricted
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -name "LsaCfgFlags" -Value 1

    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name "SubscribedContent-310093Enabled" -Value 0
    New-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Safer\CodeIdentifiers' -Name "ExecutableTypes" -Value "exe;com"
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name "NoDriveTypeAutoRun" -Value 255

    powercfg /change monitor-timeout-ac 10

    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name "RestrictAnonymousSAM" -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanmanServer\Parameters' -Name "SMBDirectHosting" -Value 0

    Set-MpPreference -EnableControlledFolderAccess Enabled

    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -name "LsaCfgFlags" -Value 1

    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name "SubscribedContent-310093Enabled" -Value 0
    New-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Safer\CodeIdentifiers' -Name "ExecutableTypes" -Value "exe;com"
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name "NoDriveTypeAutoRun" -Value 255
    powercfg /change monitor-timeout-ac 10

    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name "RestrictAnonymousSAM" -Value 1

    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanmanServer\Parameters' -Name "SMBDirectHosting" -Value 0


    net accounts /minpwlen:10
    net accounts /lockoutthreshold:5
    net accounts /lockoutduration:30

    Get-LocalUser | Where-Object {$_.SID -like "S-1-5-*-500" -or $_.SID -like "S-1-5-*-501"} | Disable-LocalUser

    auditpol /set /subcategory:"*"
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\SecurityProviders\WDigest' -Name 'UseLogonCredential' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'LimitBlankPasswordUse' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'NoLMHash' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'RestrictAnonymous' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'RestrictAnonymousSAM' -Value 1


    fsutil behavior set EncryptPagingFile 1

    Disable-WindowsErrorReporting
    Set-PrivacySetting -Level High
    Set-NetFirewallProfile -Profile Domain,Public,Private -DefaultInboundAction Block
    Disable-WindowsOptionalFeature -Online -FeatureName MicrosoftWindowsPowerShellV2Root
    # wevtutil sl security /ca:O:BAG:SYD:(A;;0x1;;;SY)
    vssadmin Resize ShadowStorage /For=C: /On=C: /MaxSize=10GB
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Windows Search' -Name 'AllowCortana' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Remote Assistance' -Name 'fAllowToGetHelp' -Value 0
    Set-PSSessionConfiguration -Name Microsoft.PowerShell -ShowSecurityDescriptorUI

    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'DisableCAD' -Value 0
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'DisableRegistryTools' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows NT\MitigationOptions' -Name 'MitigationOptions_FontBocking' -Value 1000000000000
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'Isolation' -Value 'PMEM'
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'BingSearchEnabled' -Value 0
    Set-LocalUser -Name "UserAccount" -AccountNeverExpires $False -PasswordNeverExpires $False
    Set-SmbServerConfiguration -EnableGuestAccess $False
    Set-Item WSMan:\localhost\Shell\AllowRemoteShellAccess -Value $False
    Set-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\System' -Name 'DisableCMD' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'AUOptions' -Value 4
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\WcmSvc\wifinetworkmanager\config' -Name 'AutoConnectAllowedOEM' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'NoLMHash' -Value 1
    Set-NetConnectionProfile -InterfaceAlias "Ethernet0" -NetworkCategory Public
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN' -Name 'iexplore.exe' -Value 0
    cmdkey /list | ForEach-Object {if($_ -like "*Target:*"){cmdkey /delete:($_ -replace " ","" -replace "Target:","")}}
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'legalnoticecaption' -Value 'Your Legal Notice Here'
    net accounts /minpwlen:10 /minpwage:1 /maxpwage:30 /uniquepw:5 /domain
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'HideFastUserSwitching' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\System' -Name 'EnableSmartScreen' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\PreviewBuilds' -Name 'AllowBuildPreview' -Value 0
    Set-MpPreference -EnableNetworkProtection Enabled
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoControlPanel' -Value 1
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'DisableRegistryTools' -Value 1
    Set-NetFirewallRule -DisplayName "File and Printer Sharing (Echo Request - ICMPv4-In)" -Enabled False
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows NT\Rpc' -Name 'RestrictRemoteClients' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\NetCache' -Name 'DisableFileSync' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters' -Name 'MaxTokenSize' -Value 65535
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows NT\DNSClient' -Name 'EnableMulticast' -Value 0
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree' -Name 'SD' -Value 'D:P(A;;GA;;;BA)'
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows NT\Printers' -Name 'AddPrinterDrivers' -Value 1
    Set-NetFirewallProfile -All -LogFileName '%systemroot%\System32\LogFiles\Firewall\pfirewall.log' -LogAllowed $True -LogBlocked $True
    net accounts /maxpwage:90
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Biometrics' -Name 'Enabled' -Value 0
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DisableWindowsUpdateAccess' -Value 1
    verifier /standard /all
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\System' -Name 'DisableCMD' -Value 1
    Set-Service -Name RemoteRegistry -StartupType Disabled
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0' -Name 'RestrictSendingNTLMTraffic' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorUser' -Value 0
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'SaveZoneInformation' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1
    Set-AppLockerPolicy -XmlPolicy 'C:\Path\To\YourPolicy.xml'
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PreventExecutionOfNonExecuteDrivers' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\DeviceGuard' -Name 'EnableVirtualizationBasedSecurity' -Value 1
    # sc sdset w32time D:(A;;CCLCSWLOCRRC;;;AU)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(A;;CCLCSWLOCRRC;;;BA)S:(AU;FA;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;WD)
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options' -Name 'EnableUnsafeImageLoadProtection' -Value 1
    schtasks /Change /TN "\Microsoft\Windows\RAC\RacTask" /Disable
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'EnabledV9' -Value 1
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Script Host\Settings' -Name 'Enabled' -Value 0
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Windows' -Name 'HeapProtection' -Value 1
    Set-MpPreference -MAPSReporting Advanced
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\MobilityCenter' -Name 'NoMobilityCenter' -Value 1
    Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\StorageDevicePolicies' -Name 'WriteProtect' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'LmCompatibilityLevel' -Value 5
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Siuf\Rules' -Name 'NumberOfSIUFInPeriod' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy' -Name 'Enabled' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DisableWindowsUpdateAccess' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\System' -Name 'EnableCdp' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'RestrictAnonymous' -Value 1
    powercfg /hibernate off
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN' -Name 'iexplore.exe' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\DriverSearching' -Name 'SearchOrderConfig' -Value 0
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\PowerShell' -Name 'EnableScripts' -Value 0
    Set-MpPreference -MAPSBlockAtFirstSeen Enabled
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Windows Search' -Name 'PreventIndexingOutlook' -Value 1
    New-AppLockerPolicy -RuleType Path -User Everyone -Path 'C:\ApprovedApps\' -Deny
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\WMDRM' -Name 'DisableOnline' -Value 1
    Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\USBSTOR' -Name 'Start' -Value 4
    # Add-MpPreference -AttackSurfaceReductionRules_Ids <Rule ID> -AttackSurfaceReductionRules_Actions Enabled
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\WCN\Registrars' -Name 'EnableRegistrars' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0' -Name 'RestrictSendingNTLMTraffic' -Value 2
    New-SRPolicyRule -Path '%WINDIR%\System32\Notepad.exe' -Permission Allow
    Disable-WindowsOptionalFeature -Online -FeatureName 'RemoteDifferentialCompression'
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'LocalAccountTokenFilterPolicy' -Value 0
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\System' -Name 'BlockDomainPicturePassword' -Value 1
    Set-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\System' -Name 'DisableCMD' -Value 2
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'PasswordExpiryWarning' -Value 14
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\DeviceGuard' -Name 'LsaCfgFlags' -Value 1
    Set-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\System' -Name 'DisableCommandPrompt' -Value 1
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoFileSharingControl' -Value 1
    New-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3' -Name '1809' -Value 3
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\System' -Name 'ProfileSizeLimit' -Value 30000
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows Defender\Features' -Name 'TamperProtection' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Installer' -Name 'DisableMSI' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\WOW64FileSystemRedirection' -Name 'Enabled' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0' -Name 'NTLMMinClientSec' -Value 537395200
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\LocationAndSensors' -Name 'DisableLocation' -Value 1
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SilentInstalledAppsEnabled' -Value 0
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\SQMClient\Windows' -Name 'CEIPEnable' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard' -Name 'EnableVirtualizationBasedSecurity' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\DeviceInstall\Restrictions' -Name 'DenyUnspecified' -Value 1
    Set-ProcessMitigation -System -Enable DEP, SEHOP
    Set-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\CurrentVersion\PushNotifications' -Name 'NoToastApplicationNotification' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\System' -Name 'LetAppsAccessPersonalFiles' -Value 0
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows NT\Printers' -Name 'DisableHTTPPrinting' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'NoConnectedUser' -Value 3
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Network' -Name 'MinPwdLen' -Value 12
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanmanServer\Parameters' -Name 'DisableStrictNameChecking' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'RestrictAnonymous' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NetBT\Parameters' -Name 'EnableProxy' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'LmCompatibilityLevel' -Value 5
    Set-Service -Name wcncsvc -StartupType Disabled
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'TranslateNames' -Value 0

    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 1


    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanmanServer\Parameters' -Name 'DisableCompression' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanmanServer\Parameters' -Name 'RequireSecuritySignature' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'LockoutDuration' -Value 30
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoDriveTypeAutoRun' -Value 255

    auditpol /set /category:* /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\GameDVR' -Name 'AllowGameDVR' -Value 0
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'DontDisplayLogonHoursWarnings' -Value 1
    auditpol /set /subcategory:"Audit Policy Change" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'LocalAccountTokenFilterPolicy' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters' -Name 'NullSessionPipes' -Value ''
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\Tcpip6\Parameters' -Name 'DisabledComponents' -Value 255
    auditpol /set /subcategory:"Object Access" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'AllowRemoteRPC' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedExactPaths' -Name 'Machine' -Value ''
    Set-Service -Name 'messaging' -StartupType Disabled
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoAddPrinter' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'RestrictRemoteSAM' -Value 'O:BAG:BAD:(A;;RC;;;BA)'
    Set-Service -Name 'p2psvc' -StartupType Disabled
    auditpol /set /subcategory:"Filtering Platform Packet Drop" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorUser' -Value 0
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\MobilityCenter' -Name 'NoMobilityCenter' -Value 1
    auditpol /set /subcategory:"Application Group Management" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\SecureBoot\Rules' -Name 'Policy' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'RestrictAnonymousSAM' -Value 1
    Set-Service -Name 'WerSvc' -StartupType Disabled
    auditpol /set /subcategory:"Credential Validation" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'RestrictAnonymous' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Explorer' -Name 'NoUseStoreOpenWith' -Value 1
    auditpol /set /subcategory:* /success:enable /failure:enable
    Set-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\System' -Name 'DisableCMD' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters' -Name 'NullSessionShares' -Value ''
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\AppCompat' -Name 'DisableInventory' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'Scremoveoption' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LDAP' -Name 'LDAPClientIntegrity' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\CredentialsDelegation' -Name 'AllowSavedCredentialsWhenNTLMOnly' -Value 0
    auditpol /set /subcategory:"Authorization Policy Change" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters' -Name 'RequireSecuritySignature' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters' -Name 'RestrictNullSessAccess' -Value 1
    auditpol /set /subcategory:"Logon" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'FilterAdministratorToken' -Value 1
    auditpol /set /subcategory:"Filtering Platform Connection" /success:enable /failure:enable
    Set-Service -Name 'irmon' -StartupType Disabled
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Network' -Name 'OldPasswordHistory' -Value 24
    auditpol /set /subcategory:"Process Creation" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\PowerShell' -Name 'ExecutionPolicy' -Value 'Restricted'
    Set-MpPreference -DisableRealtimeMonitoring $False
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\MobilityCenter' -Name 'NoMobilityCenter' -Value 1
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'NoLMHash' -Value 1
    auditpol /set /subcategory:"System Integrity" /success:enable /failure:enable
    # sc.exe sdset localservice D:(A;;CCLCSWLOCRRC;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)(A;;CCLCSWLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ValidateAdminCodeSignatures' -Value 1
    # wevtutil sl security /ca:O:BAG:SYD:(A;;0x1;;;SY)
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0' -Name 'NTLMMinClientSec' -Value 537395200
    auditpol /set /subcategory:"User Account Management" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableVirtualization' -Value 1
    auditpol /set /subcategory:"Filtering Platform Policy Change" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\LLTD' -Name 'EnableLLTDIO' -Value 0
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'NoLMHash' -Value 1
    auditpol /set /subcategory:"Directory Service Access" /success:enable /failure:enable
    auditpol /set /category:* /success:enable /failure:enable /force
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Script Host\Settings' -Name 'Enabled' -Value 0
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 2
    auditpol /set /subcategory:"Security State Change" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'LmCompatibilityLevel' -Value 5
    auditpol /set /subcategory:"Logoff" /success:enable /failure:enable
    auditpol /set /subcategory:"Audit Policy Change" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'DisableDomainCreds' -Value 1
    auditpol /set /subcategory:"Security Group Management" /success:enable /failure:enable
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 5
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableSmartScreen' -Value 2
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'ShellSmartScreenLevel' -Value 'Block'
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint' -Name 'RestrictDriverInstallationToAdministrators' -Value 1
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableVirtualization' -Value 1
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers' -Name 'DisableAutoplay' -Value 1
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'DisableLockScreenAppNotifications' -Value 1
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'NoAutoUpdate' -Value 0      
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\WindowsStore' -Name 'RemoveWindowsStore' -Value 1
    Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' -Name 'UEFISecureBootEnabled' -Value 1
    Disable-WindowsOptionalFeature -Online -FeatureName 'TelnetClient'
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' -Name 'SecurityLayer' -Value 2

    # Define the registry path and key
    $registryPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection"
    $keyName = "ForceDefenderPassiveMode"

    # Check if the registry key exists
    if (Test-Path -Path $registryPath) {
        # Check the value of the key
        $keyValue = Get-ItemProperty -Path $registryPath -Name $keyName -ErrorAction SilentlyContinue

        if ($keyValue -and $keyValue.$keyName -eq 0) {
            Write-Host "Windows Defender is not in passive mode."
        } elseif ($keyValue) {
            Write-Host "Windows Defender is set to passive mode. Changing to active mode..."
            Set-ItemProperty -Path $registryPath -Name $keyName -Value 0
        }
    } else {
        Write-Host "Registry key for passive mode does not exist. Windows Defender should be active."
    }

    # Define the registry path and key
    $registryPath = "HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl"

    # Check if the path exists and create it if it doesn't
    if (-not (Test-Path $registryPath)) {
        New-Item -Path $registryPath -Force
    }

    # Set the registry key value
    Set-ItemProperty -Path $registryPath -Name "CrashDumpEnabled" -Value 0



    $rule = New-AppLockerRule -Action Deny -Condition Path -Path "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
    New-AppLockerPolicy -Rule $rule -XML -OutFile "AppLockerPolicy.xml"
    Set-AppLockerPolicy -XMLPolicy "AppLockerPolicy.xml"
}
elseif ($userInput -contains "s") {
    # Enable Firewall for all profiles (Domain, Private, Public)
    Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True

    # Block all inbound traffic by default
    Set-NetFirewallProfile -Profile Domain,Private,Public -DefaultInboundAction Block

    # Allow all outbound traffic by default
    Set-NetFirewallProfile -Profile Domain,Private,Public -DefaultOutboundAction Allow

    # Enable Logging
    Set-NetFirewallProfile -Profile Domain,Private,Public -LoggingAllowed True -LogFileName "%systemroot%\System32\LogFiles\Firewall\pfirewall.log"

    # Set Log Size
    Set-NetFirewallProfile -Profile Domain,Private,Public -LogMaxSizeKilobytes 16384

    # Enable Stealth Mode - Do not respond to unsolicited requests
    Set-NetFirewallProfile -Profile Domain,Private,Public -StealthMode Block

    # Disable Unicast Responses to Multicast and Broadcast messages
    Set-NetFirewallProfile -Profile Domain,Private,Public -DisableUnicastResponsesToMulticastBroadcast Enable

    # Prevent the firewall from merging rules from Group Policy Objects
    Set-NetFirewallProfile -Profile Domain,Private,Public -RulesNotInGroupPolicy Active

    # Block All Incoming Connections, including those in the list of allowed apps
    Set-NetFirewallProfile -Profile Public -BlockAllInboundTraffic True

    # Enable Firewall Notifications
    Set-NetFirewallProfile -Profile Domain,Private,Public -NotifyOnListen True

    New-NetFirewallRule -DisplayName "BlockInboundNetwork" -Direction Inbound -Action Block
    # Block ICMP (Ping)
    New-NetFirewallRule -DisplayName "Block_ICMP" -Direction Inbound -Protocol ICMPv4 -Action Block

    # Block Remote Desktop
    New-NetFirewallRule -DisplayName "Block_Remote_Desktop" -Direction Inbound -Protocol TCP -LocalPort 3389 -Action Block
    netsh advfirewall set publicprofile firewallpolicy blockinbound,allowoutbound

    # Allow SSH (Port 22)
    New-NetFirewallRule -DisplayName "Allow_SSH" -Direction Inbound -Protocol TCP -LocalPort 22 -Action Allow

    # Apply changes
    $userInput = Read-Host "Block TCP?"
    if ($userInput -contains "y") {
        New-NetFirewallRule -DisplayName "Block_TCP" -Direction Inbound -Protocol TCP -Action Block
        New-NetFirewallRule -DisplayName "Block_TCP_445" -Direction Inbound -Protocol TCP -LocalPort 445 -Action Block
    }



    Write-Host "Firewall settings applied."



    Read-Host "Press any key to continue..."

    sfc /scannow
    Get-WindowsFeature | Where-Object {$_.Installed -eq $True} 


    Read-Host "Press any key to continue..."

        # Disable Auto-Play for All Drives
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoDriveTypeAutoRun' -Value 255

    # Configure Windows Defender Antivirus PUA Protection
    Set-MpPreference -PUAProtection Enable

    # Enable Audit of Privilege Use
    auditpol /set /subcategory:"Privilege Use" /success:enable /failure:enable

    # Disable AutoRun for Network and CD-ROM Drives
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoDriveTypeAutoRun' -Value 4

    # Set Network Security: Require Security Signature for SMB Servers
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters' -Name 'RequireSecuritySignature' -Value 1

    # Enable Audit of Detailed Tracking
    auditpol /set /subcategory:"Detailed Tracking" /success:enable /failure:enable

    # Configure Password Must Meet Complexity Requirements
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Network' -Name 'PasswordComplexity' -Value 1

    # Set User Account Control: Detect Application Installations
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableInstallerDetection' -Value 1

    # Enable Audit of Policy Change
    auditpol /set /subcategory:"Policy Change" /success:enable /failure:enable

    # Set Network Access: Do Not Allow Storage of Credentials or .NET Passports for Network Authentication
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'DisableDomainCreds' -Value 1

    # Disable Automatic Learning in Windows Defender
    Set-MpPreference -DisablePrivacyMode $true

    # Enable Audit of Other Account Logon Events
    auditpol /set /subcategory:"Other Account Logon Events" /success:enable /failure:enable

    # Configure Windows Defender Cloud-Delivered Protection Level
    Set-MpPreference -CloudBlockLevel High

    # Set Network Security: Minimum Session Security for NTLM SSP Based Servers
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0' -Name 'NTLMMinServerSec' -Value 537395200

    # Enable Audit of System Events
    auditpol /set /subcategory:"System" /success:enable /failure:enable

    # Set Network Access: Allow Anonymous SID/Name Translation to Disabled
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'RestrictAnonymous' -Value 1

    # Restrict Software Installation to Admins Only
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Installer' -Name 'AlwaysInstallElevated' -Value 0

    # Disable SMBv2 and SMBv3 if not required
    Set-SmbServerConfiguration -EnableSMB2Protocol $false

    # Disable PowerShell Remoting
    Disable-PSRemoting -Force

    # Restrict Access to PowerShell 2.0 Engine
    Disable-WindowsOptionalFeature -Online -FeatureName MicrosoftWindowsPowerShellV2Root

    # Enable Firewall Rule to Block Inbound SMB Traffic
    New-NetFirewallRule -DisplayName "Block Inbound SMB 445" -Direction Inbound -Protocol TCP -LocalPort 445 -Action Block

    # Disable Windows Remote Management (WinRM)
    Set-Service -Name WinRM -StartupType Disabled

    # Disable Remote Desktop Protocol (RDP)
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -Value 1

    # Disable Guest Account
    Disable-LocalUser -Name "Guest"

    # Disable Built-in Administrator Account
    Disable-LocalUser -Name "Administrator"

    # Set UAC Policy to Prompt for Consent on the Secure Desktop
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 1

    # Disable Creation of Thumbs.db Files on Network Locations
    Set-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'DisableThumbsDBOnNetworkFolders' -Value 1

    # Disable Scheduled Tasks Known to be Used in Attacks
    Get-ScheduledTask | Where-Object {$_.TaskName -like "*BadTask*"} | Disable-ScheduledTask

    # Disable Remote Assistance
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Remote Assistance' -Name 'fAllowToGetHelp' -Value 0

    # Disable Remote Registry Service
    Set-Service -Name RemoteRegistry -StartupType Disabled

    # Block Outbound Traffic to Known Malicious IP Addresses
    # Replace '1.2.3.4' with the actual IP address
    New-NetFirewallRule -DisplayName "Block Malicious IP" -Direction Outbound -RemoteAddress 1.2.3.4 -Action Block

    # Disable Windows Tips and Tricks
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-310093Enabled' -Value 0

    # Set Maximum Password Age
    net accounts /maxpwage:60

    # Enable System Restore Configuration
    Enable-ComputerRestore -Drive "C:\"

    # Configure Audit of Successful File Deletion Events
    auditpol /set /subcategory:"File Deletion" /success:enable

    # Disable Sync Center
    Set-Service -Name 'CscService' -StartupType Disabled

    # Disable Microsoft Consumer Experience
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoUseStoreOpenWith' -Value 1

    # Disable Storage Sense
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\StorageSense' -Name 'AllowStorageSenseGlobal' -Value 0

    # Block Access to Command Prompt
    Set-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\System' -Name 'DisableCMD' -Value 1

    # Disable Windows Insider Service
    Set-Service -Name 'wisvc' -StartupType Disabled

    # Disable Data Execution Prevention (DEP) for Specific Applications
    # Replace 'C:\Path\To\App.exe' with the actual application path
    Set-ProcessMitigation -Name 'App.exe' -Disable DEP

    # Block Internet Explorer from Running
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Internet Explorer' -Name 'RestrictIE' -Value 1

    # Disable Cloud Content on Start Menu
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CloudStore\Store\Cache\DefaultAccount' -Name 'Data' -Value 0

    # Configure User Account Control: Run All Administrators in Admin Approval Mode
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1

    # Disable Open File - Security Warning on Downloads
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'SaveZoneInformation' -Value 1

    # Set Network Security: Add Server Exceptions for NTLM Authentication in Inbound Calls
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters' -Name 'AllowNTLMInbound' -Value 1

    # Disable Windows Hello Experience Ads
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\System' -Name 'NoWindowsHelloExperienceAdv' -Value 1

    # Enable Strong Encryption for Windows Network Sessions on Clients
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'RequireStrongKeyProtection' -Value 1

    # Disable Password Reveal Button on the Sign-in Screen
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\CredUI' -Name 'DisablePasswordReveal' -Value 1

    # Enable Audit of Security System Extension
    auditpol /set /subcategory:"Security System Extension" /success:enable /failure:enable

    # Restrict Application Execution with Software Restriction Policies
    New-Object -ComObject HNetCfg.FwPolicy2

    # Disable Launching of Windows Installer via Group Policy
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Installer' -Name 'DisableMSI' -Value 1

    # Set Network Security: LAN Manager Server Level to Send NTLMv2 Response Only
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'LmCompatibilityLevel' -Value 5

    # Disable Saving Passwords in Remote Desktop Client
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Terminal Server Client' -Name 'DisablePasswordSaving' -Value 1

    # Enable Audit of System Integrity Detail
    auditpol /set /subcategory:"System Integrity Detail" /success:enable /failure:enable

    # Set User Account Control: Switch to Secure Desktop When Prompting for Elevation
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 1

    # Disable Remote Desktop Session Host Server
    Set-Service -Name 'SessionEnv' -StartupType Disabled

    # Enable Audit of IPsec Driver
    auditpol /set /subcategory:"IPsec Driver" /success:enable /failure:enable

    # Configure Windows SmartScreen Settings for Store Apps
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\System' -Name 'EnableSmartScreen' -Value 1

    # Disable the Password Reveal Button in Credential UI
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\CredUI' -Name 'DisablePasswordReveal' -Value 1

    # Enable Audit of Other Object Access Events
    auditpol /set /subcategory:"Other Object Access Events" /success:enable /failure:enable

    # Set User Account Control: Run All Administrators in Admin Approval Mode
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1

    # Disable Remote Assistance
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Remote Assistance' -Name 'fAllowToGetHelp' -Value 0

    # Enable Audit of Other Policy Change Events
    auditpol /set /subcategory:"Other Policy Change Events" /success:enable /failure:enable

    # Disable Windows Error Reporting
    Set-Service -Name 'WerSvc' -StartupType Disabled

    # Enable Audit of Other Privilege Use Events
    auditpol /set /subcategory:"Other Privilege Use Events" /success

    # Disable Automatic Setup of Network Connected Devices
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Device Metadata' -Name 'PreventDeviceMetadataFromNetwork' -Value 1

    # Restrict Access to the Command Line Using PowerShell
    Set-ExecutionPolicy Restricted

    # Disable Windows Ink Workspace
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\WindowsInkWorkspace' -Name 'AllowWindowsInkWorkspace' -Value 0

    # Disable Storage Sense
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\StorageSense' -Name 'Enabled' -Value 0

    # Disable Structured Exception Handling Overwrite Protection (SEHOP)
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Session Manager\Kernel' -Name 'DisableExceptionChainValidation' -Value 1

    # Set User Account Control: Only Elevate UIAccess Applications That Are Installed in Secure Locations
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableSecureUIAPaths' -Value 1

    # Disable Shared User Certificates
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\SystemCertificates' -Name 'SharedUserCertificates' -Value 0

    # Enable Audit of Other System Events
    auditpol /set /subcategory:"Other System Events" /success:enable /failure:enable

    # Disable the Launch of Mixed Reality Portal
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\MixedReality' -Name 'AllowMixedReality' -Value 0

    # Enable Audit of Other Account Management Events
    auditpol /set /subcategory:"Other Account Management Events" /success:enable /failure:enable

    # Set User Account Control: Behavior of Elevation Prompt for Standard Users to Automatically Deny Elevation Requests
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorUser' -Value 0

    # Disable the Use of Camera on the Lock Screen
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Personalization' -Name 'NoLockScreenCamera' -Value 1

    # Enable Audit of Authorization Policy Changes
    auditpol /set /subcategory:"Authorization Policy Change" /success:enable /failure:enable

    # Disable Cloud Content in Search Results
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Windows Search' -Name 'DisableWebSearch' -Value 1

    # Set Network Security: Minimum Session Security for NTLM SSP Based Clients to Require 128-bit Encryption
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0' -Name 'NTLMMinClientSec' -Value 536870912

    # Enable Audit of Filtering Platform Connection
    auditpol /set /subcategory:"Filtering Platform Connection" /success:enable /failure:enable

    # Disable the Use of Biometrics
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Biometrics' -Name 'Enabled' -Value 0

    # Set User Account Control: Admin Approval Mode for the Built-in Administrator Account
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'FilterAdministratorToken' -Value 1

    # Disable Feedback Notifications
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\DataCollection' -Name 'DoNotShowFeedbackNotifications' -Value 1

    # Enable Audit of Kernel Object
    auditpol /set /subcategory:"Kernel Object" /success:enable /failure:enable

    # Disable Web Content Evaluation ("SmartScreen") for Files
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\System' -Name 'EnableSmartScreen' -Value 0

    # Configure Windows Update to Use Local Servers Only
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DoNotConnectToWindowsUpdateInternetLocations' -Value 1

    # Disable Remote Desktop Server
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -Value 1

    # Enable Audit of Security System Extension
    auditpol /set /subcategory:"Security System Extension" /success:enable /failure:enable

    # Set User Account Control: Detect Application Installations and Prompt for Elevation
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableInstallerDetection' -Value 1

    # Disable Cloud Search
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Windows Search' -Name 'DisableWebSearch' -Value 1

    # Disable Online Tips and Tricks in Settings App
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\SettingSync' -Name 'DisableSettingSync' -Value 1

    # Enable Audit of File System
    auditpol /set /subcategory:"File System" /success:enable /failure:enable
    #Set User Account Control: Behavior of Elevation Prompt for Administrators in Admin Approval Mode
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 2
    #Disable Remote Desktop Gateway Service
    Set-Service -Name 'TSGateway' -StartupType Disabled
    #Enable Audit of Handle Manipulation
    auditpol /set /subcategory:"Handle Manipulation" /success:enable /failure:enable
    #Set Network Security: Do Not Allow Storage of Passwords and Credentials for Network Authentication
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'DisableDomainCreds' -Value 1
    #Disable Automatic Download and Installation of Map Updates
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Maps' -Name 'AutoDownloadAndUpdateMapData' -Value 0
    #Disable Windows Mobility Center
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\MobilityCenter' -Name 'NoMobilityCenter' -Value 1
    #Enable Audit of Registry
    auditpol /set /subcategory:"Registry" /success:enable /failure:enable
    #Disable AutoPlay for All Drives
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoDriveTypeAutoRun' -Value 255
    #Set User Account Control: Admin Approval Mode for the Built-in Administrator Account
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'FilterAdministratorToken' -Value 1
    #Disable Data Execution Prevention (DEP) for Explorer
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Explorer' -Name 'NoDataExecutionPrevention' -Value 1
    #Enable Audit of Non Sensitive Privilege Use
    auditpol /set /subcategory:"Non Sensitive Privilege Use" /success:enable

    #Set User Account Control: Run All Administrators in Admin Approval Mode
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1
    #Disable Windows HotStart
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Explorer' -Name 'NoHotStart' -Value 1
    #Enable Audit of Other Logon/Logoff Events
    auditpol /set /subcategory:"Other Logon/Logoff Events" /success:enable /failure:enable
    #Disable Sticky Keys Shortcut
    Set-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\StickyKeys' -Name 'Flags' -Value '506'
    #Set Network Security: LDAP Client Signing Requirements to Require Signing
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LDAP' -Name 'LDAPClientIntegrity' -Value 1
    #Enable Audit of Application Group Management
    auditpol /set /subcategory:"Application Group Management" /success:enable /failure:enable

    #Disable Remote Desktop Protocol (RDP) Services
    Set-Service -Name 'TermService' -StartupType Disabled
    #Set User Account Control: Virtualize File and Registry Write Failures to Per-User Locations
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableVirtualization' -Value 1
    #Disable Windows Tips
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContentEnabled' -Value 0
    #Enable Audit of Distribution Group Management
    auditpol /set /subcategory:"Distribution Group Management" /success:enable /failure:enable
    #Disable the Windows Push Notification Service (WpnService)
    Set-Service -Name 'WpnService' -StartupType Disabled
    #Set User Account Control: Only Elevate Executables That Are Signed and Validated
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ValidateAdminCodeSignatures' -Value 1
    #Disable User Access Control (UAC) Redirection on Secure Desktop
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 0
    #Enable Audit of Application Generated Events
    auditpol /set /subcategory:"Application Generated" /success:enable /failure:enable
    #Disable Microsoft Consumer Experiences
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsConsumerFeatures' -Value 1

    #Set Network Access: Named Pipes That Can Be Accessed Anonymously to None
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters' -Name 'NullSessionPipes' -Value ''

    #Disable the Lock Screen Camera and Mail Features
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Personalization' -Name 'NoLockScreenCamera' -Value 1
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Personalization' -Name 'NoLockScreenMail' -Value 1

    #Enable Audit of Central Policy Staging
    auditpol /set /subcategory:"Central Policy Staging" /success:enable /failure:enable

    #Disable the Launching of Connect Experience
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Connect' -Name 'Connect' -Value 0

    #Set User Account Control: Behavior of the Elevation Prompt for Standard Users
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorUser' -Value 0

    #Disable Background Apps from Running
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' -Name 'GlobalUserDisabled' -Value 1

    #Enable Audit of PNP Activity
    auditpol /set /subcategory:"PNP Activity" /success:enable /failure:enable

    #Disable Automatic Running of Scheduled Tasks in a Specific Path
    Get-ScheduledTask | Where-Object {$_.TaskPath -like "\Microsoft\Windows\AppID*"} | Disable-ScheduledTask

    #Set User Account Control: Switch to Secure Desktop When Prompting for Credentials
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 1

    # Enable Audit of Detailed File Share
    auditpol /set /subcategory:"Detailed File Share" /success:enable /failure:enable

    # Disable Windows Tips
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SoftLandingEnabled' -Value 0

    # Configure Legal Notice Text at Logon
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'LegalNoticeText' -Value 'Your Legal Notice Here'

    # Disable Windows Defender's Cloud-Based Protection
    Set-MpPreference -DisableIOAVProtection $true

    # Set Network Security: Do Not Allow Storage of Passwords and Credentials for Network Authentication
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'DisableDomainCreds' -Value 1

    # Disable Remote Desktop Protocol (RDP) Compression
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services' -Name 'ClientAVC420Enabled' -Value 0

    # Enable Audit of Other Logon/Logoff Events
    auditpol /set /subcategory:"Other Logon/Logoff Events" /success:enable /failure:enable

    # Disable Suggested Content in Settings App
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-338388Enabled' -Value 0

    # Disable Automatic Download of Maps
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\Maps' -Name 'AutoDownloadMaps' -Value 0

    # Set Network Security: Allow Local System to Use Computer Identity for NTLM
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'UseMachineId' -Value 1
 
    # Disable SMB Client Redirector Caching
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters' -Name 'DirectoryCacheLifetime' -Value 0

    # Enable Audit of Handle Manipulation
    auditpol /set /subcategory:"Handle Manipulation" /success:enable /failure:enable

    # Set Network Security: Blocks NTLM Authentication for Remote Calls
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0' -Name 'RestrictSendingNTLMTraffic' -Value 2

    # Disable Application Compatibility Engine
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\AppCompat' -Name 'DisableEngine' -Value 1

    # Enable Audit of Security Group Management Events
    auditpol /set /subcategory:"Security Group Management" /success:enable /failure:enable

    # Disable Windows Update Sharing
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\DeliveryOptimization' -Name 'DODownloadMode' -Value 0

    # Disable Sync Over Metered Connections
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\SettingSync' -Name 'SyncPolicy' -Value 2

    # Enable Audit of Kernel Object
    auditpol /set /subcategory:"Kernel Object" /success:enable /failure:enable

    # Disable Web Search in Start Menu
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'BingSearchEnabled' -Value 0

    # Set Network Security: LDAP Client Signing Requirements to Require Signing
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\LDAP' -Name 'LDAPClientIntegrity' -Value 1

    # Enable Audit of Non-Sensitive Privilege Use
    auditpol /set /subcategory:"Non Sensitive Privilege Use" /success:enable /failure:enable

    # Set Network Security: Restrict NTLM: Audit Incoming NTLM Traffic
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0' -Name 'AuditReceivingNTLMTraffic' -Value 1

    # Disable Location Scripting
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\LocationAndSensors' -Name 'DisableLocationScripting' -Value 1

    # Enable Audit of Application Generated
    auditpol /set /subcategory:"Application Generated" /success:enable /failure:enable

    # Disable Toast Notifications
    Set-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'DisableNotificationCenter' -Value 1

    # Disable Wi-Fi Sense Credential Sharing
    Set-ItemProperty -Path 'HKLM:\Software\Microsoft\WcmSvc\wifinetworkmanager\Config' -Name 'AutoConnectAllowedOEM' -Value 0

    # Enable Audit of PNP Activity
    auditpol /set /subcategory:"PNP Activity" /success:enable /failure:enable

    # Disable Microsoft Consumer Experience
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsConsumerFeatures' -Value 1

    # Disable Activity History
    Set-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Windows\System' -Name 'EnableActivityFeed' -Value 0


}
else {
    Write-Host "exiting"
    exit
}
