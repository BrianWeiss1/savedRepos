if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Host "Please run PowerShell as an Administrator."
    break
}

$YOUuser = ""
$YOUpassword = ""
$passwordDict = @{}
function Generate-RandomPassword {
    $result = @()
    for ($i = 1; $i -le 20; $i++) {
        $randomNumber = Get-Random -Minimum 1 -Maximum 62
        if ($randomNumber -le 9) {
            $result += $randomNumber
        } else {
            # Convert the number to a letter using ASCII
            $letter = [char]([byte][char]"A" + ($randomNumber - 10))
            $result += $letter
        }
    }
    return -join $result
}
function get-CocurrentAdmins() {
    $adminLst = @()
    $admins = (Get-LocalGroupMember -Group "Administrators")
    foreach ($admin in $admins) {
        $values = $Admin.Name.Split('\')[-1]
        $adminLst += $values
    }
    return $adminLst
}
function get-CocurrentUsers() {
    $users = Get-LocalUser
    $userlst = @()
    foreach ($user in $users) {
        $userlst += $user.Name
    }
    return $userlst
}
$adminLst = get-CocurrentAdmins
$userlst = get-CocurrentUsers
$pathToFile=".\test.txt"
Remove-Item -Path $pathToFile
New-Item -ItemType File -Path $pathToFile
Start-Process -FilePath $pathToFile
Start-Sleep -Seconds 10
$userInput = Read-Host "Are you sure? (y/n)"
$lines = Get-Content -Path $pathToFile
if ($userInput -contains "y") {
$credentials = @{}
for ($i = 0; $i -lt $lines.Length; $i++) {
    $line = $lines[$i].Trim()
    if ($line -match '^(\w+|\w+\s+\(you\))$') {
        $name = $line
        $password = $lines[$i + 1] -replace 'password: '
        $credentials[$name] = $password.Trim()
    }
    if ($line -contains "Authorized Users:") {
        break
    }
}
$start=1
$AutherizedUsers = @()
for ($i = 0; $i -lt $lines.Length; $i++) {
    $line = $lines[$i].Trim()
    if ($line -contains "Authorized Users:") {
        $start=0
    }
    if ($start -eq 0) {
        $name = $line
        $AutherizedUsers += $name
    }
}
foreach ($administrator2 in $credentials.GetEnumerator()) {
    $key = $administrator2.Key
    $value = $administrator2.Value
    if ($key -like "* (you)") {    
        $newKey = $key.Replace(' (you)', '')
        $credentials.Remove($key)
        $credentials[$newKey] = $value
        $YOUuser = $key
        $YOUpassword = $value
    }
}
foreach ($admin in $adminLst) {
    $stop=1
    if ($credentials[$admin]) {
        Write-Host "Change Pass $admin"
        $Password=$credentials[$admin]
        $SecurePassword = ConvertTo-SecureString -String $Password -AsPlainText -Force
        $UserAccount = Get-LocalUser -Name $admin # sets password
        $UserAccount | Set-LocalUser -Password $SecurePassword
    }
    else {
        if ($admin -ne "Administrator") {
            foreach ($user in $AutherizedUsers) {
                if ($user -eq $admin) {
                    Write-Host "Change $user to Local User" # not quite sure how to do this...
                    Remove-LocalGroupMember -Group "Administrators" -Member $admin 
                    $stop=0
                }
            }
            if ($stop -eq 1) {
                Write-Host "Remove User: $admin"
                Remove-LocalGroupMember -Group "Administrators" -Member $admin # Should remove user
                Remove-LocalUser -Name $admin
            }

        }
    }
}
foreach ($user in $userlst) {
    $stop=1
    foreach ($userCorrect in $AutherizedUsers) {
        if ($user -eq $userCorrect) {
            $stop=0
        }
    }
    foreach ($admin in $adminLst) {
        if ($user -eq $admin) {
            $stop=0
        }
    }
    if ($stop -eq 1) {



        if (($user -ne "Guest") -and ($user -ne "WDAGUtilityAccount") -and ($user -ne "DefaultAccount")) {
            Write-Host "Remove User: $user"
            Remove-LocalUser -Name $user
        }
    }
}
Write-Host "You are $YOUuser"
Write-Host "You are $YOUpassword"
$currentUserlst = get-CocurrentUsers
$adminLst = get-CocurrentAdmins
foreach ($autherizedUser in $AutherizedUsers) {
    $specialNum=1
    foreach ($currentUser in $currentUserlst) {
        if ($autherizedUser -eq $currentUser) {
            $specialNum=0
        }
    } 
    if ($specialNum -eq 1) {
        if ($autherizedUser -ne 'Authorized Users:') {
            Write-Host "Need to add $autherizedUser as Local User"
            $password = Generate-RandomPassword
            New-LocalUser -Name $autherizedUser -Password (ConvertTo-SecureString $password -AsPlainText -Force) -AccountNeverExpires
        }
    }
}
foreach ($autherizedAdmin in $AutherizedAdmins) {
    $specialNum=1
    foreach ($currentAdmin in $adminLst) {
        if ($autherizedAdmin -eq $currentAdmin) {
            $specialNum=0
        }
    }
    if ($specialNum -eq 1) {
        if ($autherizedAdmin -ne "Authorized Administrators:") {
            Write-Host "Need to add $autherizedAdmin as admin User"
            $password = Generate-RandomPassword
            New-LocalUser -Name $autherizedAdmin -Password (ConvertTo-SecureString $password -AsPlainText -Force) -AccountNeverExpires
            Add-LocalGroupMember -Group "Administrators" -Member $autherizedAdmin
        }
    }
}
$currentUserlst = get-CocurrentUsers
$currentAdminLst = get-CocurrentAdmins #just added some more not sure what to do about that
foreach ($currnetUser in $currentUserlst) {
    $Num=0
    foreach ($admin in $currentAdminLst) {
        if ($currnetUser -eq $admin) {
            $Num=1
        }
    }
    if ($Num -eq 0) {
        $password = Generate-RandomPassword
        $passwordDict[$currnetUser]=$password
        $password = $password | ConvertTo-SecureString -AsPlainText -Force
        $user = Get-LocalUser -Name $currnetUser
        $user | Set-LocalUser -Password $password
    }
}
foreach ($currentAdmin in $currentAdminLst) {
    $password = $credentials[$currentAdmin]   
    $passwordDict[$currentAdmin]=$password
}

$allUsers = Get-ConcurrentUsers

# Iterate through each user and set the password to expire
foreach ($user in $allUsers) {
    try {
        # Set the password to expire
        Set-LocalUser -Name $user -PasswordNeverExpires $false
        Write-Host "Password expiration set for user: $user"
    } catch {
        Write-Error "Failed to set password expiration for user: $user. Error: $_"
    }
}


Write-Host ($passwordDict | Format-List | Out-String)



net user administrator /active:no
net user guest /active:no

# How to do this?
auditpol /set /category:"Account Management" /success:enable /failure:enable
auditpol /set /category:"Logon/Logoff" /success:enable /failure:enable
auditpol /set /category:"Account Logon" /success:enable /failure:enable 

#What is UAC - Set User Account Control to prompt Admin Approval Mode:

reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 3 /f

# What is FTP directory: 11) Set permissions for the FTP directory: 6 pts.

# Enable firewall
Set-NetFirewallProfile -Enabled True

reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v fDisablePNPRedir /t REG_DWORD /d 1 /f

Set-Service -Name "simptcp" -Status stopped -StartupType disabled

Auditpol /set /Category:System /failure:enable
Set-Service -Name "EventLog" -Status running -StartupType automatic

# change Remote accessablity settings
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance" -Name "fAllowToGetHelp" -Value 0
Restart-Service -Name rasauto

Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name "fDenyTSConnections" -Value 1
Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Name "UserAuthentication" -Value 1

Set-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Remote Assistance" -Name fAllowToGetHelp -Value 0
Set-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Remote Assistance" -Name fAllowFullControl -Value 0

Restart-Service -Name TermService -Force

Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' -Name 'fAllowToGetHelp' -Value 0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' -Name 'fAllowFullControl' -Value 0
Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -Value 1
Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Name 'UserAuthentication' -Value 1
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableAntiSpyware' -Value 1
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' -Name 'SMB1' -Value 0
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' -Name 'SMB2' -Value 0
Set-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows Script Host\Settings' -Name 'Enabled' -Value 0
Set-ItemProperty -Path 'HKLM:\SAM\SAM\Domains\Account\Users\000001F5' -Name 'UserAccountControl' -Value 0
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoDriveTypeAutoRun' -Value 255
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell' -Name 'EnableScripts' -Value 0




















}

