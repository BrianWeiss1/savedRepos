# Define the path to the Firefox profiles
$user = "Doug Rattmann"
$profilesPath = "C:\Users\$user\AppData\Roaming\Mozilla\Firefox\Profiles"
Write-Host $profilesPath
# Define the required configuration setting
$configSetting = 'user_pref("identity.fxaccounts.enabled", false);'

# Check if the directory exists
if (Test-Path $profilesPath) {
    # Get all profile directories
    $profileDirs = Get-ChildItem -Path $profilesPath -Directory

    # Check each profile for the configuration setting
    foreach ($dir in $profileDirs) {
        $prefsFile = Join-Path -Path $dir.FullName -ChildPath 'prefs.js'

        # Check if the prefs file exists in the profile
        if (Test-Path $prefsFile) {
            # Check if the required setting is in the file
            $fileContent = Get-Content $prefsFile
            if ($fileContent -contains $configSetting) {
                Write-Host "Profile $($dir.Name) has Firefox sync disabled."
            } else {
                Write-Host "Profile $($dir.Name) does NOT have Firefox sync disabled."
            }
        } else {
            Write-Host "No prefs.js found in profile $($dir.Name)."
        }
    }
} else {
    Write-Host "Firefox profiles directory not found."
}
