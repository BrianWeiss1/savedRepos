if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Host "Please run PowerShell as an Administrator."
    break
}


$excludedPath = "C:\Users\rio\go"
Get-ChildItem -Path "C:\Users" -Recurse -File | Where-Object { $_.FullName -notlike "$excludedPath*" } | ForEach-Object {
    Write-Output $_.FullName
}




#with hiden files

$excludedPath = "C:\Users\rio\go"
Get-ChildItem -Path "C:\Users" -Recurse -File -Force | Where-Object { $_.FullName -notlike "$excludedPath*" } | ForEach-Object {
    Write-Output $_.FullName
}
