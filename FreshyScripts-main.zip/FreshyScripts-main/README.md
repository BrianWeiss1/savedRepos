# FreshyScripts
This Repository is for the CyberSecurity upincoming 10th graders, directed mainly towards scripts.
