def xor_operation(text, key):
    return ''.join(chr(ord(char) ^ key) for char in text)

def substitution_cipher_decrypt(text, key):
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    key_map = {key[i]: alphabet[i] for i in range(len(alphabet))}
    decrypted = ""

    for char in text:
        if char.upper() in key_map:
            # Reverse substitution
            decrypted_char = key_map[char.upper()]
            # Preserve case
            decrypted += decrypted_char.lower() if char.islower() else decrypted_char
        else:
            decrypted += char
    return decrypted

def decrypt(text):
    key = "QUNLYIHVPXERFZCABJMOKDGWST"
    xor_key = 6
    # First reverse XOR
    xor_decrypted = xor_operation(text, xor_key)
    # Then reverse Substitution Cipher
    return substitution_cipher_decrypt(xor_decrypted, key)


