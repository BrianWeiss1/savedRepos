Setup env

```
export PYTHONPATH="${PYTHONPATH}:/Users/brianw/Documents/GitHub/crypto-analyzer/"
export PYTHONPATH="${PYTHONPATH}:/crypto-analyzer/"
```

import os
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath("/Users/brianw/Documents/GitHub/crypto-analyzer")))

pip install ta, pandas_ta