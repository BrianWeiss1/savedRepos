import random

def prompt_and_encrypt(plaintext):
    # Define the standard alphabets and numbers
    lowercase = 'abcdefghijklmnopqrstuvwxyz'
    uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    numbers = '0123456789'

    # Prompt user for the entire cipher
    print("Please enter the entire cipher:")
    substitution_cipher = input().strip()

    # Extract individual ciphers for lowercase, uppercase, and numbers
    sub_lowercase = substitution_cipher[:26]
    sub_uppercase = substitution_cipher[26:52]
    sub_numbers = substitution_cipher[52:]

    # Verify the input lengths
    if len(sub_lowercase) != 26 or len(sub_uppercase) != 26 or len(sub_numbers) != 10:
        print("Invalid cipher input. Please ensure correct lengths for each cipher part.")
        return None

    # Creating translation tables
    # Note: We're reversing the order for encryption
    translation_table = str.maketrans(sub_lowercase + sub_uppercase + sub_numbers,
                                      lowercase + uppercase + numbers)

    # Encrypting the plaintext
    encrypted_text = plaintext.translate(translation_table)
    return encrypted_text

def prompt_and_decrypt(ciphertext):
    # Define the standard alphabets and numbers
    lowercase = 'abcdefghijklmnopqrstuvwxyz'
    uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    numbers = '0123456789'

    # Prompt user for the entire cipher
    print("Please enter the entire cipher:")
    substitution_cipher = input().strip()

    # Extract individual ciphers for lowercase, uppercase, and numbers
    sub_lowercase = substitution_cipher[:26]
    sub_uppercase = substitution_cipher[26:52]
    sub_numbers = substitution_cipher[52:]

    # Verify the input lengths
    if len(sub_lowercase) != 26 or len(sub_uppercase) != 26 or len(sub_numbers) != 10:
        print("Invalid cipher input. Please ensure correct lengths for each cipher part.")
        return None

    # Creating translation tables
    translation_table = str.maketrans(lowercase + uppercase + numbers,
                                      sub_lowercase + sub_uppercase + sub_numbers)

    # Decrypting the ciphertext
    decrypted_text = ciphertext.translate(translation_table)
    return decrypted_text

def generate_substitution_cipher():
    lowercase = 'abcdefghijklmnopqrstuvwxyz'
    uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    numbers = '0123456789'

    # Shuffle to create substitution ciphers
    sub_lowercase = ''.join(random.sample(lowercase, len(lowercase)))
    sub_uppercase = ''.join(random.sample(uppercase, len(uppercase)))
    sub_numbers = ''.join(random.sample(numbers, len(numbers)))

    return sub_lowercase, sub_uppercase, sub_numbers


# Example usage
# lowercase_cipher, uppercase_cipher, numbers_cipher = generate_substitution_cipher()
# print("Substitution cipher for lowercase:", lowercase_cipher)
# print("Substitution cipher for uppercase:", uppercase_cipher)
# print("Substitution cipher for numbers:", numbers_cipher)


# # Example usage
# plaintext = ""
# encrypted_message = prompt_and_encrypt("")
# if encrypted_message is not None:
#     print("Encrypted message:", encrypted_message)

if __name__ == '__main__':
    # Example usage
    ciphertext = ""
    decrypted_message = prompt_and_decrypt(ciphertext)
    if decrypted_message is not None:
        print("Decrypted message:", decrypted_message)
