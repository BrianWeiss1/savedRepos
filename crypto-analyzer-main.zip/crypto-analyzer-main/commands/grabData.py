import datetime
import requests
from time import sleep
from commands.format import dataToDF, forexDataToDF
import pandas as pd
from io import StringIO
import yfinance as yf

def getForexData(forex):
    df = eval(open(f'documents/finance/{forex}Data.txt', 'r').read())
    df = forexDataToDF(df[len(df)-17500:len(df)])
    columns_to_convert = ['open', 'high', 'low', 'close']
    for column in columns_to_convert:
        df[column] = df[column].apply(float)
    global dfIndex
    dfIndex = df.index[0]
    return df

# gets old data already obtained from binance
def getData(crypto='BTC'):
    # calltimes30('BTCUSDT')
    df = eval(open(f'documents/finance/{crypto}Data.txt', 'r').read())
    df = dataToDF(df[len(df)-17500:len(df)-3000])
    columns_to_convert = ['open', 'high', 'low', 'close', 'volume']
    for column in columns_to_convert:
        df[column] = df[column].apply(float)
    global dfIndex
    dfIndex = df.index[0]
    return df
def getDataAll(crypto='BTC'):
    # calltimes30('BTCUSDT')
    df = eval(open(f'documents/finance/{crypto}Data.txt', 'r').read())
    df = dataToDF(df)
    columns_to_convert = ['open', 'high', 'low', 'close', 'volume']
    for column in columns_to_convert:
        df[column] = df[column].apply(float)
    global dfIndex
    dfIndex = df.index[0]
    return df

def getDataBacktest(crypto='BTC'):
    # calltimes30('BTCUSDT')
    df = eval(open(f'documents/finance/{crypto}Databack.txt', 'r').read())
    df = dataToDF(df[len(df)-3000:len(df)])
    columns_to_convert = ['open', 'high', 'low', 'close', 'volume']
    for column in columns_to_convert:
        df[column] = df[column].apply(float)
    global dfIndex
    dfIndex = df.index[0]
    return df


def getDataTEST(crypto='BTC'):
    # calltimes30('BTCUSDT')
    df = eval(open(f'documents/finance/{crypto}Data.txt', 'r').read())
    df = dataToDF(df[len(df)-15000:len(df)])
    columns_to_convert = ['open', 'high', 'low', 'close', 'volume']
    for column in columns_to_convert:
        df[column] = df[column].apply(float)
    global dfIndex
    dfIndex = df.index[0]
    return df

def getStockData(stock='TSLA'):
    df = eval(open(f'documents/finance/{stock}Data.txt', 'r').read())
    df = dataToDF(df[len(df)-17500:len(df)])
    columns_to_convert = ['open', 'high', 'low', 'close', 'volume']
    for column in columns_to_convert:
        df[column] = df[column].apply(float)
    global dfIndex
    dfIndex = df.index[0]
    return df
def findOldStockData(stock='TSLA', filename='documents/stocks/TSLAData.csv'):
    """
    Fetch historical stock data for the given stock symbol from Yahoo Finance and write it to a CSV file.

    :param stock: Stock symbol, default is 'TSLA'.
    :param filename: Name of the file to save the data.
    :return: None. Writes data to a CSV file.
    """
    # Set the period to max to retrieve as much historical data as possible
    data = yf.download(stock, interval='30m', period='max')

    # Check if we have enough data points
    if len(data) < 20000:
        print(f"Warning: Only {len(data)} data points fetched, which is less than 20000.")

    # Write to CSV
    data.to_csv(filename)
    print(f"Data saved to {filename}")

def getDataTESTTEST(crypto='BTC'):
    # calltimes30('BTCUSDT')
    df = eval(open(f'documents/finance/{crypto}Data.txt', 'r').read())
    df = dataToDF(df[len(df)-50800:len(df)-25000])
    columns_to_convert = ['open', 'high', 'low', 'close', 'volume']
    for column in columns_to_convert:
        df[column] = df[column].apply(float)
    global dfIndex
    dfIndex = df.index[0]
    return df
def findOldData(symbol='SOLUSDT', start_time = '2015-11-17'):
    endpoint = "https://api.binance.com/api/v1/klines"
    api_key = "0imfnc8mVLWwsAawjYr4RxAf50DDqtle" # 0imfnc8mVLWwsAawjYr4RxAf50DDqtlx
    symbol.split()
    symbol = symbol
    interval = "30m"
    start_time = start_time # prev 2023-02-23, '2023-05-23
    date_obj = datetime.datetime.strptime(start_time, "%Y-%m-%d")
    timestamp_ms = int(date_obj.timestamp()) * 1000
    end_time = '2030-12-15'
    date_obj = datetime.datetime.strptime(end_time, "%Y-%m-%d")
    timestamp_ms2 = int(date_obj.timestamp()) * 1000
    start_time = timestamp_ms  # Replace with your desired start time in milliseconds
    end_time = timestamp_ms2    # Replace with your desired end time in milliseconds
    formatted_data = []

    limit = 1000
    all_data = []

    while start_time < end_time:
        params = {
            "symbol": symbol,
            "interval": interval,
            "startTime": start_time,
            "endTime": end_time,
            "limit": limit,
        }

        headers = {
            "X-MBX-APIKEY": api_key,
        }

        response = requests.get(endpoint, params=params, headers=headers)

        if response.status_code == 200:
            historical_data = response.json()
            if not historical_data:
                break
            all_data.extend(historical_data)
            start_time = historical_data[-1][0] + 1  # Set the new startTime for the next request

        else:
            print(f"Error: {response.status_code}, {response.text}")
            break


    for candle in all_data:
        timestamp = candle[0] / 1000  # Convert milliseconds to seconds
        date = datetime.datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M')
        open_price = candle[1]
        high_price = candle[2]
        low_price = candle[3]
        close_price = candle[4]
        volume = candle[5]

        formatted_candle = {
            'date': date,
            'open': open_price,
            'high': high_price,
            'low': low_price,
            'close': close_price,
            'volume': volume,
        }

        formatted_data.append(formatted_candle)
    # print(formatted_data)
    split_pair = symbol.split("USDT")
    f = open(f'documents/{split_pair[0]}Data.txt', 'w')
    f.write(str(formatted_data))
    f.close()
    return formatted_data


def findCurrentData(symbol, start_time = '2023-08-27'):
    endpoint = "https://api.binance.com/api/v1/klines"
    api_key = "0imfnc8mVLWwsAawjYr4RxAf50DDqtle" # 0imfnc8mVLWwsAawjYr4RxAf50DDqtlx
    symbol.split()
    symbol = symbol
    interval = "30m"
    start_time = start_time # prev 2023-02-23
    date_obj = datetime.datetime.strptime(start_time, "%Y-%m-%d")
    timestamp_ms = int(date_obj.timestamp()) * 1000
    end_time = '2030-02-23'
    date_obj = datetime.datetime.strptime(end_time, "%Y-%m-%d")
    timestamp_ms2 = int(date_obj.timestamp()) * 1000
    start_time = timestamp_ms  
    end_time = timestamp_ms2    
    formatted_data = []
    limit = 1000
    all_data = []
    while start_time < end_time:
        params = {
            "symbol": symbol,
            "interval": interval,
            "startTime": start_time,
            "endTime": end_time,
            "limit": limit,
        }
        headers = {
            "X-MBX-APIKEY": api_key,
        }
        response = requests.get(endpoint, params=params, headers=headers)
        if response.status_code == 200:
            historical_data = response.json()
            if not historical_data:
                break
            all_data.extend(historical_data)
            start_time = historical_data[-1][0] + 1 
        else:
            print(f"Error: {response.status_code}, {response.text}")
            break
    for candle in all_data:
        timestamp = candle[0] / 1000 
        date = (datetime.datetime.utcfromtimestamp(timestamp)  - datetime.timedelta(hours=4)).strftime('%Y-%m-%d %H:%M')
        open_price = candle[1]
        high_price = candle[2]
        low_price = candle[3]
        close_price = candle[4]
        volume = candle[5]
        formatted_candle = {
            'date': date,
            'open': open_price,
            'high': high_price,
            'low': low_price,
            'close': close_price,
            'volume': volume,
        }
        formatted_data.append(formatted_candle)
    return formatted_data
def grabLast1000(symbol):
    endpoint = "https://api.binance.com/api/v1/klines"
    api_key = "0imfnc8mVLWwsAawjYr4RxAf50DDqtle" # 0imfnc8mVLWwsAawjYr4RxAf50DDqtlx
    symbol.split()
    symbol = symbol
    interval = "30m"
    limit = 1000


    params = {
    "symbol": symbol,
    "interval": interval,
    "limit": limit,
    }
    headers = {
        "X-MBX-APIKEY": api_key,
    }
    response = requests.get(endpoint, params=params, headers=headers)
    if response.status_code == 200:
        formatted_data = []
        historical_data = response.json()
        for candle in historical_data:
            timestamp = candle[0] / 1000 
            date = (datetime.datetime.utcfromtimestamp(timestamp)  - datetime.timedelta(hours=4)).strftime('%Y-%m-%d %H:%M')
            open_price = candle[1]
            high_price = candle[2]
            low_price = candle[3]
            close_price = candle[4]
            volume = candle[5]
            formatted_candle = {
                'date': date,
                'open': open_price,
                'high': high_price,
                'low': low_price,
                'close': close_price,
                'volume': volume,
            }
            formatted_data.append(formatted_candle)
        return formatted_data
    return response.json()

def grabForex(values):
    symbol = "JPY"
    api_key = "d6e8542914aa439e92fceaccca1c2708"
    base_url = "https://api.twelvedata.com/time_series"
    params = {
        "symbol": f"{symbol}/USD",  # The forex symbol you want to retrieve
        "interval": "30min",   # Time interval (e.g., 1min, 1day)
        "outputsize": values,     # Number of data points to retrieve
        "apikey": api_key     # Your Twelve Data API key
    }
    response = requests.get(base_url, params=params)
    data = response.json()
    f = open(f'documents/{symbol}Data.txt', 'w')
    f.write(str(data['values']))
    f.close()
    return data['values']
    
if __name__ == '__main__':
    # df = getForexData('forex')
    # print(df)
    df = getDataAll("BTC")
    print(df)
    # print(df)
    # findOldData('BTCUSDT')
    # grabForex(1000)