

def findMFI(value):
    if value > 55:
        return "BULLISH"
    elif value < 45:
        return 'BEARISH'
    else:
        return 'SIDEWAYS'