from ta.momentum import StochRSIIndicator
import pandas_ta as ta
import pandas as pd
from ta.volume import MFIIndicator
from ta.trend import EMAIndicator
from ta.trend import SMAIndicator
import numpy as np


def get_StochasticRelitiveStrengthIndex(data, window, smooth1, smooth2):
    close_prices = pd.DataFrame(np.array(data['close']).astype(float), columns=['close'])
    stochRSIind = StochRSIIndicator(close=close_prices['close'], window=window, smooth1=smooth1, smooth2=smooth2)
    return stochRSIind.stochrsi_k(), stochRSIind.stochrsi_d()
def get_EMA(df: pd.DataFrame, window: int):
    ind = EMAIndicator(close=df['close'], window=window)
    return ind.ema_indicator()

def get_SMA(df: pd.DataFrame, window: int):
    ind = SMAIndicator(close=df['close'], window=window)
    return ind.sma_indicator()

def get_MFI(data, window):
    MFIind = MFIIndicator(data['high'], data['low'], data['close'], data['volume'], window)
    return MFIind.money_flow_index()

def get_hull(df: pd.DataFrame, period_1: int):
    hma = ta.hma(df["close"], period_1) 
    return hma
def get_WMA(df: pd.DataFrame, period_1: int):
    wma = ta.wma(df["close"], period_1)
    return wma

def get_DoubleEMA(df: pd.DataFrame, period_1: int, period_2: int) -> pd.Series:
    ema_1 = ta.ema(df["close"], period_1)
    ema_2 = ta.ema(df["close"], period_2)    
    return ema_1, ema_2

def get_DoubleWMA(df: pd.DataFrame, period_1: int, period_2: int) -> pd.Series:
    wma_1 = ta.wma(df["close"], period_1)
    wma_2 = ta.wma(df["close"], period_2)    
    return wma_1, wma_2

def get_DoubleHMA(df: pd.DataFrame, period_1: int, period_2: int) -> pd.Series:
    hma_1 = ta.hma(df["close"], period_1)
    hma_2 = ta.hma(df["close"], period_2)    
    return hma_1, hma_2

def get_TripleHMA(df: pd.DataFrame, period_1: int, period_2: int, period_3: int) -> tuple:
    hma_1 = ta.hma(df["close"], period_1)
    hma_2 = ta.hma(df["close"], period_2)
    hma_3 = ta.hma(df["close"], period_3)
    return hma_1, hma_2, hma_3
def get_QuadrupleHMA(df: pd.DataFrame, period_1: int, period_2: int, period_3: int, period_4: int) -> tuple:
    hma_1 = ta.hma(df["close"], period_1)
    hma_2 = ta.hma(df["close"], period_2)
    hma_3 = ta.hma(df["close"], period_3)
    hma_4 = ta.hma(df["close"], period_4)
    return hma_1, hma_2, hma_3, hma_4

def get_Stochastic(df: pd.DataFrame, period_1: int, period_2: int, period_3: int) -> tuple:
    df["high"] = np.array(df["high"]).astype(float)
    df["low"] = np.array(df["low"]).astype(float)
    df["close"] = np.array(df["close"]).astype(float)

    stoch = ta.stoch(df["high"], df["low"], df["close"], period_1, period_2, period_3)
    return stoch[f'STOCHk_{period_1}_{period_2}_{period_3}'], stoch[f'STOCHd_{period_1}_{period_2}_{period_3}']