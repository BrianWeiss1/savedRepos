import pandas as pd
import pytz
from datetime import datetime
from decimal import Decimal

#converts data to a datetime
def dataToDF(data):
    df = pd.DataFrame(data)
    df['datetime'] = pd.to_datetime(df['date'])
    df = df.set_index('datetime')
    df = df.drop('date', axis=1)
    return df

def forexToDF(data):
    df = pd.DataFrame(data)
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.set_index('datetime')
    df = df.drop('datetime', axis=1)
    return df

# converts the df's time's to be of the estimated correct timezone
def convert_to_est(df, utc_offset):
    df.index = pd.to_datetime(df.index) - pd.Timedelta(hours=utc_offset)
    est = pytz.timezone('US/Eastern')
    df.index = df.index.tz_localize('UTC').tz_convert(est).tz_localize(None)
    return df

# estimates timezone the df is in
def estimateTimezone(df):
    last_datetime = df.iloc[-1].name
    if last_datetime.tzinfo is None:
        last_datetime = last_datetime.tz_localize('UTC')
    est = pytz.timezone('America/New_York')
    current_time_est = datetime.now(est)
    time_difference = current_time_est - last_datetime
    hours_offset = round(time_difference.total_seconds() / 3600, 1)
    return int(hours_offset)

#converts data with volume to float
def convertData1(df):
    columns_to_convert = ['open', 'high', 'low', 'close', 'volume']
    for column in columns_to_convert:
        df[column] = df[column].astype(float)
    return df
#converts data without volume to float
def convertData2(df):
    columns_to_convert = ['open', 'high', 'low', 'close']
    for column in columns_to_convert:
        df[column] = df[column].astype(float)
    return df
#converts data with volume to Decimal
def convertData3(df):
    columns_to_convert = ['open', 'high', 'low', 'close', 'volume']
    for column in columns_to_convert:
        df[column] = df[column].apply(lambda x: Decimal(x) if pd.notna(x) and not isinstance(x, str) else x)
    return df
# converts forex data to datetime (why forex)
def forexDataToDF(data):
    df = pd.DataFrame(data)
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.set_index('datetime')
    # df = df.drop('datetime', axis=1)
    return df