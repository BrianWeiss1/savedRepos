from bingX.spot.spot import Spot
