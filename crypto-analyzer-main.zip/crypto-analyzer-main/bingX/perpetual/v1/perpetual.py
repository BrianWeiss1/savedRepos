
class PerpetualV1:
    def __init__(self, api_key: str, secret_key: str) -> None:
        pass