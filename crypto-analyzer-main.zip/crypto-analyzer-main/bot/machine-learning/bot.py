import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from commands.indicators.indicators import get_DoubleHMA, get_TripleHMA, get_StochasticRelitiveStrengthIndex
from commands.grabData import getData, findOldData

# ... [previous import statements remain the same]

# Retrieve ETH data
ethDF = findOldData('ETHUSDT')
print(ethDF)
# Feature Engineering on ETH data

# Add Double HMA
hma_20, hma_50 = get_DoubleHMA(ethDF, 27, 50)  # Example parameters
ethDF['HMA_20'] = hma_20
ethDF['HMA_50'] = hma_50

# Add Triple HMA
hma_short, hma_medium, hma_long = get_TripleHMA(ethDF, 17, 172, 68)  # Example parameters
ethDF['HMA_Short'] = hma_short
ethDF['HMA_Medium'] = hma_medium
ethDF['HMA_Long'] = hma_long

# Add Stochastic Oscillator
stochRSIK, stochRSID = get_StochasticRelitiveStrengthIndex(ethDF, 73, 1, 21)
ethDF['Stoch_K'] = stochRSIK
ethDF['Stoch_D'] = stochRSID

# Predicting 'Close' of the next day
ethDF['Target'] = ethDF['close'].shift(-1)

# Handling NaN values
ethDF.dropna(inplace=True)

# Split data into features and target
X_eth = ethDF.drop('Target', axis=1)
y_eth = ethDF['Target']

# Split data into train and test sets
X_train_eth, X_test_eth, y_train_eth, y_test_eth = train_test_split(X_eth, y_eth, test_size=0.2, random_state=42)

# Model Training
model.fit(X_train_eth, y_train_eth)

# Prediction
predictions_eth = model.predict(X_test_eth)

# Evaluate the model
mse_eth = mean_squared_error(y_test_eth, predictions_eth)
print(f'Mean Squared Error for ETH: {mse_eth}')

# Generate Buy/Sell Signals
ethDF['Predicted_Next_Close'] = np.nan
ethDF.iloc[(len(ethDF) - len(predictions_eth)):, ethDF.columns.get_loc('Predicted_Next_Close')] = predictions_eth
ethDF['Signal'] = 'Hold'
ethDF.loc[ethDF['close'] < ethDF['Predicted_Next_Close'], 'Signal'] = 'Buy'
ethDF.loc[ethDF['close'] > ethDF['Predicted_Next_Close'], 'Signal'] = 'Sell'

# Display the last few rows to verify
print(ethDF.tail())
