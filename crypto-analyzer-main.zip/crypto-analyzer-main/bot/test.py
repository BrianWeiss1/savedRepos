import subprocess

# Path to the binary file
binary_file_path = 'decrypt'

# Execute the binary file
# The `check=True` option will raise an exception if the command exits with a non-zero status
try:
    result = subprocess.run([binary_file_path], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    print("Binary file executed successfully.")
    print("Output:", result.stdout.decode())  # Decoding is necessary for binary output
except subprocess.CalledProcessError as e:
    print("Error occurred while executing binary file.")
    print("Error message:", e.stderr.decode())