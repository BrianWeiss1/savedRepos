from typing import Literal
from documents.coinex.coinex import CoinEx, CoinExApiError
from enum import Enum
import ccxt
from decimal import Decimal
import telebot
    
def send_message(text, parse_mode=None):
    BOT_TOKEN = '6913673966:AAGVUweik0EpNrPxUgFVA35Ve0Dyayo5waw'
    telegramBot = telebot.TeleBot(BOT_TOKEN)    
    chat_id = 5046185897
    telegramBot.send_message(chat_id, text, parse_mode=parse_mode)

class Leverage(Enum):
    """
    Enumeration for leverage options.

    Attributes:
        ONE: Represents a leverage of 1.
        TWO: Represents a leverage of 2.
        THREE: Represents a leverage of 3.
        FIVE: Represents a leverage of 5.
        EIGHT: Represents a leverage of 8.
        TEN: Represents a leverage of 10.
        TWENTY: Represents a leverage of 20.
        FIFTY: Represents a leverage of 50.
        HUNDRED: Represents a leverage of 100.
    """
    ONE = '1'
    TWO = '2'
    THREE = '3'
    FIVE = '5'
    EIGHT = '8'
    TEN = '10'
    TWENTY = '20'
    FIFTY = '50'
    HUNDRED = '100'
    
class Trade:
    def __init__(self, coinex: CoinEx, ccxt_coinex: ccxt.coinex, symbol: str, leverage: float):
        self.coinex = coinex
        self.ccxt_coinex = ccxt_coinex
        self.symbol = symbol
        self.leverage = leverage
        
    def get_Order_IDs(self):
        orderList = []
        orders = self.coinex.get_orders(self.symbol)
        for order in orders:
            orderList.append([order['position_id'], order['amount']]) 
        return orderList

    def buy(self, amount: float):
        ticker = self.ccxt_coinex.fetch_ticker(self.symbol)['last']
        value = float(ticker)
        return self.coinex.perpetual_order_limit(market=self.symbol, side='long', amount=amount, price=value)
    
    def buyStoploss(self, position_id, stopLossDecimal: float = 0.5):
        ticker = self.ccxt_coinex.fetch_ticker(self.symbol)['last']
        value = float(ticker)
        intermediateValue = Decimal(stopLossDecimal*100/self.leverage)
        stoplossPrice = Decimal(value)*((Decimal(100)-intermediateValue)/Decimal(100))
        return self.coinex.perpetual_stop_limit(market=self.symbol, order_id=position_id, stop_loss_price=str(stoplossPrice))

    def close(self, amount: float):
        ticker = self.ccxt_coinex.fetch_ticker(self.symbol)['last']
        value = float(ticker) 
        # if long
        orderList = Trade.get_Order_IDs(self)
        if orderList != []:
            try:
                return self.coinex.perpetual_close_limit(market=self.symbol, position_id=orderList[0][0], amount=amount, price=value) # what if the possisiton size is greater 
            except CoinExApiError as e:
                if str(e) == 'invalid close amount':
                    return self.coinex.perpetual_close_limit(market=self.symbol, position_id=orderList[0][0], amount=orderList[0][1], price=value)
                else:
                    print(str(e))
                    send_message(str(e))
            
                
        else: 
            return False
    def short(self, amount: float):
        ticker = self.ccxt_coinex.fetch_ticker(self.symbol)['last']
        value = float(ticker)
        return self.coinex.perpetual_order_limit(market=self.symbol, side='short', amount=amount, price=value)
    def cancel_orders(self):
        data = self.coinex.perpetual_pending_positions(self.symbol, 0)['records']
        extracted_data = []
        for item in data:
            extracted_info = {
                'amount': item['amount'],
                'price': item['price'],
                'order_id': item['order_id']
            }
            extracted_data.append(extracted_info)
        # print(ext racted_data)
        if extracted_data != '[]':
            for item in extracted_data:
                self.coinex.perpetual_cancel_order(self.symbol, item['order_id'])
        return True
        
        
    def change_Leverage(self, leverage: Leverage, position_type: Literal["Isolated Margin", "Cross Margin"]):
        if position_type == "Isolated Margin":
            position_type = 1
        elif position_type == 'Cross Margin':
            position_type = 2
        try:
            return self.coinex.perpetual_adjust_leverage(market=self.symbol, position_type=position_type, leverage=leverage.value)
        except CoinExApiError as e:
                if str(e) == 'order exist':
                    return False, 'Order exists'
                else:
                    print(str(e))
                    send_message(str(e))

    def get_orders(self):
        return self.coinex.get_orders(self.symbol)
    def get_balance(self):
        return Decimal(self.coinex.perpetual_balance_info()['USDT']['available'])
    def get_balance_all(self):
        return self.coinex.perpetual_balance_info()['USDT']
