import time
from datetime import datetime
from bot.coinexT.trade import Leverage, Trade
from documents.coinex.coinex import CoinEx
from decimal import Decimal
from bot.example import init
from commands.format import convert_to_est, dataToDF, estimateTimezone
from commands.grabData import grabLast1000
from commands.indicators.indicators import get_StochasticRelitiveStrengthIndex

bot: Trade = None
leverage = Decimal(100)
betPercent = Decimal(0.1)

def run():
    global bot
    stopBuys = False
    i = -1
    stochShort: int = 0
    stochLong: int = 0

    dataPre = dataToDF(grabLast1000("BTCUSDT"))
    timezone_offset = estimateTimezone(dataPre)
    df = convert_to_est(dataPre, -timezone_offset)

    rsiK, rsiD = get_StochasticRelitiveStrengthIndex(df, 27, 50, 13)

    close = df["close"]

    if 0.0001 > leverage * (betPercent * bot.get_balance()) / Decimal(
        df["close"].iloc[i]
    ):
        stopBuys = True

    if rsiK.iloc[i-1] < rsiD.iloc[i-1] and rsiK.iloc[i] > (rsiD.iloc[i]*1.4067):
        stochShort = 1
    else:
        stochShort = 0
    if rsiK.iloc[i-1] > rsiD.iloc[i-1] and (rsiK.iloc[i]*1.4023) < rsiD.iloc[i]:
        stochLong = 1
    else:
        stochLong = 0
        
    if stochLong == 1:
        size = ((betPercent * bot.get_balance())/ close)
        print('BUY')
        print(size)
        order = bot.buy(size=size)
    elif stochShort == 1:
        size = ((betPercent * bot.get_balance())/ close)
        print('SELL')
        print(size)
        order = bot.close(size=size)
    
    i += 1
 
def main():
    bot = init()
    bot.change_Leverage(Leverage.FIFTY, "Isolated Margin")
    oldMinute = -1  # FIND ERRORS and DEBUG
    # if sell size is less then 0.0005, if more then
    while True:
        currentMinute = datetime.now().minute
        if currentMinute == 30 and currentMinute != oldMinute:
            print("30 minutes have passed")
            oldMinute = currentMinute
            run()
        time.sleep(50)


if __name__ == "__main__":
    main()
