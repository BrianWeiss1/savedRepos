

import time
import ccxt
import sys
import importlib.util
from documents.coinex.coinex import CoinEx
from bot.coinexT.trade import Leverage, Trade
import documents.decrypt as decrypt

def init(market='BTCUSDT', leverage=50):
    global bot
    global coinex
    global ccxt_coinex
    global access_id
    global secret
    with open('documents/coinex_api.txt') as f:
        access_id = f.read()
    with open('documents/coinex_private_api.txt') as f: 
        secret = decrypt.decrypt(f.read())
    coinex = CoinEx(access_id, secret)
    ccxt_coinex = ccxt.coinex({
        'apiKey': access_id,
        'secret': secret,
    })
    bot = Trade(coinex, ccxt_coinex, market, leverage)
    return bot
    
if __name__ == '__main__':
    bot = init('BTCUSDT', 50)
    bot.cancel_orders()
    # time.sleep(20)
    # print(bot.close(0.0005))
    
    # bot.short
    
