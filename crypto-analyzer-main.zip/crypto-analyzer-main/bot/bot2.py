import time
from datetime import datetime
from bot.coinexT.trade import Leverage
from decimal import Decimal
from bot.example import init
from commands.format import convert_to_est, dataToDF, estimateTimezone
from commands.grabData import grabLast1000
from commands.indicators.indicators import get_DoubleHMA
import numpy as np

bot = None
leverage = Decimal(100)
betPercent = Decimal(0.1)


def run():
    global bot
    stopBuys = False
    i = -1
    try:
        dataPre = dataToDF(grabLast1000("BTCUSDT"))
    except ValueError as e:
        print("VPN ERORR Maybe")
        print(e)
        return
        
    timezone_offset = estimateTimezone(dataPre)
    df = convert_to_est(dataPre, -timezone_offset)

    hull_short, hull_long = get_DoubleHMA(df, 27, 50)
    # df = np.array(df)
    hull_short = np.array(hull_short)
    hull_long = np.array(hull_long)
    hull_long = hull_long.astype(float)
    hull_short = hull_short.astype(float)

    close = df["close"]
    close = np.array(close)
    close = close.astype(float)

    if 0.0001 > leverage * (betPercent * bot.get_balance()) / Decimal(
        df["close"].iloc[i]
    ):
        stopBuys = True

    if hull_short[i] > hull_long[i]:
        if close[i] > hull_short[i]:
            hullSignal = "BUY SIGNAL"
        elif close[i] < hull_short[i] and close[i] > hull_long[i]:
            hullSignal = "LUQUIDATE CURRENT POSITION"
        elif close[i] < hull_long[i]:
            hullSignal = "SELL SIGNAL"
        else:
            print("ERROR 1")
    elif hull_long[i] > hull_short[i]:
        if close[i] > hull_long[i]:
            hullSignal = "SELL SIGNAL"
        elif close[i] < hull_long[i] and close[i] > hull_short[i]:
            hullSignal = "LUQUIDATE CURRENT POSITION"
        elif close[i] < hull_short[i]:
            hullSignal = "BUY SIGNAL"
        else:
            print("ERROR 2")
    elif hull_long[i] == hull_short[i]:
        print("EQUALITY ERROR 4")
    else:
        print("ERROR 3")

    if (
        hull_short[i - 1] > hull_long[i - 1]
        and hull_short[i] < hull_long[i]
    ):
        hullShort = True
    else:
        hullShort = False
    if (
        hull_short[i - 1] < hull_long[i - 1]
        and (hull_short[i]) > hull_long[i]
    ):
        hullLong = True
    else:
        hullLong = False

    if hullSignal == "BUY SIGNAL" and stopBuys == False:
        long = True
        short = False
        size = (
            leverage * (betPercent * bot.get_balance()) / Decimal(close[i])
        )
        print(size)
        print('BUY')
        order = bot.buy(size)

        longPrice = close[i]
    elif hullSignal == "SELL SIGNAL":
        short = True
        long = False

        size = (
            leverage * (betPercent * bot.get_balance()) / Decimal(close[i])
        )
        print('SELL')

        order = bot.sell(size)
        shortPrice = close[i]

    if hullLong == True and short and stopBuys == False:
        long = True
        short = False
        size = (
            leverage * (betPercent * bot.get_balance()) / Decimal(close[i])
        )
        print('BUY')
        order = bot.buy(size)

        longPrice = close[i]
    elif hullShort == True and long:
        long = False
        short = True
        size = (
            leverage * (betPercent * bot.get_balance()) / Decimal(close[i])
        )
        print('SELL')
        order = bot.sell(size)
        shortPrice = close[i]

def main():
    bot = init()
    bot.change_Leverage(Leverage.HUNDRED, "Isolated Margin")
    oldMinute = -1  # FIND ERRORS and DEBUG
    # if sell size is less then 0.0005, if more then
    while True:
        currentMinute = datetime.now().minute
        if currentMinute == 30 and currentMinute != oldMinute:
            print("30 minutes have passed")
            oldMinute = currentMinute
            run()
        time.sleep(50)

if __name__ == "__main__":
    main()
