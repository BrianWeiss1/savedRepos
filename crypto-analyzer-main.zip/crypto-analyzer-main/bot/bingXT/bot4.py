# ░██████╗██╗███╗░░██╗░██████╗░██╗░░░░░███████╗  ██╗░░██╗███╗░░░███╗░█████╗░
# ██╔════╝██║████╗░██║██╔════╝░██║░░░░░██╔════╝  ██║░░██║████╗░████║██╔══██╗
# ╚█████╗░██║██╔██╗██║██║░░██╗░██║░░░░░█████╗░░  ███████║██╔████╔██║███████║
# ░╚═══██╗██║██║╚████║██║░░╚██╗██║░░░░░██╔══╝░░  ██╔══██║██║╚██╔╝██║██╔══██║
# ██████╔╝██║██║░╚███║╚██████╔╝███████╗███████╗  ██║░░██║██║░╚═╝░██║██║░░██║
# ╚═════╝░╚═╝╚═╝░░╚══╝░╚═════╝░╚══════╝╚══════╝  ╚═╝░░╚═╝╚═╝░░░░░╚═╝╚═╝░░╚═╝

import time
from datetime import datetime
from bot.bingXT.trade import Trade
from decimal import Decimal
from bot.bingXT.example import APIKey, init
from commands.format import convert_to_est, dataToDF, estimateTimezone
from commands.grabData import grabLast1000
from commands.indicators.indicators import get_hull
from bot.bingXT.trade import send_message
import pytz
import numpy as np

leverage = Decimal(50)


def run(bot: Trade):
    """
    Executes the trading bot logic based on the given parameters.

    Args:
        bot (Trade): The trading bot object.

    Returns:
        None
    """
    global leverage
    i = -1
    stopBuys = False
    betPercent = Decimal(0.1)
    dataPre = dataToDF(grabLast1000("BTCUSDT"))
    # print(dataPre)
    timezone_offset = estimateTimezone(dataPre)
    df = convert_to_est(dataPre, -timezone_offset)
    close = float(df["close"].iloc[i])

    hull = get_hull(
        df, 31
    )
    hull = np.array(hull)
    
    if 0.0001 > leverage * (betPercent * bot.get_balance()) / Decimal(
        close
    ):
        stopBuys = True
        
    # Ensure data is not NaN
    if hull[i] > close:
        size = (
            leverage * (betPercent * bot.get_balance()) /
            Decimal(close)
        )
        order = bot.buyLong(size) 
        print("BUY")
        longPrice = close
        short = True
        long = False
        send_message(4, str(order))
        send_message(4, 'BUY')
        # Implement your code for buying here
    elif close > hull[i]:
        size = (
            leverage * (betPercent * bot.get_balance()) /
            Decimal(close)
        )
        order = bot.closeLong(size) 
        print("SELL")
        shortPrice = close
        short = False
        long = True
        send_message(4, str(order))
        send_message(4, 'SELL')


    i += 1


def main():
    leverage = 50
    bot = init('BTCUSDT', leverage, 0.5, APIKey.API_4.value)
    bot.changeLeverage(leverage)
    oldMinute = -1
    i = 0
    count = 0
    while True:
        try:
            currentMinute = datetime.now().minute
            i += 1
            if ((currentMinute == 30 or currentMinute == 0) and currentMinute != oldMinute):
                # bot.cancel_orders()
                count += 1
                est = pytz.timezone('US/Eastern')
                print("30 minutes: " + str(bot.get_balance()) + ": " +
                        str(datetime.now(pytz.utc).astimezone(est)))
                run(bot)
                oldMinute = currentMinute
            time.sleep(50)
        except Exception as e:
            if count >= 5:
                count = 0
                send_message(4, "Bot has stopped running")
                time.sleep(61)
            else:
                oldMinute = -1
            print(str(e))
            send_message(4, str(e))


if __name__ == "__main__":
    main()
