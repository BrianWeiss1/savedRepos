# ██████╗░░█████╗░██╗░░░██╗██████╗░██╗░░░░░███████╗  ██╗░░██╗██╗░░░██╗██╗░░░░░██╗░░░░░
# ██╔══██╗██╔══██╗██║░░░██║██╔══██╗██║░░░░░██╔════╝  ██║░░██║██║░░░██║██║░░░░░██║░░░░░
# ██║░░██║██║░░██║██║░░░██║██████╦╝██║░░░░░█████╗░░  ███████║██║░░░██║██║░░░░░██║░░░░░
# ██║░░██║██║░░██║██║░░░██║██╔══██╗██║░░░░░██╔══╝░░  ██╔══██║██║░░░██║██║░░░░░██║░░░░░
# ██████╔╝╚█████╔╝╚██████╔╝██████╦╝███████╗███████╗  ██║░░██║╚██████╔╝███████╗███████╗
# ╚═════╝░░╚════╝░░╚═════╝░╚═════╝░╚══════╝╚══════╝  ╚═╝░░╚═╝░╚═════╝░╚══════╝╚══════╝

import time
from datetime import datetime
from bot.bingXT.trade import Trade
from decimal import Decimal
from bot.bingXT.example import APIKey, init
from commands.format import convert_to_est, dataToDF, estimateTimezone
from commands.grabData import grabLast1000
from commands.indicators.indicators import get_DoubleHMA
from bot.bingXT.trade import send_message
import pytz
import numpy as np

#Fix glitch ewith doing bot buy and sell orders .

bot = None
leverage = Decimal(50)
betPercent = Decimal(0.1)


def run(bot: Trade):
    """
    Executes the trading strategy based on the current market conditions.

    This function retrieves historical data, performs calculations, and makes trading decisions
    based on the Hull Moving Average (HMA) signals. It buys or sells assets according to the
    calculated signals and the available balance.

    Returns:
        None
    """
    # global bot
    stopBuys = False
    i = -1
    try:
        dataPre = dataToDF(grabLast1000("BTCUSDT"))
    except ValueError as e:
        print("VPN ERORR")
        print(e)
        return

    timezone_offset = estimateTimezone(dataPre)
    df = convert_to_est(dataPre, -timezone_offset)

    hull_short, hull_long = get_DoubleHMA(df, 27, 50)
    hull_short = np.array(hull_short)
    hull_long = np.array(hull_long)
    hull_long = hull_long.astype(float)
    hull_short = hull_short.astype(float)

    close = df["close"]
    close = np.array(close)
    close = close.astype(float)

    if 0.0001 > leverage * (betPercent * bot.get_balance()) / Decimal(
        df["close"].iloc[i]
    ):
        stopBuys = True

    if hull_short[i] > hull_long[i]:
        if close[i] > hull_short[i]:
            hullSignal = "BUY SIGNAL"
        elif close[i] < hull_short[i] and close[i] > hull_long[i]:
            hullSignal = "LUQUIDATE CURRENT POSITION"
        elif close[i] < hull_long[i]:
            hullSignal = "SELL SIGNAL"
        else:
            print("ERROR 1")
    elif hull_long[i] > hull_short[i]:
        if close[i] > hull_long[i]:
            hullSignal = "SELL SIGNAL"
        elif close[i] < hull_long[i] and close[i] > hull_short[i]:
            hullSignal = "LUQUIDATE CURRENT POSITION"
        elif close[i] < hull_short[i]:
            hullSignal = "BUY SIGNAL"
        else:
            print("ERROR 2")
    elif hull_long[i] == hull_short[i]:
        print("EQUALITY ERROR 4")
    else:
        print("ERROR 3")

    if hull_short[i - 1] > hull_long[i - 1] and hull_short[i] < hull_long[i]:
        hullShort = True
    else:
        hullShort = False
    if hull_short[i - 1] < hull_long[i - 1] and (hull_short[i]) > hull_long[i]:
        hullLong = True
    else:
        hullLong = False

    if hullSignal == "BUY SIGNAL" and stopBuys == False:
        long = True
        short = False
        size = leverage * (betPercent * bot.get_balance()) / Decimal(close[i])
        print(size)
        print("BUY")
        order = bot.buyLong(size)
        bot.openTakeProfit(size)
        send_message(3, str(order))
        send_message(3, 'BUY')

        longPrice = close[i]
    elif hullSignal == "SELL SIGNAL":
        if hullLong != True:
            short = True
            long = False

            size = leverage * (betPercent * bot.get_balance()) / Decimal(close[i])
            print("SELL")

            order = bot.closeLong(size*10/9)
            shortPrice = close[i]
            send_message(3, str(order))
            send_message(3, 'BUY')

    if hullLong == True and short and stopBuys == False:
        long = True
        short = False
        size = leverage * (betPercent * bot.get_balance()) / Decimal(close[i])
        print("BUY")
        order = bot.buyLong(size)
        bot.openTakeProfit(size)
        send_message(3, str(order))
        send_message(3, 'BUY')


        longPrice = close[i]
    elif hullShort == True and long:
        long = False
        short = True
        size = leverage * (betPercent * bot.get_balance()) / Decimal(close[i])
        print("SELL")
        order = bot.closeLong(size*10/9)
        shortPrice = close[i]
        send_message(3, str(order))
        send_message(3, 'SELL')



if __name__ == "__main__":
    bot = init("BTCUSDT", leverage, 0.5, APIKey.API_3.value)
    bot.changeLeverage(leverage)
    oldMinute = -1
    i = 0
    count = 0
    while True:
        try:
            currentMinute = datetime.now().minute
            i += 1
            if (
                currentMinute == 30 or currentMinute == 0
            ) and currentMinute != oldMinute:
                # bot.cancel_orders()
                count += 1
                est = pytz.timezone("US/Eastern")
                print(
                    "30 minutes: "
                    + str(bot.get_balance())
                    + ": "
                    + str(datetime.now(pytz.utc).astimezone(est))
                )
                run(bot)
                oldMinute = currentMinute
            time.sleep(50)
        except Exception as e:
            if count >= 5:
                count = 0
                send_message(3, "Bot has stopped running")
                time.sleep(61)
            else:
                oldMinute = -1
            print(str(e))
            send_message(3, str(e))
