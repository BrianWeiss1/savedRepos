from bingX.exceptions import ClientError
from decimal import Decimal
import telebot
from bingX.perpetual.v2 import PerpetualV2
from bingX.perpetual.v2.types import (
    ForceOrder,
    HistoryOrder,
    MarginType,
    OrderType,
    Order,
    PositionSide,
    Side,
)

def send_message(botid=1, text='notext', parse_mode=None): # add botid to calling of function
    BOT_TOKEN = ""
    if botid == 1:
        BOT_TOKEN = '6913673966:AAGVUweik0EpNrPxUgFVA35Ve0Dyayo5waw'
    elif botid == 2:
        BOT_TOKEN = '6830962232:AAHq7InNscrDf2Qfzi1Rmq1L2Vv9Q0gTtZc'
    elif botid == 3:
        BOT_TOKEN = '6674521761:AAG82tUw-2xoq3B-47zU5tIr-PIz_MW6M-Q'
    elif botid == 4:
        BOT_TOKEN = '6956964690:AAEEaFLDuRLxhW8iRIXl4DiWU86l4nYUW6w'
    else:
        BOT_TOKEN = '6913673966:AAGVUweik0EpNrPxUgFVA35Ve0Dyayo5waw'
    telegramBot = telebot.TeleBot(BOT_TOKEN)    
    chat_id = 5046185897
    telegramBot.send_message(chat_id, text, parse_mode=parse_mode)
    
class Trade:
    """
    A class representing a trade in a cryptocurrency exchange.

    Attributes:
    - apiurl (str): The URL of the API for the exchange.
    - bingx (PerpetualV2): An instance of the PerpetualV2 class for making API calls.
    - symbol (str): The trading symbol for the trade.
    - leverage (float): The leverage used for the trade.
    - stoploss (float): The stop loss percentage for the trade.

    Methods:
    - __init__(bingx: PerpetualV2, symbol: str, leverage: float, stoploss: float): Initializes a Trade object.
    - changeLeverage(leverage: int = None): Changes the leverage for the trade.
    - buyLong(amount: float): Places a long buy order for the trade.
    - closeLong(amount: float): Closes a long position for the trade.
    - buyShort(amount: float): Places a short sell order for the trade.
    - closeShort(amount: float): Closes a short position for the trade.
    - cancel_orders(): Cancels all open orders for the trade.
    - get_balance(): Returns the available margin balance for the trade.
    """

    apiurl = "https://open-api.bingx.com"

    def __init__(self, bingx: PerpetualV2, symbol: str, leverage: float, stoploss: float):
        """
        Initializes a Trade object.

        Parameters:
        - bingx (PerpetualV2): An instance of the PerpetualV2 class for making API calls.
        - symbol (str): The trading symbol for the trade.
        - leverage (float): The leverage used for the trade.
        - stoploss (float): The stop loss percentage for the trade.
        """
        self.bingx = bingx
        self.symbol = f'{symbol.split("USDT")[0]}-USDT'
        self.leverage = Decimal(leverage)
        self.stoploss = Decimal(stoploss)

    def changeLeverage(self, leverage: int = None):
        """
        Changes the leverage for the trade.

        Parameters:
        - leverage (int): The new leverage value. If not provided, the current leverage value will be used.
        """
        if leverage == None:
            leverage = self.leverage
        self.leverage = leverage
        self.bingx.trade.change_leverage(symbol=self.symbol, positionSide=PositionSide.LONG, leverage=leverage)
        self.bingx.trade.change_leverage(symbol=self.symbol, positionSide=PositionSide.LONG, leverage=leverage)

    def buyLong(self, size: float):      
        """
        Places a long buy order for the trade.

        Parameters:
        - amount (float): The amount of the cryptocurrency to buy.
        """
        value = Decimal(self.bingx.market.get_latest_price_of_trading_pair(self.symbol)['price'])
        quanity = round(Decimal(size), 4)
        
        stoplossPrice = value * (Decimal(1) - self.stoploss/self.leverage)
        
        self.bingx.trade.create_order(Order(symbol=self.symbol, side=Side.BUY, positionSide=PositionSide.LONG, quantity=quanity, type=OrderType.MARKET, stopPrice=stoplossPrice))
        self.bingx.trade.create_order(Order(symbol=self.symbol, side=Side.BUY, positionSide=PositionSide.LONG, quantity=quanity, type=OrderType.STOP_MARKET, stopPrice=stoplossPrice))
    def openTakeProfit(self, size: float):
        """
        Places a take profit order for the trade.

        Parameters:
        - amount (float): The amount of the cryptocurrency to buy.
        """
        value = Decimal(self.bingx.market.get_latest_price_of_trading_pair(self.symbol)['price'])
        quanity = round(Decimal(size), 4)
        
        takeProfitPrice = value * (Decimal(1) + self.stoploss/self.leverage)
        
        self.bingx.trade.create_order(Order(symbol=self.symbol, side=Side.BUY, positionSide=PositionSide.LONG, quantity=quanity, type=OrderType.TAKE_PROFIT_MARKET, stopPrice=takeProfitPrice))

    def closeLong(self, size: float):
        """
        Closes a long position for the trade.

        Parameters:
        - amount (float): The amount of the cryptocurrency to sell.
        """
        quanity = round(Decimal(size), 4)
        try:
            self.bingx.trade.create_order(Order(symbol=self.symbol, side=Side.SELL, positionSide=PositionSide.LONG, quantity=quanity))
        except ClientError:
            print('Position does not exist!')
            send_message('Position does not exist!')

    def buyShort(self, amount: float):
        """
        Places a short sell order for the trade.

        Parameters:
        - amount (float): The amount of the cryptocurrency to sell.
        """
        value = Decimal(self.bingx.market.get_latest_price_of_trading_pair(self.symbol)['price'])
        quanity = round(Decimal(amount), 4)
        
        stopLoss = value * (Decimal(1)+ self.stoploss/self.leverage)
        
        self.bingx.trade.create_order(Order(symbol=self.symbol, side=Side.SELL, positionSide=PositionSide.SHORT, quantity=quanity, type=OrderType.MARKET, stopPrice=stopLoss))
        self.bingx.trade.create_order(Order(symbol=self.symbol, side=Side.SELL, positionSide=PositionSide.SHORT, quantity=quanity, type=OrderType.STOP_MARKET, stopPrice=stopLoss))

    def closeShort(self, amount: float):
        """
        Closes a short position for the trade.

        Parameters:
        - amount (float): The amount of the cryptocurrency to buy.
        """
        quanity = round(Decimal(amount), 4)

        self.bingx.trade.create_order(Order(symbol=self.symbol, side=Side.BUY, positionSide=PositionSide.SHORT, quantity=quanity))

    def cancel_orders(self):
        """
        Cancels all open orders for the trade.
        """
        self.bingx.trade.cancel_all_orders(self.symbol)

    def get_balance(self):
        """
        Returns the available margin balance for the trade.

        Returns:
        - balance (Decimal): The available margin balance.
        """
        return Decimal(self.bingx.account.get_details()['balance']['availableMargin'])
    def get_all_balance(self):
        """
        Retrieves the balance from the account details.

        Returns:
            Decimal: The balance of the account.
        """
        return self.bingx.account.get_details()['balance']
