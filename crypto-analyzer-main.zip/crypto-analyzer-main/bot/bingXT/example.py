from commands.decrypt import prompt_and_decrypt
from bingX.perpetual.v2.perpetual import PerpetualV2
from bot.bingXT.trade import Trade
import time
from enum import Enum

class APIKey(Enum):
    """
    Enumeration class representing different API keys.
    
    Attributes:
        API_1 (str): The first API key. brianct: Byte
        API_2 (str): The second API key. theboy
        API_3 (str): The third API key. brian970
        API_4 (str): The fourth API key. wario
    """
    API_1 = "1" 
    API_2 = "2"
    API_3 = "3"
    API_4 = "4"

def init(market: str='BTCUSDT', leverage: int=50, stoploss: float=0.5, api_key_id: str = '1'):
    """
    Initializes the trading bot with the specified market, leverage, and stoploss.

    Args:
        market (str, optional): The market to trade on. Defaults to 'BTCUSDT'.
        leverage (int, optional): The leverage to use for trading. Defaults to 50.
        stoploss (float, optional): The stoploss percentage for the bot. Defaults to 0.5.

    Returns:
        Trade: The initialized trading bot.
    """
    APIKEY = ""
    SECRETKEY = ""
    if api_key_id == "1":
        f = open('documents/bingx_api.txt', 'r')
        APIKEY = 'zGnYUEbpDvOI36v9DnPIvMLQEVz44Vgme7AUAyFeonkUAusiLDi9PFM65nyjAuijESmpmC2eGAuqmFfHVQ'
        SECRETKEY = prompt_and_decrypt(f.readline())
        f.close()
    elif api_key_id == "2":
        f = open('documents/bingx_api2.txt', 'r')
        APIKEY = '4kBokBizUrJ8SPGUR0Vr4Aul6vVgKJwB4Fas0qzhYbvf5WRKQGyaBW9DMJqI7pTOn4BzDh96ycgAE2WH1Vg'
        SECRETKEY = prompt_and_decrypt(f.readline())
        f.close()
    elif api_key_id == "3":
        f = open('documents/bingx_api3.txt', 'r')
        APIKEY = '0yM5fkA5pvkqE9v5RlukfZdqmAZY8xgQAkhFjnECepgGgX6OT8mNPolBDY7yefFqbHUzIexIdhWb4QD8ZEcw'
        SECRETKEY = prompt_and_decrypt(f.readline())
        f.close()
    elif api_key_id == "4":
        f = open('documents/bingx_api4.txt', 'r')
        APIKEY = '9LmAnahanHadg075x3vyPZRpTLvoSnkXL9m3Q3PbFaOuDwu2Zabb3LogNdjXnsBi9ybByVl2cUL4xhehk5P5AA'
        SECRETKEY = prompt_and_decrypt(f.readline())
        f.close()

    
    bingx = PerpetualV2(api_key=APIKEY, secret_key=SECRETKEY)
    bot = Trade(bingx, market, leverage, stoploss)
    return bot

if __name__ == '__main__':
    bot = init('BTCUSDT', 100, 0.5)
    bot.changeLeverage(100)
    bot.buyLong(0.0001)
    # time.sleep(5)
    
    # bot.closeLong(0.0002)
