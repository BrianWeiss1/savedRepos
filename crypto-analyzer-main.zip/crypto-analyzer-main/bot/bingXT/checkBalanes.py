
import time
from datetime import datetime
from bot.bingXT.trade import Trade
from decimal import Decimal
from bot.bingXT.example import APIKey, init
from commands.format import convert_to_est, dataToDF, estimateTimezone
from commands.grabData import grabLast1000
from commands.indicators.indicators import get_DoubleHMA
from bot.bingXT.trade import send_message
import pytz
import numpy as np
leverage = 50

for API in APIKey:
    bot = init("BTCUSDT", leverage, 0.5, API.value)
    print(bot.get_all_balance())


bot.get_balance()