# ░██████╗████████╗░█████╗░░█████╗░██╗░░██╗
# ██╔════╝╚══██╔══╝██╔══██╗██╔══██╗██║░░██║
# ╚█████╗░░░░██║░░░██║░░██║██║░░╚═╝███████║
# ░╚═══██╗░░░██║░░░██║░░██║██║░░██╗██╔══██║
# ██████╔╝░░░██║░░░╚█████╔╝╚█████╔╝██║░░██║ RSI
# ╚═════╝░░░░╚═╝░░░░╚════╝░░╚════╝░╚═╝░░╚═╝
import time
from datetime import datetime
from bot.bingXT.trade import Trade
from decimal import Decimal
from bot.bingXT.example import APIKey, init
from commands.format import convert_to_est, dataToDF, estimateTimezone
from commands.grabData import grabLast1000
from commands.indicators.indicators import get_StochasticRelitiveStrengthIndex
from bot.bingXT.trade import send_message
import pytz
import numpy as np

bot: Trade = None
leverage = Decimal(50)
betPercent = Decimal(0.1)


def run(bot: Trade):
    stopBuys = False
    i = -1
    stochShort: int = 0
    stochLong: int = 0

    try:
        dataPre = dataToDF(grabLast1000("BTCUSDT"))
    except ValueError as e:
        print("VPN ERORR")
        print(e)
        return
    timezone_offset = estimateTimezone(dataPre)
    df = convert_to_est(dataPre, -timezone_offset)

    rsiK, rsiD = get_StochasticRelitiveStrengthIndex(df, 27, 50, 13)

    close = df["close"].iloc[-1]

    if 0.0001 > leverage * (betPercent * bot.get_balance()) / Decimal(
        df["close"].iloc[i]
    ):
        stopBuys = True

    if rsiK.iloc[i-1] < rsiD.iloc[i-1] and rsiK.iloc[i] > (rsiD.iloc[i]*1.4067):
        stochShort = 1
    else:
        stochShort = 0
    if rsiK.iloc[i-1] > rsiD.iloc[i-1] and (rsiK.iloc[i]*1.4023) < rsiD.iloc[i]:
        stochLong = 1
    else:
        stochLong = 0

    if stochLong == 1:
        size = ((betPercent * bot.get_balance()) / close)
        print('BUY')
        print(size)
        order = bot.buyLong(size=size)
        send_message(3, str(order))
        send_message(3, 'BUY')
    elif stochShort == 1:
        size = ((betPercent * bot.get_balance()) / close)
        print('SELL')
        print(size)
        order = bot.closeLong(size=size)
        send_message(3, str(order))
        send_message(3, 'SELL')

    i += 1


def main():
    leverage = 50
    bot = init("BTCUSDT", leverage, 0.5, APIKey.API_3.value)
    bot.changeLeverage(leverage)
    oldMinute = -1
    i = 0
    count = 0
    while True:
        try:
            currentMinute = datetime.now().minute
            i += 1
            if (
                currentMinute == 30 or currentMinute == 0
            ) and currentMinute != oldMinute:
                # bot.cancel_orders()
                count += 1
                est = pytz.timezone("US/Eastern")
                print(
                    "30 minutes: "
                    + str(bot.get_balance())
                    + ": "
                    + str(datetime.now(pytz.utc).astimezone(est))
                )
                run(bot)
                oldMinute = currentMinute
            time.sleep(50)
        except Exception as e:
            if count >= 5:
                count = 0
                send_message(3, ("Bot has stopped running"))
                time.sleep(61)
            else:
                oldMinute = -1
            print(str(e))
            send_message(3, (str(e)))


if __name__ == "__main__":
    main()
