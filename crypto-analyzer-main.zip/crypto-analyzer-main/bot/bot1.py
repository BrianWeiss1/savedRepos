import time
from datetime import datetime
from bot.coinexT.trade import Leverage, Trade
# from coinex.coinex import CoinEx
from decimal import Decimal
from bot.example import init
from commands.format import convert_to_est, dataToDF, estimateTimezone
from commands.grabData import grabLast1000
from commands.indicators.indicators import get_TripleHMA
from bot.coinexT.trade import send_message

bot = None
leverage = Decimal(100)
betPercent = Decimal(0.1)

def run(bot: Trade):
    global leverage
    stopBuys = False
    dataPre = dataToDF(grabLast1000("BTCUSDT"))
    timezone_offset = estimateTimezone(dataPre)
    df = convert_to_est(dataPre, -timezone_offset)

    i = -1
    hull_short, hull_medium, hull_long = get_TripleHMA(
        df, 17, 172, 68
    )  # 17, 172, 68     (970 max)

    if 0.0001 > leverage * (betPercent * bot.get_balance()) / Decimal(
        df["close"].iloc[i]
    ):
        stopBuys = True

    if (
        hull_short.iloc[i] > hull_medium.iloc[i]
        and hull_medium.iloc[i] > hull_long.iloc[i]
    ) and not stopBuys:
        print("BUY")
        # Buy logic
        size = (
            leverage * (betPercent * bot.get_balance()) / Decimal(df["close"].iloc[i])
        )
        
        order = bot.buy(size)
        # print(order)
        
        order = bot.buyStoploss(bot.get_Order_IDs()[0][0], 0.5)
        
        longPrice = df.iloc[i]
        long = True
        short = False
        send_message('BUY')
    elif (
        hull_short.iloc[i] < hull_medium.iloc[i]
        and hull_medium.iloc[i] < hull_long.iloc[i]
    ):
        print("SELL")
        size = (
            leverage * (betPercent * bot.get_balance()) / Decimal(df["close"].iloc[i])
        )
        order = bot.close(size)
        send_message(str(order))
        shortPrice = df.iloc[i]
        long = False
        short = True
        send_message('SELL')
# original_text = "_WO1J6>34OW0J?01617?1SH_0JJ0S25>_J7?25614H_H4_?W"
# # key = 

# # Example usage
# # encrypted_text_v2 = encrypt(original_text)
# decrypted_text_v2 = decrypt(original_text)

# print(decrypted_text_v2)
def main():
    leverage = 100
    bot = init('BTCUSDT', leverage)
    bot.change_Leverage(Leverage.HUNDRED, "Isolated Margin")
    oldMinute = -1
    i = 0
    count = 0 
    while True:
        try:
            currentMinute = datetime.now().minute
            i+=1
            if ((currentMinute == 30 or currentMinute == 0) and currentMinute != oldMinute):
                # bot.cancel_orders()
                count+=1
                print("30 minutes have passed")
                run(bot)
                oldMinute = currentMinute
            time.sleep(50)
        except Exception as e:
            if count >= 5:
                count = 0
                send_message("Bot has stopped running")
                time.sleep(61)  
            else:   
                oldMinute = -1           
            print(str(e))
            send_message(str(e))
            
        

if __name__ == "__main__":
    main()
