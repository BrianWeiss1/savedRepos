import backtrader as bt
# from commands.format import dataToDF
from commands.grabData import getData, getDataTEST
from datetime import date, datetime, time, timedelta
from commands.counter import run
import numpy as np
from commands.indicators.indicators import get_TripleHMA
import time
from commands.indicators.calculate import findMFI
import multiprocessing
from functools import partial
import random
start_time = time.time()
leverage = 50
class OpeningRangeBreakout(bt.Strategy):
    params = (
        ('hull_short', None),  # HMA with 45 periods
        ('hull_medium', None), # HMA with 105 periods
        ('hull_long', None),   # HMA with 240 periods
    )
    def __init__(self):
        self.i = 0
        self.order = None
        self.betPercent = 0.1 # I'm not sure if I should stack indicators since this is so high

        self.long = True
        self.short = True
        self.longPrice = None
        self.shortPrice = None
        
        self.hullLong = False
        self.hullShort = False
        self.hullSignal = ""
        self.hull_short = self.params.hull_short
        self.hull_medium = self.params.hull_medium
        self.hull_long = self.params.hull_long
        
        self.long_positions = []
        self.short_positions = []
        
        self.position_size = 0
        self.orders = []
        self.id = 0
        self.runProgram = True
        
    def next(self):
        if self.runProgram:
            i = self.i
            
            if self.broker.getvalue() < 4:
                self.runProgram = False
            else:
                self.runProgram = True
            if self.long or self.short:
                self.check_stop_loss()
            # Ensure data is not NaN
            if self.runProgram:
                if not np.isnan(self.hull_short[i]) and not np.isnan(self.hull_medium[i]) and not np.isnan(self.hull_long[i]):  
                    if self.hull_short[i] > self.hull_medium[i] and self.hull_medium[i] > self.hull_long[i]:
                        self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                        self.order = self.buy(size=self.size) 
                        self.long = True
                        self.short = False
                        self.position_size = self.size
                        self.long_positions.append({
                            'entry_price': self.data.close[0],
                            'size': self.size
                        })

                        # Implement your code for buying here
                    elif self.hull_short[i] < self.hull_medium[i] and self.hull_medium[i] < self.hull_long[i]:
                        self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                        self.order = self.sell(size=self.size) 
                        self.long = False
                        self.short = True
                        self.position_size = -self.size
                        self.short_positions.append({
                            'entry_price': self.data.close[0],
                            'size': self.size
                        })                    
            self.i += 1

    def check_stop_loss(self):
        global leverage
        stoploss = 0.5/leverage
        for position in self.long_positions:
            current_price = self.data.close[0]
            loss = (position['entry_price'] - current_price) / position['entry_price']
            loss *= leverage  # Adjust for leverage
            if loss >= stoploss:
                self.close(size=position['size'])  # Close this specific position
                self.long_positions.remove(position)  # Remove from list

        # Check stop loss for short positions
        for position in self.short_positions:
            current_price = self.data.close[0]
            loss = (current_price - position['entry_price']) / position['entry_price']
            loss *= leverage  # Adjust for leverage
            if loss >= stoploss:
                self.close(size=position['size'])  # Close this specific position
                self.short_positions.remove(position)  # Remove from list


def worker(v, option, a, b, c):
    cerebro = bt.Cerebro()
    cerebro.broker.set_cash(50.00)         
    cerebro.broker.setcommission(mult=leverage)

    df = getData()
    if option == 1:
        hma_short, hma_medium, hma_long = get_TripleHMA(df, v, b, c) # 110, 111, 224
    elif option == 2:
        hma_short, hma_medium, hma_long = get_TripleHMA(df, a, v, c) # 110, 80, 25   
    elif option == 3:
        hma_short, hma_medium, hma_long = get_TripleHMA(df, a, b, v) # 110, 80, 25
    # if doesnt work, test on two ind datasets
    
    npHMA_short = np.array(hma_short)
    npHMA_medium = np.array(hma_medium)
    npHMA_long = np.array(hma_long)
    data = bt.feeds.PandasData(dataname=df)
    cerebro.adddata(data)
    cerebro.addstrategy(OpeningRangeBreakout, hull_short=npHMA_short, hull_medium=npHMA_medium, hull_long=npHMA_long)

    cerebro.run()

    finalVal = cerebro.broker.getvalue()
    return [finalVal, v]

if __name__ == '__main__':
    pool = multiprocessing.Pool(multiprocessing.cpu_count())

    while (True):
        option = 2
        defaultValues = [random.randint(1, 200), random.randint(1, 200), random.randint(1, 200)] #110, 111, 224
        # defaultValues = [174, 56, 29]
        values = defaultValues
        samecount = [False, False, False]
        while True:
            print('STARTING NEW ITERATION  ' + str(values))
            # Create a partial function that pre-fills the arguments
            partial_worker = partial(worker, option=option, a=values[0], b=values[1], c=values[2])

            # Use pool.map with the partial function
            results = pool.map(partial_worker, range(1, 200))

            # Process the results
            sorted_results = sorted(results, key=lambda x: x[0], reverse=True)
            max_final_val, max_final_sym = sorted_results[0]
            bestVal = sorted_results[0][1]         
            if option == 1:
                priorVal = values[0]
                values[0] = bestVal
                if priorVal == bestVal:
                    samecount[0] = True
                else:
                    samecount[0] = False
                    samecount[1] = False
                    samecount[2] = False                
                option = 2
                if samecount[0] and samecount[1]:
                    option = 3
            elif option == 2:
                priorVal = values[1]
                values[1] = bestVal
                if priorVal == bestVal:
                    samecount[1] = True
                else:
                    samecount[0] = False
                    samecount[1] = False
                    samecount[2] = False                
                option = 3
                if samecount[1] and samecount[2]:
                    option = 1
            elif option == 3:
                priorVal = values[2]
                values[2] = bestVal
                if priorVal == bestVal:
                    samecount[2] = True
                else:
                    samecount[0] = False
                    samecount[1] = False
                    samecount[2] = False
                option = 1
                
                if samecount[2] and samecount[0]:
                    option = 2
            if samecount[2] and samecount[1] and samecount[0]:
                break
            
            
            end_time = time.time()
            execution_time = (end_time - start_time)
            
            print(f"Optimal value: {max_final_sym}, Max Final Value: {max_final_val}, Execution Time: {execution_time}")
        print(values)
        with open('output.txt', 'a') as f:
            f.write(str(values) + "\n")