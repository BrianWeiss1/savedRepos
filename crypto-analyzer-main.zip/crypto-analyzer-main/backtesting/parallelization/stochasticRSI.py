import concurrent.futures
import random
import numpy as np
import backtrader as bt
from commands.indicators.indicators import get_StochasticRelitiveStrengthIndex
from commands.grabData import getData, getDataTEST


# from commands.indicators.calculate import findMFI
class OpeningRangeBreakout(bt.Strategy):
    params = (
        ('rsiK', None),  # External NumPy array for stochRSIK3
        ('rsiD', None),  # External NumPy array for stochRSID3
        # ('k', None),
        # ('j', None),
    )
    def __init__(self):
        self.order = None
        self.i = 0
        self.betPercent = 0.1 # I'm not sure if I should stack indicators since this is so high
        self.stochLong = 0
        self.stochShort = 0
        
    def next(self):
        i = self.i
        rsiK = self.params.rsiK
        rsiD = self.params.rsiD

        if rsiK[i-1] < rsiD[i-1] and rsiK[i] > (rsiD[i]*1.4067):
            self.stochShort = 1
        else:
            self.stochShort = 0
        if rsiK[i-1] > rsiD[i-1] and (rsiK[i]*1.4023) < rsiD[i]:
            self.stochLong = 1
        else:
            self.stochLong = 0
            
        if self.stochLong == 1:
            self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
            self.order = self.buy(size=self.size)
        elif self.stochShort == 1:
            self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
            self.order = self.close(size=self.size)
      
        self.i += 1
 
9
        
def cerebroInit(df, stochRSIk, stochRSId):
    cerebro = bt.Cerebro()
    cerebro.broker.set_cash(1.00)
    print('Starting Portfolio Value: %.2f' % cerebro.broker.getvalue())
    data = bt.feeds.PandasData(dataname=df)
    cerebro.adddata(data)
    cerebro.addstrategy(OpeningRangeBreakout, rsiK=stochRSIk, rsiD=stochRSId)
    cerebro.broker.setcommission(mult=53)
    return cerebro


def run_strategy(df, a, b, c):
    stochRSIK, stochRSID = get_StochasticRelitiveStrengthIndex(df, a, b, c)
    stochRSIk = np.array(stochRSIK)                
    stochRSId = np.array(stochRSID)
    print('\n'+str([a, b, c]))
    cerebro = cerebroInit(df, stochRSIk, stochRSId)
    return cerebro
def run_strategy_wrapper(args):
    """Wrapper function for run_strategy to handle tuple of arguments."""
    return run_strategy(*args)

if __name__ == "__main__":
    maxValue = -1
    maxSym = -1  
    lst = []
    startA = startB = startC = False
    a = random.randint(0, 100)
    b = random.randint(0, 100)
    c = random.randint(0, 100)
    start = random.randint(0, 2)
    if start == 0:
        startA = True
        startB = False
        startC = False
    elif start == 1:
        startB = True
        startA = False
        startC = False
    elif start == 2:
        startC = True
        startB = False
        startA = False
    df = getDataTEST()
    repeated2 = False
    repeated = False
    for _ in range(10):
        while True:
            strategy_args = []
            for num in range(1, 200):
                if startA:
                    strategy_args.append((df, num, b, c))
                elif startB:
                    strategy_args.append((df, a, num, c))
                elif startC:
                    strategy_args.append((df, a, b, num))

            with concurrent.futures.ProcessPoolExecutor() as executor:
                results = list(executor.map(run_strategy_wrapper, strategy_args))

            for cerebro, num in zip(results, range(1, 200)):
                cerebro.run()
                VALUE = cerebro.broker.getvalue()
                print('Final Portfolio Value: %.2f' % VALUE + "")
                
                if VALUE > maxValue:
                    maxValue = VALUE
                    maxSym = num
                print(maxValue)
                print(maxSym)

            if startA:
                if maxSym == a and repeated2:
                    print([a, b, c])
                    lst.append((maxValue, [a, b, c]))
                    break
                if maxSym == a and repeated:
                    repeated2 = True
                if maxSym == a:
                    repeated = True
                else:
                    repeated = False
                    repeated2 = False
                a = maxSym
                startA = False
                startB = True
                startC = False
            elif startB:
                if maxSym == b and repeated2:
                    print([a, b, c])
                    lst.append((maxValue, [a, b, c]))
                    break
                if maxSym == b and repeated:
                    repeated2 = True
                if maxSym == b:
                    repeated = True
                else:
                    repeated = False
                    repeated2 = False
                b = maxSym
                startA = False
                startB = False
                startC = True
            elif startC:
                if maxSym == c and repeated2:
                    print([a, b, c])
                    lst.append((maxValue, [a, b, c]))
                    break
                if maxSym == c and repeated:
                    repeated2 = True
                if maxSym == c:
                    repeated = True
                else:
                    repeated = False
                    repeated2 = False
                c = maxSym
                startA = True
                startB = False
                startC = False
        
    sortedLst = sorted(lst, key=lambda x: x[0], reverse=True)
    print(sortedLst)
    with open('stochRSI.txt', 'w') as f:
        for item in sortedLst:
            f.write("%s\n" % item)
