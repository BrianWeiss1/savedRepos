import backtrader as bt
# from commands.format import dataToDF
from commands.grabData import getDataBacktest, getDataTEST
from datetime import date, datetime, time, timedelta
from commands.counter import run
import numpy as np
import matplotlib as plt
from commands.indicators.indicators import get_WMA
import time

class WeightedMovingAverage(bt.Strategy):
    params = (
        ('hull', None),  # HMA with 45 periods
    )
    def __init__(self):
        self.i = 0
        self.order = None
        self.betPercent = 0.1 

        self.long = True
        self.short = True
        self.longPrice = None
        self.shortPrice = None
        
        self.hullLong = False
        self.hullShort = False
        self.hullSignal = ""
        self.hull = self.params.hull
        
        self.runProgram = True

    def next(self):
        if self.runProgram:
            i = self.i
            close = self.data.close[0]
            # Ensure data is not NaN
            if not np.isnan(self.hull[i]):
                if self.hull[i] > close:
                    self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                    self.order = self.buy(size=self.size) 
                    self.longPrice = self.data.close[0]
                    self.short = True
                    self.long = False
                    # Implement your code for buying here
                elif close > self.hull[i]:
                    self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                    self.order = self.sell(size=self.size) 
                    self.shortPrice = self.data.close[0]
                    self.short = False
                    self.long = True
            if self.broker.getvalue() < 0:
                self.runProgram = False

            self.i += 1
continu = False
if not continu:
    maxFinalVal = -1
    maxFinalSym = -1  
    lst = []  
    k = -1
    # b = 1
    df = getDataBacktest('BTC')
    testedData = [96, 95, 69, 68, 67, 66, 62, 63, 65, 64, 61, 57, 58, 60, 55, 56, 59, 47, 48, 49, 29, 46, 28, 45, 39, 27, 38, 43, 42, 41, 30, 37, 20, 11,]
    # for b in range(1, 500, 1):
    for b in testedData:
        # while(True):
        print("\n\n\n\n" + str(b))
        valueOptions = [0, 1, 2]
        valueToChange = valueOptions[0]
        start_time = time.time()  # Start time
        cerebro = bt.Cerebro()
        cerebro.broker.set_cash(1.00)         
        cerebro.broker.setcommission(mult=50)

        if valueToChange == 0:
            hma = get_WMA(df, b) # 110, 80, 25

        npHMA = np.array(hma)
        data = bt.feeds.PandasData(dataname=df)
        cerebro.adddata(data)
        cerebro.addstrategy(WeightedMovingAverage, hull=npHMA)


        cerebro.run()

        finalVal = cerebro.broker.getvalue()
        print('Final Portfolio Value: %.2f' % finalVal + "\n")

        # cerebro.plot()

        lst.append([finalVal, b])
        if finalVal > maxFinalVal:
            maxFinalVal = finalVal
            maxFinalSym = b

    sortedLst = sorted(lst, key=lambda x: x[0], reverse=True) # How to sort a lst by the first elemenet in python
    print(sortedLst[0])
    end_time = time.time() 
    execution_time_ms = (end_time - start_time)

    print(f"The script took {execution_time_ms} seconds to run.")
    print(sortedLst)
    optimalValue = sortedLst[0][1]
else:

    pass
    # array3 = array1 + array2
    # test = [96, 95, 69, 68, 67, 66, 62, 63, 65, 64, 61, 57, 58, 60, 55, 56, 59, 47, 48, 49, 29, 46, 28, 45, 39, 27, 38, 43, 42, 41, 30, 37, 20, 11, 53]
    # sortedLst = sorted(array3, key=lambda x: x[0], reverse=True) # How to sort a lst by the first elemenet in python
    # print(sortedLst)
    testingData = []
    # for i in array3:
    #     testingData.append(i[1])
    
    print(testingData)
    
#WMA: 96, 95.
# [[4029.581584833336, 96], [2208.556466628793, 95], [76.48626873503713, 20], [1.1134629010589552, 37], [1.112730964546685, 38], [1.097149343187457, 59], [1.095631336485984, 69], [1.091076131862894, 39], [1.0892807990553328, 62], [1.0846241973011597, 61], [1.080787804253456, 58], [1.080060085076442, 68], [1.079656530061273, 57], [1.078897667633164, 67], [1.0775556605029433, 60], [1.0772735496751973, 63], [1.0756919688639044, 66], [1.071721559137433, 55], [1.0716276482632943, 65], [1.0713022202435418, 56], [1.0702514040091455, 64], [1.0684521319495008, 27], [1.0680355553285006, 45], [1.0673853751692657, 30], [1.065881315730326, 29], [1.0609965503289294, 42], [1.059589405348824, 41], [1.059214610256813, 43], [1.055556942382742, 46], [1.0547942567510402, 49], [1.0510528695594548, 48], [1.0462458645457262, 47], [1.042104818119251, 28], [0.9753380848586279, 11]]