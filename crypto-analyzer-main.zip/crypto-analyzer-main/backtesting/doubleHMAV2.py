import random
import backtrader as bt
import numpy as np
import matplotlib as plt
import time
from commands.indicators.indicators import get_DoubleHMA
from commands.indicators.calculate import findMFI
from commands.grabData import getData, getDataBacktest
from commands.counter import run
from commands.format import dataToDF
from datetime import timedelta

start_time = time.time()  # Start time
run()
class Every100CandlesObserver(bt.Observer):
    lines = ('value',)

    def next(self):
        if len(self._owner) % 100 == 0:  # Check if the bar number is a multiple of 100
            self.lines.value[0] = self._owner.broker.getvalue()  # Log the account value
            interval = timedelta(minutes=30)
            # Multiply the interval by 100
            duration = interval * len(self._owner)
            print(f'Day: {duration.days}, Candle: {len(self._owner)}, Account Value: {self.lines.value[0]}')


class DoubeHMA(bt.Strategy):
    params = (
        ('hull_20', None),  # External NumPy array for stochRSIK3
        ('hull_50', None),  # External NumPy array for stochRSID3
    )
    def __init__(self):
        self.i = 0
        self.order = None
        self.betPercent = 0.1 # I'm not sure if I should stack indicators since this is so high

        self.long = True
        self.short = True
        self.longPrice = None
        self.shortPrice = None
        
        self.hullLong = False
        self.hullShort = False
        self.hullSignal = ""
        self.hull_20 = self.params.hull_20
        self.hull_50 = self.params.hull_50
        self.runProgram = True

        
    def next(self):
        i = self.i
        if self.broker.getvalue() < 0:
            self.runProgram = False

        
        if not np.isnan(self.hull_20[i]) and not np.isnan(self.hull_50[i]) and self.runProgram:  
            if self.hull_20[i] > self.hull_50[i]:
                if self.data.close[0] > self.hull_20[i]:
                    self.hullSignal = "BUY SIGNAL"
                elif self.data.close[0] < self.hull_20[i] and self.data.close[0] > self.hull_50[i]: 
                    self.hullSignal = "LUQUIDATE CURRENT POSITION"
                elif self.data.close[0] < self.hull_50[i]: 
                    self.hullSignal = "SELL SIGNAL"
                else:
                    pass
                    # print("ERROR 1")
            elif self.hull_50[i] > self.hull_20[i]:
                if self.data.close[0] > self.hull_50[i]:
                    self.hullSignal = "SELL SIGNAL"
                elif self.data.close[0] < self.hull_50[i] and self.data.close[0] > self.hull_20[i]:
                    self.hullSignal = "LUQUIDATE CURRENT POSITION"
                elif self.data.close[0] < self.hull_20[i]:
                    self.hullSignal = "BUY SIGNAL"
                else:
                    pass
                    # print("ERROR 2")
            elif self.hull_50[i] == self.hull_20[i]:
                pass
                # print("EQUALITY ERROR 4")
            else:
                pass
                # print("ERROR 3")
                        
            if self.hull_20[i-1] > self.hull_50[i-1] and self.hull_20[i] < self.hull_50[i] :
                self.hullShort = True
            else:
                self.hullShort = False
            if self.hull_20[i - 1] < self.hull_50[i - 1] and (self.hull_20[i]) > self.hull_50[i]:
                self.hullLong = True
            else:
                self.hullLong = False
                
            # '''
            if self.hullSignal == 'BUY SIGNAL':
                self.long = True
                self.short = False
                self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                # if self.position:
                #     self.close() #size=self.position.size
                self.order = self.buy(size=self.size) #price=self.data.close[0], size=size

                self.longPrice = self.data.close[0]

            if self.hullSignal == 'SELL SIGNAL':
                self.short = True  
                self.long = False

                self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                # if self.position:
                self.order = self.sell(size=self.size*10/9) # price=self.df_data.close[0], size=size
                # if self.broker.cash < 0.1*self.broker.getvalue():
                #     self.close()
                self.shortPrice = self.data.close[0]

            if (self.hullLong == True and self.short): 
                self.long = True
                self.short = False
                self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                self.order = self.buy(size=self.size) 

                self.longPrice = self.data.close[0]
            elif (self.hullShort == True and self.long):
                self.long = False
                self.short = True  
                self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                self.order = self.sell(size=self.size*10/9) 
                self.shortPrice = self.data.close[0]
      
        self.i += 1

def init(a, b):
    cerebro = bt.Cerebro()
    cerebro.broker.set_cash(1.00)
    print('Starting Portfolio Value: %.2f' % cerebro.broker.getvalue())

    df = getDataBacktest()
    hma_20, hma_50 = get_DoubleHMA(df, a, b) # bull, bear

    npHMA_20 = np.array(hma_20)                
    npHMA_50 = np.array(hma_50)
    data = bt.feeds.PandasData(dataname=df)

    cerebro.adddata(data)
    cerebro.addstrategy(DoubeHMA, hull_20=npHMA_20, hull_50=npHMA_50)
    cerebro.addobserver(Every100CandlesObserver)
    cerebro.broker.setcommission(mult=50)
    return cerebro
option = 0

if option == 0:
    cerebro = init(55, 56)
    cerebro.run()
    cerebro.plot()
    FINAL_VALUE = cerebro.broker.getvalue()
    print(FINAL_VALUE)
else:
    lst = []  
    for _ in range(3):
        a = random.randint(0, 200)
        b = random.randint(0, 200)
        start = random.randint(0, 1)
        if start == 0:
            startA = True
            startB = False
        elif start == 1:
            startB = True
            startA = False
        cerebro = None
        maxWorth = -1
        maxSymbol = -1
        while True:
            for validValue in range(1, 8, 5):
                if startA:  
                    cerebro = init(validValue, b)
                elif startB:
                    cerebro = init(a, validValue)
                cerebro.run()
                FINAL_VALUE = cerebro.broker.getvalue()
                print('Final Portfolio Value: %.2f' % FINAL_VALUE + "\n")
                print(str(maxWorth) + "Worth")
                print(str(maxSymbol) + "Symbol")
                if maxWorth < FINAL_VALUE:
                    maxWorth = FINAL_VALUE 
                    maxSymbol = validValue
            if startA:
                if a == maxSymbol and repeated:
                    print(f'END: a={a}, b={b}')
                    print(f'[{a}, {b}]')
                    print(f'Final Value: %.2f' % maxWorth + "\n")
                    lst.append([maxWorth, [a,b]])
                    break
                if a == maxSymbol:
                    repeated = True
                else:
                    repeated = False
                a = maxSymbol
                startA = False
                startB = True
            elif startB:
                if a == maxSymbol and repeated:
                    print(f'END: a={a}, b={b}')
                    print(f'[{a}, {b}]')
                    print(f'Final Value: %.2f' % maxWorth + "\n")
                    lst.append([maxWorth, [a,b]])
                    break
                if b == maxSymbol:
                    repeated = True
                else:
                    repeated = False
                b = maxSymbol
                startB = False
                startA = True            






    sortedLst = sorted(lst, key=lambda x: x[0], reverse=True)
    end_time = time.time()
    execution_time_ms = (end_time - start_time) * 1000
    print(f"The script took {execution_time_ms} milliseconds to run.")
