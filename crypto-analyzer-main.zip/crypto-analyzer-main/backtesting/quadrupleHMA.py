import backtrader as bt

from commands.grabData import getData, getDataTEST
import random
class QuadrupleHMAStrategy(bt.Strategy):
    params = (
        ('hull_period1', 3),
        ('hull_period2', 4),
        ('hull_period3', 5),
        ('hull_period4', 6),
    )

    def __init__(self):
        # Initialize HMA indicators
        self.hma1 = bt.indicators.HullMovingAverage(self.data.close, period=self.params.hull_period1)
        self.hma2 = bt.indicators.HullMovingAverage(self.data.close, period=self.params.hull_period2)
        self.hma3 = bt.indicators.HullMovingAverage(self.data.close, period=self.params.hull_period3)
        self.hma4 = bt.indicators.HullMovingAverage(self.data.close, period=self.params.hull_period4)

    def next(self):
        # Entry condition - all HMAs ascending
        if self.crossover(self.hma1, self.hma2) and self.crossover(self.hma2, self.hma3) and self.crossover(self.hma3, self.hma4):
            self.buy()

        # Exit condition - any HMA crosses below close
        elif self.crossunder(self.hma1, self.data.close) or self.crossunder(self.hma2, self.data.close) or self.crossunder(self.hma3, self.data.close) or self.crossunder(self.hma4, self.data.close):
            self.close()

    def crossover(self, hma1, hma2):
        return hma1[-1] < hma2[-1] and hma1[0] > hma2[0]

    def crossunder(self, hma1, price):
        return hma1[-1] > price[-1] and hma1[0] < price[0]

# Example usage
def init(df, a, b, c, d):
    cerebro = bt.Cerebro()
    cerebro.broker.set_cash(1.00)
    print('Starting Portfolio Value: %.2f' % cerebro.broker.getvalue())

    data = bt.feeds.PandasData(dataname=df)

    cerebro.adddata(data)
    cerebro.addstrategy(QuadrupleHMAStrategy, hull_period1=a, hull_period2=b, hull_period3=c, hull_period4=d)
    cerebro.broker.setcommission(mult=52)
    return cerebro
    

if __name__ == '__main__':
    maxValue = -1
    maxSym = -1  
    lst = []
    startA = startB = startC = False
    a = random.randint(3, 200)
    b = random.randint(3, 200)
    c = random.randint(3, 200)
    d = random.randint(3, 200)
    start = random.randint(0, 3)
    if start == 0:
        startA = True
        startB = False
        startC = False
        startD = False
    elif start == 1:
        startB = True
        startA = False
        startC = False
        startD = False
    elif start == 2:
        startC = True
        startB = False
        startA = False
        startD = False
    elif start == 3:
        startD = True
        startB = False
        startC = False
        startA = False
    df = getDataTEST()
    print(df)
    cerebro = None
    while True:
        maxiumFinalValue = -1
        maxiumFinalSym = -1
        for validValue in range(2, 200):
            if startA:  
                cerebro = init(df, validValue, b, c, d)
            elif startB:
                cerebro = init(df, a, validValue, c, d)
            elif startC:
                cerebro = init(df, a, b, validValue, d)
            elif startD:
                cerebro = init(df, a, b, c, validValue)
            cerebro.run()
            FINAL_VALUE = cerebro.broker.getvalue()
            print('Final Portfolio Value: %.2f' % FINAL_VALUE + "\n")
            if maxiumFinalValue > FINAL_VALUE:
                FINAL_VALUE = maxiumFinalValue
                maxiumFinalSym = validValue
        if startA:
            if a == maxiumFinalSym and repeated3: # fix this
                print(f'END: a={a}, b={b}, c={c}, d={d}')
                print(f'[{a}, {b}, {c}, {d}]')
                lst.append([maxiumFinalValue, [a,b, c, d]])
                break
            elif a == maxiumFinalSym and repeated2:
                repeated3 = True
            elif a == maxiumFinalSym and repeated:
                repeated2 = True
            elif a == maxiumFinalSym:
                repeated = True
            else:
                repeated = False
                repeated2 = False
                repeated3 = False
                
            a = maxiumFinalSym
            startA = False
            startB = True
            startC = False
            startD = False
        elif startB:
            if b == maxiumFinalSym and repeated3:
                print(f'END: a={a}, b={b}, c={c}, d={d}')
                print(f'[{a}, {b}, {c}, {d}]')
                lst.append([maxiumFinalValue, [a,b, c, d]])
                break
            elif b == maxiumFinalSym and repeated2:
                repeated3 = True
            elif b == maxiumFinalSym and repeated:
                repeated2 = True
            elif b == maxiumFinalSym:
                repeated = True
            else:
                repeated = False
                repeated2 = False
                repeated3 = False
            b = maxiumFinalSym
            startA = False
            startB = False
            startC = True
            startD = False
        elif startC:
            if c == maxiumFinalSym and repeated3:
                print(f'END: a={a}, b={b}, c={c}, d={d}')
                print(f'[{a}, {b}, {c}, {d}]')
                lst.append([maxiumFinalValue, [a,b, c, d]])
                break
            elif c == maxiumFinalSym and repeated2:
                repeated3 = True
            elif c == maxiumFinalSym and repeated:
                repeated2 = True
            elif c == maxiumFinalSym:
                repeated = True
            else:
                repeated = False
                repeated2 = False
                repeated3 = False
            c = maxiumFinalSym
            startA = False
            startB = False
            startC = False
            startD = True
        elif startD:
            if d == maxiumFinalSym and repeated3:
                print(f'END: a={a}, b={b}, c={c}, d={d}')
                print(f'[{a}, {b}, {c}, {d}]')
                lst.append([maxiumFinalValue, [a,b, c, d]])
                break
            elif d == maxiumFinalSym and repeated2:
                repeated3 = True
            elif d == maxiumFinalSym and repeated:
                repeated2 = True
            elif d == maxiumFinalSym:
                repeated = True
            else:
                repeated = False
                repeated2 = False
                repeated3 = False
            d = maxiumFinalSym
            startA = True
            startB = False
            startC = False
            startD = False
    
    
    
    cerebro = bt.Cerebro()
    cerebro.addstrategy(QuadrupleHMAStrategy, hull_period1=4, hull_period2=2, hull_period3=3, hull_period4=4)
    cerebro.broker.set_cash(1.00)         
    cerebro.broker.setcommission(mult=100)
    
    df = getData()
    data = bt.feeds.PandasData(dataname=df)
    cerebro.adddata(data)
    cerebro.broker.setcommission(mult=100)
    cerebro.run()
    finalVal = cerebro.broker.getvalue()

    print('Final Portfolio Value: %.2f' % finalVal + "\n")
