import random
import backtrader as bt
import numpy as np
# import matplotlib as plt
import time
from commands.indicators.indicators import get_DoubleEMA
from commands.indicators.calculate import findMFI
from commands.grabData import getData
from commands.counter import run
from commands.format import dataToDF

start_time = time.time()  # Start time
run()
class OpeningRangeBreakout(bt.Strategy):
    params = (
        ('hull_20', None),  # External NumPy array for stochRSIK3
        ('hull_50', None),  # External NumPy array for stochRSID3
    )
    def __init__(self):
        self.i = 0
        self.order = None
        self.betPercent = 0.1 # I'm not sure if I should stack indicators since this is so high

        self.long = True
        self.short = True
        self.longPrice = None
        self.shortPrice = None
        
        self.hullLong = False
        self.hullShort = False
        self.hullSignal = ""
        self.hull_20 = self.params.hull_20
        self.hull_50 = self.params.hull_50
        self.runProgram = True

        
    def next(self):
        i = self.i
        if self.broker.getvalue() < 0:
            self.runProgram = False

        
        if not np.isnan(self.hull_20[i]) and not np.isnan(self.hull_50[i]) and self.runProgram:  
            if self.hull_20[i] > self.hull_50[i]:
                if self.data.close[0] > self.hull_20[i]:
                    self.hullSignal = "BUY SIGNAL"
                elif self.data.close[0] < self.hull_20[i] and self.data.close[0] > self.hull_50[i]: 
                    self.hullSignal = "LUQUIDATE CURRENT POSITION"
                elif self.data.close[0] < self.hull_50[i]: 
                    self.hullSignal = "SELL SIGNAL"
                else:
                    pass
                    # print("ERROR 1")
            elif self.hull_50[i] > self.hull_20[i]:
                if self.data.close[0] > self.hull_50[i]:
                    self.hullSignal = "SELL SIGNAL"
                elif self.data.close[0] < self.hull_50[i] and self.data.close[0] > self.hull_20[i]:
                    self.hullSignal = "LUQUIDATE CURRENT POSITION"
                elif self.data.close[0] < self.hull_20[i]:
                    self.hullSignal = "BUY SIGNAL"
                else:
                    pass
                    # print("ERROR 2")
            elif self.hull_50[i] == self.hull_20[i]:
                pass
                # print("EQUALITY ERROR 4")
            else:
                pass
                # print("ERROR 3")
                        
            if self.hull_20[i-1] > self.hull_50[i-1] and self.hull_20[i] < self.hull_50[i] :
                self.hullShort = True
            else:
                self.hullShort = False
            if self.hull_20[i - 1] < self.hull_50[i - 1] and (self.hull_20[i]) > self.hull_50[i]:
                self.hullLong = True
            else:
                self.hullLong = False
                
            # '''
            if self.hullSignal == 'BUY SIGNAL':
                self.long = True
                self.short = False
                self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                # if self.position:
                #     self.close() #size=self.position.size
                self.order = self.buy(size=self.size) #price=self.data.close[0], size=size

                self.longPrice = self.data.close[0]

            if self.hullSignal == 'SELL SIGNAL':
                self.short = True  
                self.long = False

                self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                # if self.position:
                self.order = self.sell(size=self.size) # price=self.df_data.close[0], size=size
                # if self.broker.cash < 0.1*self.broker.getvalue():
                #     self.close()
                self.shortPrice = self.data.close[0]

            if (self.hullLong == True and self.short): 
                self.long = True
                self.short = False
                self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                self.order = self.buy(size=self.size) 

                self.longPrice = self.data.close[0]
            elif (self.hullShort == True and self.long):
                self.long = False
                self.short = True  
                self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                self.order = self.sell(size=self.size) 
                self.shortPrice = self.data.close[0]
      
        self.i += 1

def init(df, a, b):
    cerebro = bt.Cerebro()
    cerebro.broker.set_cash(1.00)
    print('Starting Portfolio Value: %.2f' % cerebro.broker.getvalue())

    hma_20, hma_50 = get_DoubleEMA(df, a, b) # bull, bear

    npHMA_20 = np.array(hma_20)                
    npHMA_50 = np.array(hma_50)
    data = bt.feeds.PandasData(dataname=df)

    cerebro.adddata(data)
    cerebro.addstrategy(OpeningRangeBreakout, hull_20=npHMA_20, hull_50=npHMA_50)
    cerebro.broker.setcommission(mult=50)
    return cerebro
    
lst = []  
values = []
cerebro = None
df = getData()
for i in range(1, 100):
    for j in range(1, 100):
        cerebro = init(df, i, j)
        cerebro.run()
        FINAL_VALUE = cerebro.broker.getvalue()
        print('Final Portfolio Value: %.2f' % FINAL_VALUE + " [" + str(i) + "] [" + str(j) + "]\n")
        values.append([FINAL_VALUE, [i, j]])
    
values.sort(key=lambda x: x[0], reverse=True)
print(values)
with open('values.txt', 'w') as f:
    f.write(str(values))
end_time = time.time()
execution_time_ms = (end_time - start_time) * 1000
print(f"The script took {execution_time_ms} milliseconds to run.")
