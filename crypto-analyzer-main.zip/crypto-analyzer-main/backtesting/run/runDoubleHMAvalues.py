from backtesting.doubleHMA import init as initV1
from backtesting.doubleHMAV2 import init as initV2


with open('values.txt', 'r') as file:
    values = eval(file.readlines()[0])
dic = {}
print(type(values))
for value in values:
    print(str(value[1]))
    print("V1")
    cerebro = initV1(value[1][0], value[1][1])
    cerebro.run()
    cerebro.plot()
    FINAL_VALUE = cerebro.broker.getvalue()
    print(FINAL_VALUE)
    print("V2")
    cerebro = initV2(value[1][0], value[1][1])
    cerebro.run()
    cerebro.plot()
    FINAL_VALUE = cerebro.broker.getvalue()
    print(FINAL_VALUE)