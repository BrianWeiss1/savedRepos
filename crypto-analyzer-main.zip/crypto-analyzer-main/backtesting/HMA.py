import backtrader as bt
# from commands.format import dataToDF
from commands.grabData import getData, getDataBacktest, getDataTEST
from datetime import date, datetime, time, timedelta
from commands.counter import run
import numpy as np
import matplotlib as plt
from commands.indicators.indicators import get_hull
import time

class OpeningRangeBreakout(bt.Strategy):
    params = (
        ('hull', None),  # HMA with 45 periods
    )
    def __init__(self):
        self.i = 0
        self.order = None
        self.betPercent = 0.1 

        self.long = True
        self.short = True
        self.longPrice = None
        self.shortPrice = None
        
        self.hullLong = False
        self.hullShort = False
        self.hullSignal = ""
        self.hull = self.params.hull
        
        self.runProgram = True

    def next(self):
        if self.runProgram:
            i = self.i
            close = self.data.close[0]
            # Ensure data is not NaN
            if not np.isnan(self.hull[i]):
                if self.hull[i] > close:
                    self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                    self.order = self.buy(size=self.size) 
                    self.longPrice = self.data.close[0]
                    self.short = True
                    self.long = False
                    # Implement your code for buying here
                elif close > self.hull[i]:
                    self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                    self.order = self.sell(size=self.size) 
                    self.shortPrice = self.data.close[0]
                    self.short = False
                    self.long = True
            if self.broker.getvalue() < 0:
                self.runProgram = False

            self.i += 1
maxFinalVal = -1
maxFinalSym = -1  
lst = []  
k = -1
# b = 1
df = getDataBacktest('BTC')
lst2 = [91, 69, 71, 84, 60, 79, 67, 77, 76, 78, 58, 70, 87, 75, 74, 80, 86, 72, 73, 85, 57, 93, 59, 89, 88, 47, 56, 90, 81, 95, 83, 7, 6, 82, 13, 4]
# for b in range(1, 500, 1):
for b in lst2:
    # while(True):
    print("\n\n\n\n" + str(b))
    valueOptions = [0, 1, 2]
    valueToChange = valueOptions[0]
    start_time = time.time()  # Start time
    cerebro = bt.Cerebro()
    cerebro.broker.set_cash(1.00)         
    cerebro.broker.setcommission(mult=50)

    if valueToChange == 0:
        hma = get_hull(df, b) # 110, 80, 25

    npHMA = np.array(hma)
    data = bt.feeds.PandasData(dataname=df)
    cerebro.adddata(data)
    cerebro.addstrategy(OpeningRangeBreakout, hull=npHMA)


    cerebro.run()

    finalVal = cerebro.broker.getvalue()
    print('Final Portfolio Value: %.2f' % finalVal + "\n")

    # cerebro.plot()

    lst.append([finalVal, b])
    if finalVal > maxFinalVal:
        maxFinalVal = finalVal
        maxFinalSym = b

sortedLst = sorted(lst, key=lambda x: x[0], reverse=True) # How to sort a lst by the first elemenet in python
print(sortedLst[0])
end_time = time.time() 
execution_time_ms = (end_time - start_time)

print(f"The script took {execution_time_ms} seconds to run.")
print(sortedLst)
optimalValue = sortedLst[0][1]


# lst = []
# array3 = [[16799649.060471237, 91], [6509177.800931573, 69], [5998635.746337697, 71], [5883522.789901577, 84], [4306011.16972347, 60], [3077371.706846427, 79], [2625990.63914134, 67], [2321374.296311112, 77], [1975393.8645581976, 76], [1900591.1387724802, 78], [1650823.3722435422, 58], [1484964.494018143, 70], [1460472.688342709, 87], [1447873.3453972302, 75], [1424764.7791811284, 74], [1403762.3687862754, 80], [1364264.543910835, 86], [1039383.940977999, 72], [750678.6683838358, 73], [617313.9460354019, 85], [471620.3034528638, 57], [432075.6761854002, 93], [317377.36779762106, 59], [230331.1487588822, 89], [226289.49731224496, 88], [203877.0059405698, 47], [177204.99856775044, 56], [93981.22666594805, 90], [71452.91982553038, 81], [55049.028967600665, 95], [24145.27594916796, 83], [16512.81251175012, 7], [11441.935775869533, 6], [6258.629707273896, 82], [4040.9138756387983, 13], [801.5754958105445, 4], [11.819769437658145, 3]]
# for i in array3:
#     lst.append(i[1])
# print(lst)
