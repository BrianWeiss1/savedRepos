
import os
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath("/Users/brianw/Documents/GitHub/crypto-analyzer")))
