import backtrader as bt
# from commands.format import dataToDF
from commands.grabData import getData, getDataTEST, getForexData
from datetime import date, datetime, time, timedelta
from commands.counter import run
import numpy as np
import matplotlib as plt
from commands.indicators.indicators import get_TripleHMA
import time
from commands.indicators.calculate import findMFI
import pandas as pd

class OpeningRangeBreakout(bt.Strategy):
    params = (
        ('hull_short', None),  # HMA with 45 periods
        ('hull_medium', None), # HMA with 105 periods
        ('hull_long', None),   # HMA with 240 periods
    )
    def __init__(self):
        self.i = 0
        self.order = None
        self.betPercent = 0.1 # I'm not sure if I should stack indicators since this is so high

        self.long = True
        self.short = True
        self.longPrice = None
        self.shortPrice = None
        
        self.hullLong = False
        self.hullShort = False
        self.hullSignal = ""
        self.hull_short = self.params.hull_short
        self.hull_medium = self.params.hull_medium
        self.hull_long = self.params.hull_long
        
        self.runProgram = True

    def next(self):
        if self.runProgram:
            i = self.i
            
            # Ensure data is not NaN
            if not np.isnan(self.hull_short[i]) and not np.isnan(self.hull_medium[i]) and not np.isnan(self.hull_long[i]):  
                if self.hull_short[i] > self.hull_medium[i] and self.hull_medium[i] > self.hull_long[i]:
                    # Buy logic
                    self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                    self.order = self.buy(size=self.size) 
                    self.longPrice = self.data.close[0]
                    self.long = True
                    self.short = False
                    # Implement your code for buying here
                elif self.hull_short[i] < self.hull_medium[i] and self.hull_medium[i] < self.hull_long[i]:
                    self.size = ((self.betPercent * self.broker.cash)/ self.data.close[0])
                    self.order = self.sell(size=self.size) 
                    self.shortPrice = self.data.close[0]
                    self.long = False
                    self.short = True
            if self.broker.getvalue() < 0:
                self.runProgram = False

            self.i += 1
maxFinalVal = -1
maxFinalSym = -1  
lst = []  
k = -1
b = 1
# while(True):
valueOptions = [0, 1, 2]
valueToChange = valueOptions[0]
start_time = time.time()  # Start time
a = np.multiply(b, 10)
cerebro = bt.Cerebro()
cerebro.broker.set_cash(1.00)         
cerebro.broker.setcommission(mult=52)

df = getForexData('JPY')
df['volume'] = 0
df = df.iloc[::-1]
df.index = pd.to_datetime(df.index)
print(type(df.index[0]))
# df.index = pd.to_datetime(df.index)

if valueToChange == 0:
    hma_short, hma_medium, hma_long = get_TripleHMA(df, 25,75,34














) # 110, 80, 25
print(hma_short)
print(hma_medium)
print(hma_long)
print(df)
npHMA_short = np.array(hma_short)
npHMA_medium = np.array(hma_medium)
npHMA_long = np.array(hma_long)
data = bt.feeds.PandasData(dataname=df)
cerebro.adddata(data)
cerebro.addstrategy(OpeningRangeBreakout, hull_short=npHMA_short, hull_medium=npHMA_medium, hull_long=npHMA_long)


cerebro.run()

finalVal = cerebro.broker.getvalue()
print('Final Portfolio Value: %.2f' % finalVal + "\n")

cerebro.plot()

lst.append([finalVal, b])
if finalVal > maxFinalVal:
    maxFinalVal = finalVal
    maxFinalSym = b

sortedLst = sorted(lst, key=lambda x: x[0], reverse=True) # How to sort a lst by the first elemenet in python
print(sortedLst[0])
end_time = time.time() 
execution_time_ms = (end_time - start_time)

print(f"The script took {execution_time_ms} seconds to run.")
print(sortedLst)
optimalValue = sortedLst[0][1]

